﻿
Public Class clsStudents

    '------------------------------------------------------------
    '-                File Name : clsStudents.frm               - 
    '-                Part of Project: Students class           -
    '------------------------------------------------------------
    '-                Written By: Justin Ganzak                 -
    '-                Written On: April 7, 2022                 -
    '------------------------------------------------------------
    '- File Purpose:                                            -
    '-                                                          -
    '- This file contains the secondary form which holds the    -
    '- code from the class and its properties. It had the getter-
    '- and setters as well as the constructor.
    '------------------------------------------------------------
    '- Program Purpose:                                         -
    '-                                                          -
    '- The purpose of this program is to create a class which   -
    '- holds the students data.
    '------------------------------------------------------------
    '- Global Variable Dictionary (alphabetically):             -
    '- arrScore - Holds grade score
    '- sngExam - Holds exam scores
    '- strLName - Holds last name
    '- strInitials - Holds initials
    '------------------------------------------------------------

    Public strInitials As String
    Public sngExam As Single
    Public arrScore(4) As Single
    Public strLName As String

    Public Sub setInitials(ByVal newInitials As String)

        '------------------------------------------------------------
        '-            Subprogram Name: setInitials                  -
        '------------------------------------------------------------
        '-                Written By: Justin Ganzak                 -
        '-                Written On: April 7, 2022                 -
        '------------------------------------------------------------
        '- Subprogram Purpose:                                      -
        '-                                                          -
        '- This handles the setter for the initials                 -
        '------------------------------------------------------------
        '- Parameter Dictionary (in parameter order):               -
        '- newInitials - setting the newinitials
        '------------------------------------------------------------
        '- Local Variable Dictionary (alphabetically):              -
        '- (None)                                                   -
        '------------------------------------------------------------

        strInitials = newInitials
    End Sub

    Public Function getInitials() As String
        '------------------------------------------------------------
        '-            Subprogram Name: setInitials                  -
        '------------------------------------------------------------
        '-                Written By: Justin Ganzak                 -
        '-                Written On: April 7, 2022                 -
        '------------------------------------------------------------
        '- Subprogram Purpose:                                      -
        '-                                                          -
        '- This handles the getter for the initials                 -
        '------------------------------------------------------------
        '- Parameter Dictionary (in parameter order):               -
        '- 
        '------------------------------------------------------------
        '- Local Variable Dictionary (alphabetically):              -
        '- (None)                                                   -
        '------------------------------------------------------------
        Return (strInitials)
    End Function

    Public Sub setLName(ByVal newLName As String)
        '------------------------------------------------------------
        '-            Subprogram Name: setLName                     -
        '------------------------------------------------------------
        '-                Written By: Justin Ganzak                 -
        '-                Written On: April 7, 2022                 -
        '------------------------------------------------------------
        '- Subprogram Purpose:                                      -
        '-                                                          -
        '- This handles the setter for the Last Name                -
        '------------------------------------------------------------
        '- Parameter Dictionary (in parameter order):               -
        '- newLName - holds Last name when setting
        '------------------------------------------------------------
        '- Local Variable Dictionary (alphabetically):              -
        '- (None)                                                   -
        '------------------------------------------------------------
        strLName = newLName
    End Sub

    Public Function getLName() As String
        '------------------------------------------------------------
        '-            Subprogram Name: setInitials                  -
        '------------------------------------------------------------
        '-                Written By: Justin Ganzak                 -
        '-                Written On: April 7, 2022                 -
        '------------------------------------------------------------
        '- Subprogram Purpose:                                      -
        '-                                                          -
        '- This handles the getter for the Last Name                -
        '------------------------------------------------------------
        '- Parameter Dictionary (in parameter order):               -
        '-
        '------------------------------------------------------------
        '- Local Variable Dictionary (alphabetically):              -
        '- (None)                                                   -
        '------------------------------------------------------------
        Return (strLName)
    End Function

    Public Sub setScore(ByVal newScore() As Single)
        '------------------------------------------------------------
        '-            Subprogram Name: setScore                     -
        '------------------------------------------------------------
        '-                Written By: Justin Ganzak                 -
        '-                Written On: April 7, 2022                 -
        '------------------------------------------------------------
        '- Subprogram Purpose:                                      -
        '-                                                          -
        '- This handles the setter for the homework scores          -
        '------------------------------------------------------------
        '- Parameter Dictionary (in parameter order):               -
        '- newScore - array for homework scores
        '------------------------------------------------------------
        '- Local Variable Dictionary (alphabetically):              -
        '- (None)                                                   -
        '------------------------------------------------------------
        arrScore = newScore
    End Sub

    Public Function getScore(i As Integer) As Single
        '------------------------------------------------------------
        '-            Subprogram Name: getScore                     -
        '------------------------------------------------------------
        '-                Written By: Justin Ganzak                 -
        '-                Written On: April 7, 2022                 -
        '------------------------------------------------------------
        '- Subprogram Purpose:                                      -
        '-                                                          -
        '- This handles the getter for the score                    -
        '------------------------------------------------------------
        '- Parameter Dictionary (in parameter order):               -
        '- i - counter
        '------------------------------------------------------------
        '- Local Variable Dictionary (alphabetically):              -
        '- (None)                                                   -
        '------------------------------------------------------------
        Return arrScore(i)
    End Function

    Public Sub setExam(ByVal newExam As Single)
        '------------------------------------------------------------
        '-            Subprogram Name: setExam                      -
        '------------------------------------------------------------
        '-                Written By: Justin Ganzak                 -
        '-                Written On: April 7, 2022                 -
        '------------------------------------------------------------
        '- Subprogram Purpose:                                      -
        '-                                                          -
        '- This handles the setter for the Exam Score               -
        '------------------------------------------------------------
        '- Parameter Dictionary (in parameter order):               -
        '- newExam - setting the newExam scores
        '------------------------------------------------------------
        '- Local Variable Dictionary (alphabetically):              -
        '- (None)                                                   -
        '------------------------------------------------------------
        sngExam = newExam

    End Sub

    Public Function getExam() As Single
        '------------------------------------------------------------
        '-            Subprogram Name: getExam                      -
        '------------------------------------------------------------
        '-                Written By: Justin Ganzak                 -
        '-                Written On: April 7, 2022                 -
        '------------------------------------------------------------
        '- Subprogram Purpose:                                      -
        '-                                                          -
        '- This handles the getter for the initials                 -
        '------------------------------------------------------------
        '- Parameter Dictionary (in parameter order):               -
        '- newInitials - setting the newinitials
        '------------------------------------------------------------
        '- Local Variable Dictionary (alphabetically):              -
        '- (None)                                                   -
        '------------------------------------------------------------
        Return sngExam
    End Function
    Public Sub New(ByVal newInitials As String, ByVal newLName As String, ByVal newScore() As Single, ByVal newExam As Single)
        '------------------------------------------------------------
        '-            Subprogram Name: Constructor                  -
        '------------------------------------------------------------
        '-                Written By: Justin Ganzak                 -
        '-                Written On: April 7, 2022                 -
        '------------------------------------------------------------
        '- Subprogram Purpose:                                      -
        '-                                                          -
        '- This handles the getters and setter subroutines and calling them-
        '------------------------------------------------------------
        '- Parameter Dictionary (in parameter order):               -
        '- newInitials - setting the newinitials
        '- newLName
        '- newScore()
        '- newExam
        '------------------------------------------------------------
        '- Local Variable Dictionary (alphabetically):              -
        '- (None)                                                   -
        '------------------------------------------------------------
        setExam(newExam)
        setInitials(newInitials)
        setLName(newLName)
        setScore(newScore)

    End Sub


End Class
