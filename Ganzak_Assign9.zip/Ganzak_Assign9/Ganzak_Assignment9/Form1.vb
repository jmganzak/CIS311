﻿Imports Microsoft.Office.Interop

Public Class Form1


    '------------------------------------------------------------
    '-                File Name : frmMain.frm                   - 
    '-                Part of Project: Generate Sheet with data -
    '------------------------------------------------------------
    '-                Written By: Justin Ganzak                 -
    '-                Written On: April 7, 2022                 -
    '------------------------------------------------------------
    '- File Purpose:                                            -
    '-                                                          -
    '- This file contains the main form for the entire appli-   -
    '- cation.  All user input is gathered on this form.  The   -
    '- calculations which are performed by the application      -
    '- reside in this file as well.  Finally all generated      -
    '- output is contained here too.                            -
    '------------------------------------------------------------
    '- Program Purpose:                                         -
    '-                                                          -
    '- The purpose of this program is to generate an excel sheet-
    '- with data from an list. It calculates their grades and   -
    '- provides basic statistics about the numbers.
    '- Global Variable Dictionary (alphabetically):             -
    '- myStudents - List of students from clsStudents. Holds their- 
    '- information for later use                                -
    '------------------------------------------------------------


    Dim myStudents As List(Of clsStudents) = New List(Of clsStudents)

    Private Sub btnGo_Click(sender As Object, e As EventArgs) Handles btnGo.Click

        '------------------------------------------------------------
        '-            Subprogram Name: btnGoClick                   -
        '------------------------------------------------------------
        '-                Written By: Justin Ganzak                 -
        '-                Written On: April 7, 2022              -
        '------------------------------------------------------------
        '- Subprogram Purpose:                                      -
        '-                                                          -
        '- This subroutine populates the list with student information-
        '- and handles calling the subroutines to display the data on
        '- the excel sheet. It also creates the excel sheet altogether-
        '------------------------------------------------------------
        '- Parameter Dictionary (in parameter order):               -
        '-sender
        '-e
        '------------------------------------------------------------
        '- Local Variable Dictionary (alphabetically):              -
        '- CheckExcel - Object holds excel doc
        '- anExcelDoc - Actual excel application
        '------------------------------------------------------------


        myStudents.Add(New clsStudents("V.A.", "Borstellis", {25, 25, 25, 25}, 100.0))
        myStudents.Add(New clsStudents("A.S.", "Reid", {20, 21, 20, 18}, 75.0))
        myStudents.Add(New clsStudents("C.U.", "Tyler", {19, 20, 21, 24}, 75.5))
        myStudents.Add(New clsStudents("H.A.", "Renee", {20, 23, 23, 25}, 80.5))
        myStudents.Add(New clsStudents("I.A.", "Douglas", {24, 23, 25, 25}, 95.0))
        myStudents.Add(New clsStudents("M.A.", "Elenaips", {23, 24, 23, 21}, 94.5))
        myStudents.Add(New clsStudents("A.L.", "Emmet", {21, 19, 18, 15}, 73.0))
        myStudents.Add(New clsStudents("S.U.", "James", {21, 24, 23, 22}, 87.5))
        myStudents.Add(New clsStudents("S.H.", "Issacs", {23, 24, 21, 21}, 93.0))
        myStudents.Add(New clsStudents("B.I.", "Opus", {23, 24, 25, 23}, 97.5))
        myStudents.Add(New clsStudents("T.R.", "Alski", {24, 25, 25, 23}, 95.5))
        myStudents.Add(New clsStudents("H.E.", "Zeus", {23, 24, 23, 23}, 77.0))
        myStudents.Add(New clsStudents("S.C.", "Ustaf", {24, 23, 24, 25}, 91.0))
        myStudents.Add(New clsStudents("K.I.", "Chrint", {23, 23, 24, 21}, 89.0))
        myStudents.Add(New clsStudents("J.E.", "Yaz", {25, 24, 23, 24}, 92.5))
        myStudents.Add(New clsStudents("F.R.", "Franks", {23, 19, 18, 23}, 88.5))
        myStudents.Add(New clsStudents("W.I.", "Walton", {24, 23, 23, 19}, 90.0))
        myStudents.Add(New clsStudents("K.A.", "Gilch", {24, 23, 25, 24}, 92.0))
        myStudents.Add(New clsStudents("R.O.", "Little", {23, 24, 23, 24}, 94.0))
        myStudents.Add(New clsStudents("S.A.", "Xerxes", {24, 23, 25, 23}, 94.0))
        myStudents.Add(New clsStudents("W.I.", "Harris", {23, 24, 25, 23}, 92.0))
        myStudents.Add(New clsStudents("T.I.", "Vargo", {24, 23, 25, 25}, 99.0))
        myStudents.Add(New clsStudents("I.E.", "Interas", {24, 23, 25, 25}, 97.5))
        myStudents.Add(New clsStudents("T.O.", "Kiliens", {23, 19, 18, 18}, 73.0))
        myStudents.Add(New clsStudents("E.R.", "Manrose", {23, 24, 25, 23}, 84.0))
        myStudents.Add(New clsStudents("W.A.", "Nelson", {23, 24, 25, 23}, 87.0))
        myStudents.Add(New clsStudents("K.U.", "Quaras", {23, 24, 25, 23}, 96.5))

        Dim CheckExcel As Object
        Dim anExcelDoc As Excel.Application
        Try
            CheckExcel = GetObject(, "Excel.Application")
        Catch ex As Exception

        End Try                                     '

        If CheckExcel Is Nothing Then
            anExcelDoc = New Excel.Application()
            anExcelDoc.Visible = True
        Else
            anExcelDoc = CheckExcel
            anExcelDoc.Visible = True

        End If

        anExcelDoc.Workbooks.Add()
        anExcelDoc.Sheets.Add()


        genHeaders(anExcelDoc)
        generateData(anExcelDoc)
        genStats(anExcelDoc)
        MessageBox.Show("Data successfully generated")

    End Sub

    Sub genHeaders(anExcelDoc As Excel.Application)

        '------------------------------------------------------------
        '-            Subprogram Name: genHeaders                   -
        '------------------------------------------------------------
        '-                Written By: Justin Ganzak                 -
        '-                Written On: April 7, 2022                 -
        '------------------------------------------------------------
        '- Subprogram Purpose:                                      -
        '-                                                          -
        '- This subroutine generates the headers in the excel sheet -
        '- ie: name, initials, grades, exam, final, etc. Auto sizes -
        '- as well
        '------------------------------------------------------------
        '- Parameter Dictionary (in parameter order):               -
        '- anExcelDoc - the excel application
        '------------------------------------------------------------
        '- Local Variable Dictionary (alphabetically):              -
        '- count - temp counter variables for loops
        '- headers() - array of strings holding headers
        '------------------------------------------------------------


        Dim count As Integer = 0
        Dim headers() As String = {"Initials: ", "Name:", "Grade 1:", "Grade 2:", "Grade 3:", "Grade 4:", "Grade Total:", "Exam:", "Final Grade:"}
        For i = 1 To 9
            anExcelDoc.Cells(1, i) = headers(count)
            count += 1
            anExcelDoc.Range("A1:I2").Columns.AutoFit()
        Next
        anExcelDoc.Cells(myStudents.Count + 3, 2) = "Aver:"
        anExcelDoc.Cells(myStudents.Count + 4, 2) = "St Dev:"
        anExcelDoc.Cells(myStudents.Count + 5, 2) = "Min:"
        anExcelDoc.Cells(myStudents.Count + 6, 2) = "Max:"
    End Sub

    Sub generateData(anExcelDoc As Excel.Application)

        '------------------------------------------------------------
        '-            Subprogram Name: generateData                 -
        '------------------------------------------------------------
        '-                Written By: Justin Ganzak                 -
        '-                Written On: April 7, 2022                 -
        '------------------------------------------------------------
        '- Subprogram Purpose:                                      -
        '-                                                          -
        '- This subroutine handles generating the data onto the excel-
        '- sheet and making sure it's put into the proper place on  -
        '- table.
        '------------------------------------------------------------
        '- Parameter Dictionary (in parameter order):               -
        '- anExcelDoc - excel application
        '------------------------------------------------------------
        '- Local Variable Dictionary (alphabetically):              -
        '- count - counter variable for loops                       -
        '------------------------------------------------------------


        Dim count As Integer = 2

        For i = 0 To myStudents.Count - 1
            anExcelDoc.Cells(count, 1) = myStudents(i).strInitials      'Print Initials
            count += 1
        Next

        count = 2                       'Reset Row
        For i = 0 To myStudents.Count - 1
            anExcelDoc.Cells(count, 2) = myStudents(i).strLName         'Print LastName
            count += 1

        Next

        count = 2                         'Reset row
        For i = 0 To myStudents.Count - 1
            anExcelDoc.Cells(count, 3) = myStudents(i).arrScore         'Print Grade1
            count += 1

        Next

        count = 2                         'Reset row
        For i = 0 To myStudents.Count - 1
            anExcelDoc.Cells(count, 4) = myStudents(i).arrScore(1)         'Print Grade2
            count += 1
        Next

        count = 2                         'Reset row
        For i = 0 To myStudents.Count - 1
            anExcelDoc.Cells(count, 5) = myStudents(i).arrScore(2)         'Print Grade3
            count += 1

        Next

        count = 2                         'Reset row
        For i = 0 To myStudents.Count - 1
            anExcelDoc.Cells(count, 6) = myStudents(i).arrScore(3)         'Print Grade4
            count += 1
        Next

        count = 2
        Dim temp As Integer = 2
        For i = 0 To myStudents.Count - 1
            anExcelDoc.Cells(count, 7) = "=sum(c" & temp & "..f" & temp         'Print Total Grade
            count += 1
            temp += 1
        Next

        count = 2                         'Reset row
        For i = 0 To myStudents.Count - 1
            anExcelDoc.Cells(count, 8) = myStudents(i).sngExam                  'Print Exam
            count += 1
        Next



        count = 2                         'Reset row
        For i = 0 To myStudents.Count - 1
            anExcelDoc.Cells(count, 9) = "=sum(.4*" & "G" & count & "+ .6*" & "H" & count      'Print Final
            count += 1
        Next

    End Sub

    Sub genStats(anExcelDoc As Excel.Application)

        '------------------------------------------------------------
        '-            Subprogram Name: genStatistics                -
        '------------------------------------------------------------
        '-                Written By: Justin Ganzak                 -
        '-                Written On: April 7, 2022                 -
        '------------------------------------------------------------
        '- Subprogram Purpose:                                      -
        '-                                                          -
        '- This subroutine handles generate the data statistics on  -
        '- the data into the correct cells of the sheet. 
        '------------------------------------------------------------
        '- Parameter Dictionary (in parameter order):               -
        '- anExcelDoc - the excel sheet
        '------------------------------------------------------------
        '- Local Variable Dictionary (alphabetically):              -
        '- count - counter variable
        '- temp - counter variable
        '------------------------------------------------------------


        Dim count As Integer = 3
        Dim temp As Integer = 2

        anExcelDoc.Cells(myStudents.Count + 3, count) = "=AVERAGE(C" & temp & "..C" & myStudents.Count + 1     'Print Avg Grad 1
        anExcelDoc.Cells(myStudents.Count + 3, count + 1) = "=AVERAGE(D" & temp & "..D" & myStudents.Count + 1     'Print Avg Grad 2
        anExcelDoc.Cells(myStudents.Count + 3, count + 2) = "=AVERAGE(E" & temp & "..E" & myStudents.Count + 1     'Print Avg Grad 3
        anExcelDoc.Cells(myStudents.Count + 3, count + 3) = "=AVERAGE(F" & temp & "..F" & myStudents.Count + 1     'Print Avg Grad 4
        anExcelDoc.Cells(myStudents.Count + 3, count + 4) = "=AVERAGE(G" & temp & "..G" & myStudents.Count + 1     'Print Avg Total
        anExcelDoc.Cells(myStudents.Count + 3, count + 5) = "=AVERAGE(H" & temp & "..H" & myStudents.Count + 1     'Print Avg Exam
        anExcelDoc.Cells(myStudents.Count + 3, count + 6) = "=AVERAGE(I" & temp & "..I" & myStudents.Count + 1     'Print Avg Final


        anExcelDoc.Cells(myStudents.Count + 4, count) = "=STDEV(C" & temp & "..C" & myStudents.Count + 1     'Print STDEV Grade 1
        anExcelDoc.Cells(myStudents.Count + 4, count + 1) = "=STDEV(D" & temp & "..D" & myStudents.Count + 1     'Print STDEV Grade 2
        anExcelDoc.Cells(myStudents.Count + 4, count + 2) = "=STDEV(E" & temp & "..E" & myStudents.Count + 1     'Print STDEV Grade 3
        anExcelDoc.Cells(myStudents.Count + 4, count + 3) = "=STDEV(F" & temp & "..F" & myStudents.Count + 1     'Print STDEV Grade 4
        anExcelDoc.Cells(myStudents.Count + 4, count + 4) = "=STDEV(G" & temp & "..G" & myStudents.Count + 1     'Print STDEV Total
        anExcelDoc.Cells(myStudents.Count + 4, count + 5) = "=STDEV(H" & temp & "..H" & myStudents.Count + 1    'Print STDEV Exam
        anExcelDoc.Cells(myStudents.Count + 4, count + 6) = "=STDEV(I" & temp & "..I" & myStudents.Count + 1     'Print STDEV Final

        anExcelDoc.Cells(myStudents.Count + 5, count) = "=MIN(C" & temp & "..C" & myStudents.Count + 1     'Print Min Grade 1
        anExcelDoc.Cells(myStudents.Count + 5, count + 1) = "=MIN(D" & temp & "..D" & myStudents.Count + 1     'Print Min Grade 2
        anExcelDoc.Cells(myStudents.Count + 5, count + 2) = "=MIN(E" & temp & "..E" & myStudents.Count + 1     'Print Min Grade 3
        anExcelDoc.Cells(myStudents.Count + 5, count + 3) = "=MIN(F" & temp & "..F" & myStudents.Count + 1     'Print Min Grade 4
        anExcelDoc.Cells(myStudents.Count + 5, count + 4) = "=MIN(G" & temp & "..G" & myStudents.Count + 1     'Print Min Total
        anExcelDoc.Cells(myStudents.Count + 5, count + 5) = "=MIN(H" & temp & "..H" & myStudents.Count + 1    'Print Min Exam
        anExcelDoc.Cells(myStudents.Count + 5, count + 6) = "=MIN(I" & temp & "..I" & myStudents.Count + 1     'Print Min Final

        anExcelDoc.Cells(myStudents.Count + 6, count) = "=MAX(C" & temp & "..C" & myStudents.Count + 1     'Print Max Grade 1
        anExcelDoc.Cells(myStudents.Count + 6, count + 1) = "=MAX(D" & temp & "..D" & myStudents.Count + 1     'Print Max Grade 2
        anExcelDoc.Cells(myStudents.Count + 6, count + 2) = "=MAX(E" & temp & "..E" & myStudents.Count + 1     'Print Max Grade 3
        anExcelDoc.Cells(myStudents.Count + 6, count + 3) = "=MAX(F" & temp & "..F" & myStudents.Count + 1     'Print Max Grade 4
        anExcelDoc.Cells(myStudents.Count + 6, count + 4) = "=MAX(G" & temp & "..G" & myStudents.Count + 1     'Print Max Total
        anExcelDoc.Cells(myStudents.Count + 6, count + 5) = "=MAX(H" & temp & "..H" & myStudents.Count + 1    'Print Max Exam
        anExcelDoc.Cells(myStudents.Count + 6, count + 6) = "=MAX(I" & temp & "..I" & myStudents.Count + 1     'Print Max Final
    End Sub


End Class
