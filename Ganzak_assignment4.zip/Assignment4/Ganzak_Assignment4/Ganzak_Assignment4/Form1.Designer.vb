﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnNewDish = New System.Windows.Forms.Button()
        Me.btnRightUpper = New System.Windows.Forms.Button()
        Me.btnLeftUpper = New System.Windows.Forms.Button()
        Me.lstDishes = New System.Windows.Forms.ListBox()
        Me.lblDishes = New System.Windows.Forms.Label()
        Me.txtNewDish = New System.Windows.Forms.TextBox()
        Me.lstPrepped = New System.Windows.Forms.ListBox()
        Me.lblPrepped = New System.Windows.Forms.Label()
        Me.lstPreppedList = New System.Windows.Forms.ListBox()
        Me.lblPreppedList = New System.Windows.Forms.Label()
        Me.txtNewPrepped = New System.Windows.Forms.TextBox()
        Me.btnAddPrepped = New System.Windows.Forms.Button()
        Me.txtNewRaw = New System.Windows.Forms.TextBox()
        Me.btnNewRaw = New System.Windows.Forms.Button()
        Me.lblRaw = New System.Windows.Forms.Label()
        Me.lstRaw = New System.Windows.Forms.ListBox()
        Me.lblRawPrepped = New System.Windows.Forms.Label()
        Me.lstRawPrepped = New System.Windows.Forms.ListBox()
        Me.btnLowerLeft = New System.Windows.Forms.Button()
        Me.btnLowerRight = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'btnNewDish
        '
        Me.btnNewDish.Location = New System.Drawing.Point(493, 141)
        Me.btnNewDish.Name = "btnNewDish"
        Me.btnNewDish.Size = New System.Drawing.Size(75, 53)
        Me.btnNewDish.TabIndex = 0
        Me.btnNewDish.Text = "Add New Dish"
        Me.btnNewDish.UseVisualStyleBackColor = True
        '
        'btnRightUpper
        '
        Me.btnRightUpper.Location = New System.Drawing.Point(353, 284)
        Me.btnRightUpper.Name = "btnRightUpper"
        Me.btnRightUpper.Size = New System.Drawing.Size(75, 36)
        Me.btnRightUpper.TabIndex = 1
        Me.btnRightUpper.Text = "-->"
        Me.btnRightUpper.UseVisualStyleBackColor = True
        '
        'btnLeftUpper
        '
        Me.btnLeftUpper.Location = New System.Drawing.Point(353, 242)
        Me.btnLeftUpper.Name = "btnLeftUpper"
        Me.btnLeftUpper.Size = New System.Drawing.Size(75, 36)
        Me.btnLeftUpper.TabIndex = 2
        Me.btnLeftUpper.Text = "<--"
        Me.btnLeftUpper.UseVisualStyleBackColor = True
        '
        'lstDishes
        '
        Me.lstDishes.FormattingEnabled = True
        Me.lstDishes.ItemHeight = 15
        Me.lstDishes.Location = New System.Drawing.Point(12, 27)
        Me.lstDishes.Name = "lstDishes"
        Me.lstDishes.Size = New System.Drawing.Size(755, 94)
        Me.lstDishes.TabIndex = 7
        '
        'lblDishes
        '
        Me.lblDishes.AutoSize = True
        Me.lblDishes.Location = New System.Drawing.Point(12, 9)
        Me.lblDishes.Name = "lblDishes"
        Me.lblDishes.Size = New System.Drawing.Size(96, 15)
        Me.lblDishes.TabIndex = 8
        Me.lblDishes.Text = "List of All Dishes:"
        '
        'txtNewDish
        '
        Me.txtNewDish.Location = New System.Drawing.Point(574, 152)
        Me.txtNewDish.Name = "txtNewDish"
        Me.txtNewDish.Size = New System.Drawing.Size(193, 23)
        Me.txtNewDish.TabIndex = 9
        '
        'lstPrepped
        '
        Me.lstPrepped.FormattingEnabled = True
        Me.lstPrepped.ItemHeight = 15
        Me.lstPrepped.Location = New System.Drawing.Point(12, 227)
        Me.lstPrepped.Name = "lstPrepped"
        Me.lstPrepped.SelectionMode = System.Windows.Forms.SelectionMode.MultiExtended
        Me.lstPrepped.Size = New System.Drawing.Size(300, 109)
        Me.lstPrepped.TabIndex = 10
        '
        'lblPrepped
        '
        Me.lblPrepped.AutoSize = True
        Me.lblPrepped.Location = New System.Drawing.Point(12, 209)
        Me.lblPrepped.Name = "lblPrepped"
        Me.lblPrepped.Size = New System.Drawing.Size(172, 15)
        Me.lblPrepped.TabIndex = 11
        Me.lblPrepped.Text = "Prepped Items in Selected Dish:"
        '
        'lstPreppedList
        '
        Me.lstPreppedList.FormattingEnabled = True
        Me.lstPreppedList.ItemHeight = 15
        Me.lstPreppedList.Location = New System.Drawing.Point(467, 227)
        Me.lstPreppedList.Name = "lstPreppedList"
        Me.lstPreppedList.SelectionMode = System.Windows.Forms.SelectionMode.MultiExtended
        Me.lstPreppedList.Size = New System.Drawing.Size(300, 109)
        Me.lstPreppedList.TabIndex = 12
        '
        'lblPreppedList
        '
        Me.lblPreppedList.AutoSize = True
        Me.lblPreppedList.Location = New System.Drawing.Point(467, 209)
        Me.lblPreppedList.Name = "lblPreppedList"
        Me.lblPreppedList.Size = New System.Drawing.Size(136, 15)
        Me.lblPreppedList.TabIndex = 13
        Me.lblPreppedList.Text = "List of all Prepped Items:"
        '
        'txtNewPrepped
        '
        Me.txtNewPrepped.Location = New System.Drawing.Point(574, 373)
        Me.txtNewPrepped.Name = "txtNewPrepped"
        Me.txtNewPrepped.Size = New System.Drawing.Size(193, 23)
        Me.txtNewPrepped.TabIndex = 15
        '
        'btnAddPrepped
        '
        Me.btnAddPrepped.Location = New System.Drawing.Point(493, 362)
        Me.btnAddPrepped.Name = "btnAddPrepped"
        Me.btnAddPrepped.Size = New System.Drawing.Size(75, 54)
        Me.btnAddPrepped.TabIndex = 14
        Me.btnAddPrepped.Text = "Add New Prepped Item"
        Me.btnAddPrepped.UseVisualStyleBackColor = True
        '
        'txtNewRaw
        '
        Me.txtNewRaw.Location = New System.Drawing.Point(574, 622)
        Me.txtNewRaw.Name = "txtNewRaw"
        Me.txtNewRaw.Size = New System.Drawing.Size(193, 23)
        Me.txtNewRaw.TabIndex = 23
        '
        'btnNewRaw
        '
        Me.btnNewRaw.Location = New System.Drawing.Point(493, 611)
        Me.btnNewRaw.Name = "btnNewRaw"
        Me.btnNewRaw.Size = New System.Drawing.Size(75, 54)
        Me.btnNewRaw.TabIndex = 22
        Me.btnNewRaw.Text = "Add New Raw Ing"
        Me.btnNewRaw.UseVisualStyleBackColor = True
        '
        'lblRaw
        '
        Me.lblRaw.AutoSize = True
        Me.lblRaw.Location = New System.Drawing.Point(467, 458)
        Me.lblRaw.Name = "lblRaw"
        Me.lblRaw.Size = New System.Drawing.Size(144, 15)
        Me.lblRaw.TabIndex = 21
        Me.lblRaw.Text = "List of all Raw Ingredients:"
        '
        'lstRaw
        '
        Me.lstRaw.FormattingEnabled = True
        Me.lstRaw.ItemHeight = 15
        Me.lstRaw.Location = New System.Drawing.Point(467, 476)
        Me.lstRaw.Name = "lstRaw"
        Me.lstRaw.SelectionMode = System.Windows.Forms.SelectionMode.MultiExtended
        Me.lstRaw.Size = New System.Drawing.Size(300, 109)
        Me.lstRaw.TabIndex = 20
        '
        'lblRawPrepped
        '
        Me.lblRawPrepped.AutoSize = True
        Me.lblRawPrepped.Location = New System.Drawing.Point(12, 458)
        Me.lblRawPrepped.Name = "lblRawPrepped"
        Me.lblRawPrepped.Size = New System.Drawing.Size(228, 15)
        Me.lblRawPrepped.TabIndex = 19
        Me.lblRawPrepped.Text = "Raw Ingredients in Selected Prepped Item:"
        '
        'lstRawPrepped
        '
        Me.lstRawPrepped.FormattingEnabled = True
        Me.lstRawPrepped.ItemHeight = 15
        Me.lstRawPrepped.Location = New System.Drawing.Point(12, 476)
        Me.lstRawPrepped.Name = "lstRawPrepped"
        Me.lstRawPrepped.SelectionMode = System.Windows.Forms.SelectionMode.MultiExtended
        Me.lstRawPrepped.Size = New System.Drawing.Size(300, 109)
        Me.lstRawPrepped.TabIndex = 18
        '
        'btnLowerLeft
        '
        Me.btnLowerLeft.Location = New System.Drawing.Point(353, 491)
        Me.btnLowerLeft.Name = "btnLowerLeft"
        Me.btnLowerLeft.Size = New System.Drawing.Size(75, 36)
        Me.btnLowerLeft.TabIndex = 17
        Me.btnLowerLeft.Text = "<--"
        Me.btnLowerLeft.UseVisualStyleBackColor = True
        '
        'btnLowerRight
        '
        Me.btnLowerRight.Location = New System.Drawing.Point(353, 533)
        Me.btnLowerRight.Name = "btnLowerRight"
        Me.btnLowerRight.Size = New System.Drawing.Size(75, 36)
        Me.btnLowerRight.TabIndex = 16
        Me.btnLowerRight.Text = "-->"
        Me.btnLowerRight.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 15.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(792, 705)
        Me.Controls.Add(Me.txtNewRaw)
        Me.Controls.Add(Me.btnNewRaw)
        Me.Controls.Add(Me.lblRaw)
        Me.Controls.Add(Me.lstRaw)
        Me.Controls.Add(Me.lblRawPrepped)
        Me.Controls.Add(Me.lstRawPrepped)
        Me.Controls.Add(Me.btnLowerLeft)
        Me.Controls.Add(Me.btnLowerRight)
        Me.Controls.Add(Me.txtNewPrepped)
        Me.Controls.Add(Me.btnAddPrepped)
        Me.Controls.Add(Me.lblPreppedList)
        Me.Controls.Add(Me.lstPreppedList)
        Me.Controls.Add(Me.lblPrepped)
        Me.Controls.Add(Me.lstPrepped)
        Me.Controls.Add(Me.txtNewDish)
        Me.Controls.Add(Me.lblDishes)
        Me.Controls.Add(Me.lstDishes)
        Me.Controls.Add(Me.btnLeftUpper)
        Me.Controls.Add(Me.btnRightUpper)
        Me.Controls.Add(Me.btnNewDish)
        Me.MaximumSize = New System.Drawing.Size(808, 744)
        Me.MinimumSize = New System.Drawing.Size(808, 744)
        Me.Name = "Form1"
        Me.Text = "Chez SouSad"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents btnNewDish As Button
    Friend WithEvents btnRightUpper As Button
    Friend WithEvents btnLeftUpper As Button
    Friend WithEvents lstDishes As ListBox
    Friend WithEvents lblDishes As Label
    Friend WithEvents txtNewDish As TextBox
    Friend WithEvents lstPrepped As ListBox
    Friend WithEvents lblPrepped As Label
    Friend WithEvents lstPreppedList As ListBox
    Friend WithEvents lblPreppedList As Label
    Friend WithEvents txtNewPrepped As TextBox
    Friend WithEvents btnAddPrepped As Button
    Friend WithEvents txtNewRaw As TextBox
    Friend WithEvents btnNewRaw As Button
    Friend WithEvents lblRaw As Label
    Friend WithEvents lstRaw As ListBox
    Friend WithEvents lblRawPrepped As Label
    Friend WithEvents lstRawPrepped As ListBox
    Friend WithEvents btnLowerLeft As Button
    Friend WithEvents btnLowerRight As Button
End Class
