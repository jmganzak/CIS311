﻿Public Class Form1

    '------------------------------------------------------------
    '-                File Name : Assignment4.frm               - 
    '-                Part of Project: Resturant Food Ordering  -
    '------------------------------------------------------------
    '-                Written By: Justin Ganzak                 -
    '-                Written On: February 10, 2022             -
    '------------------------------------------------------------
    '- File Purpose:                                            -
    '-                                                          -
    '- This file contains the main form for the entire appli-   -
    '- cation.  All user input is gathered on this form.  The   -
    '- calculations which are performed by the application      -
    '- reside in this file as well.  Finally all generated      -
    '- output is contained here too.                            -
    '------------------------------------------------------------
    '- Program Purpose:                                         -
    '-                                                          -
    '- The purpose of this program is to allow users to add food-
    '- to a menu and see their ingrediants and how they are made-
    '------------------------------------------------------------
    '- Global Variable Dictionary (alphabetically):             -
    '- (None)                                                   -
    '------------------------------------------------------------
    '--- GLOBAL CONSTANTS --- GLOBAL CONSTANTS --- GLOBAL CONSTANTS --- GLOBAL CONSTANTS ---
    '--- GLOBAL CONSTANTS --- GLOBAL CONSTANTS --- GLOBAL CONSTANTS --- GLOBAL CONSTANTS ---
    '--- GLOBAL CONSTANTS --- GLOBAL CONSTANTS --- GLOBAL CONSTANTS --- GLOBAL CONSTANTS ---
    '---------------------------------------------------------------------------------------
    '-           (None)
    '-------------------------------------------------------------------------------------------
    '--- GLOBAL STRUCTURES --- GLOBAL STRUCTURES --- GLOBAL STRUCTURES --- GLOBAL STRUCTURES ---
    '--- GLOBAL STRUCTURES --- GLOBAL STRUCTURES --- GLOBAL STRUCTURES --- GLOBAL STRUCTURES ---
    '--- GLOBAL STRUCTURES --- GLOBAL STRUCTURES --- GLOBAL STRUCTURES --- GLOBAL STRUCTURES ---
    '-------------------------------------------------------------------------------------------
    '-          (None)
    '---------------------------------------------------------------------------------------
    '--- GLOBAL VARIABLES --- GLOBAL VARIABLES --- GLOBAL VARIABLES --- GLOBAL VARIABLES ---
    '--- GLOBAL VARIABLES --- GLOBAL VARIABLES --- GLOBAL VARIABLES --- GLOBAL VARIABLES ---
    '--- GLOBAL VARIABLES --- GLOBAL VARIABLES --- GLOBAL VARIABLES --- GLOBAL VARIABLES ---
    '---------------------------------------------------------------------------------------

    Dim dicPrepped As New Dictionary(Of String, Dictionary(Of String, Integer))         'Global dictionary for prepped items
    Dim dicRaw As New Dictionary(Of String, Integer)                                    'Global dictionary for raw ingredients
    Dim dicOrder As New Dictionary(Of String, Dictionary(Of String, Dictionary(Of String, Integer)))        'Global dictionary for full plates

    '--- SUBPROGRAMS --- SUBPROGRAMS --- SUBPROGRAMS --- SUBPROGRAMS --- SUBPROGRAMS ---
    '--- SUBPROGRAMS --- SUBPROGRAMS --- SUBPROGRAMS --- SUBPROGRAMS --- SUBPROGRAMS ---
    '--- SUBPROGRAMS --- SUBPROGRAMS --- SUBPROGRAMS --- SUBPROGRAMS --- SUBPROGRAMS ---
    '-----------------------------------------------------------------------------------

    Sub PrepareItem()

        '------------------------------------------------------------
        '-            Subprogram Name: PrepareItem
        '------------------------------------------------------------
        '-                Written By: Justin Ganzak                 -
        '-                Written On: February 12, 2022             -
        '------------------------------------------------------------
        '- Subprogram Purpose:                                      -
        '-                                                          -
        '- This subroutine handles prepare the basic items on the   -
        '- menu and binds the proper listbox with the dictionaries. -
        '- Also adds basic ingrediants to the items in the meny by  -
        '- default.
        '------------------------------------------------------------
        '- Parameter Dictionary (in parameter order):               -
        '- (None)
        '------------------------------------------------------------
        '- Local Variable Dictionary (alphabetically):              -
        '- dicChickenSalad - dictionary for chicken salad recipe    -
        '- dicFries - dictionary for fries ingredients and recipe   -
        '- dicHamburger - dictionary for recipe/ing for burger      -
        '- dicPop - dictionary for recipe/ing for pop               -
        '------------------------------------------------------------

        Dim dicHamburger As New Dictionary(Of String, Integer)              'Dictionary for hamburger, includes recipe and ingredients
        Dim dicFries As New Dictionary(Of String, Integer)                  'Dictionary for fries, includes recipe and ingredients
        Dim dicChickenSalad As New Dictionary(Of String, Integer)           'Dictionary for Chicky salad, includes recipe and ingredients
        Dim dicPop As New Dictionary(Of String, Integer)                    'Dictionary for Pop, includes recipe and ingredients


        dicPrepped.Add("Hamburger", dicHamburger)
        dicHamburger.Add("Beef patty", 0)
        dicHamburger.Add("Cheese", 0)
        dicHamburger.Add("Bun", 0)                          'Adding basic ingredients and recipe for Hamburger, into hamburger dictionary
        dicHamburger.Add("Ketchup", 0)
        dicHamburger.Add("Mustard", 0)
        dicHamburger.Add("Onions", 0)
        dicHamburger.Add("Pickels", 0)
        dicHamburger.Add("Plate", 0)

        dicPrepped.Add("Fries", dicFries)
        dicFries.Add("Potato", 0)
        dicFries.Add("Oil", 0)                              'Adding basic ingredients and recipe for Fries, into fries dictionary
        dicFries.Add("Salt", 0)
        dicFries.Add("Pepper", 0)

        dicPrepped.Add("Chicken Salad", dicChickenSalad)
        dicChickenSalad.Add("Chicken", 0)
        dicChickenSalad.Add("Tomato", 0)
        dicChickenSalad.Add("Onion", 0)                     'Adding basic ingredients and recipe for Chicky salad, into chicky salad dictionary
        dicChickenSalad.Add("Celery", 0)
        dicChickenSalad.Add("Lemon", 0)
        dicChickenSalad.Add("Mayonnaise", 0)

        dicPrepped.Add("Pop", dicPop)
        dicPop.Add("Water", 0)
        dicPop.Add("Syrup", 0)                              'Adding basic ingredients and recipe for pop, into pop dictionary
        dicPop.Add("Caffeine", 0)
        dicPop.Add("Sugar", 0)



        With lstPreppedList
            .DataSource = New BindingSource(dicPrepped, Nothing)            'Binding lstPreppedList with dicPrepped
            .DisplayMember = "Key"
            .ValueMember = "Value"
        End With


    End Sub

    Sub RawIngredients()

        '------------------------------------------------------------
        '-            Subprogram Name: Raw Ingredients  -
        '------------------------------------------------------------
        '-                Written By: Justin Ganzak                 -
        '-                Written On: February 11, 2022             -
        '------------------------------------------------------------
        '- Subprogram Purpose:                                      -
        '-                                                          -
        '- This subroutine adds the raw ingredients from the basic  -
        '- meals to the raw ingredients dictionary. Binds the raw   -
        '- ingredients with the lstRaw
        '------------------------------------------------------------
        '- Parameter Dictionary (in parameter order):               -
        '- (None)
        '------------------------------------------------------------
        '- Local Variable Dictionary (alphabetically):              -
        '- (None)                                                   -
        '------------------------------------------------------------


        dicRaw.Add("Beef Patty", 0)
        dicRaw.Add("Cheese", 0)
        dicRaw.Add("Bun", 0)
        dicRaw.Add("Ketchup", 0)
        dicRaw.Add("Mustard", 0)
        dicRaw.Add("Onions", 0)
        dicRaw.Add("Pickels", 0)
        dicRaw.Add("Plate", 0)
        dicRaw.Add("Chicken", 0)
        dicRaw.Add("Ranch Dressing", 0)
        dicRaw.Add("Cranberries", 0)
        dicRaw.Add("Onion", 0)
        dicRaw.Add("Baby Greens", 0)
        dicRaw.Add("Black Papper", 0)
        dicRaw.Add("Salad Dressing", 0)
        dicRaw.Add("Celery", 0)
        dicRaw.Add("Bowl", 0)
        dicRaw.Add("Water", 0)
        dicRaw.Add("Syrup", 0)

        With lstRaw
            .DataSource = New BindingSource(dicRaw, Nothing)
            .DisplayMember = "Key"
            .ValueMember = "Value"
        End With

    End Sub

    Sub ItemOrders()

        '------------------------------------------------------------
        '-            Subprogram Name: ItemOrders
        '------------------------------------------------------------
        '-                Written By: Justin Ganzak                 -
        '-                Written On: February 12, 2022             -
        '------------------------------------------------------------
        '- Subprogram Purpose:                                      -
        '-                                                          -
        '- This subroutine handles the meals from the user. It adds -
        '- them to the lstOrder and makes sure they show the proper -
        '- ingreidents and recipe.
        '------------------------------------------------------------
        '- Parameter Dictionary (in parameter order):               -
        '- (None)
        '------------------------------------------------------------
        '- Local Variable Dictionary (alphabetically):              -
        '- dicChickenSalad - dictionary for chicken salad to hold ing-
        '- dicHamburger - Dictionary for hamburger to hold ingred   -
        '------------------------------------------------------------

        Dim dicHamburger As New Dictionary(Of String, Dictionary(Of String, Integer))
        Dim dicChickenSalad As New Dictionary(Of String, Dictionary(Of String, Integer))
        dicHamburger.Add("Hamburger", dicPrepped("Hamburger"))
        dicHamburger.Add("Fries", dicPrepped("Fries"))                                      'Adding proper titles to dictionary of meal. 
        dicHamburger.Add("Pop", dicPrepped("Pop"))
        dicOrder.Add("Hamburger Platter", dicHamburger)                             'Adds the meal to the lstOrder


        dicChickenSalad.Add("Chicken Salad", dicPrepped("Chicken Salad"))
        dicChickenSalad.Add("Pop", dicPrepped("Pop"))                       'Adds meal to lstOrder
        dicOrder.Add("Chicken Salad Platter", dicChickenSalad)

        With lstDishes
            .DataSource = New BindingSource(dicOrder, Nothing)              'Binds lstDishes with dicOrder
            .DisplayMember = "Key"
            .ValueMember = "Value"

        End With


    End Sub



    Private Sub lstPreppedList_SelectedIndexChanged(sender As Object, e As EventArgs) Handles lstPreppedList.SelectedIndexChanged

        '------------------------------------------------------------
        '-            Subprogram Name: Index Change LstPrepList
        '------------------------------------------------------------
        '-                Written By: Justin Ganzak                 -
        '-                Written On: February 12, 2022             -
        '------------------------------------------------------------
        '- Subprogram Purpose:                                      -
        '-                                                          -
        '- This subroutine handles showing the correct food on the  -
        '- correct index within the Prepped List
        '------------------------------------------------------------
        '- Parameter Dictionary (in parameter order):               -
        '- e                                                        -
        '- sender                                                   -
        '------------------------------------------------------------
        '- Local Variable Dictionary (alphabetically):              -
        '- (None)                                                   -
        '------------------------------------------------------------

        lstRawPrepped.Items.Clear()
        For Each entry As String In lstPreppedList.SelectedItem.value.keys                  'Checking check index of the lstBox ur selected on and showing proper items
            lstRawPrepped.Items.Add(entry)
        Next

    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        '------------------------------------------------------------
        '-            Subprogram Name: Load                         -
        '------------------------------------------------------------
        '-                Written By: Justin Ganzak                 -
        '-                Written On: February 11, 2022             -
        '------------------------------------------------------------
        '- Subprogram Purpose:                                      -
        '-                                                          -
        '- This subroutine handles running the subroutines on load  -
        '------------------------------------------------------------
        '- Parameter Dictionary (in parameter order):               -
        '- (None)
        '------------------------------------------------------------
        '- Local Variable Dictionary (alphabetically):              -
        '- (None)                                                   -
        '------------------------------------------------------------

        PrepareItem()
        RawIngredients()
        ItemOrders()
    End Sub

    Private Sub lstDishes_SelectedIndexChanged(sender As Object, e As EventArgs) Handles lstDishes.SelectedIndexChanged

        '------------------------------------------------------------
        '-            Subprogram Name: Index Change lstDish
        '------------------------------------------------------------
        '-                Written By: Justin Ganzak                 -
        '-                Written On: February 11, 2022             -
        '------------------------------------------------------------
        '- Subprogram Purpose:                                      -
        '-                                                          -
        '- This subroutine handles changing between index's on the  -
        '- entree or lstDishes menu. Changing between them changes  -
        '- the food that shows up below.
        '------------------------------------------------------------
        '- Parameter Dictionary (in parameter order):               -
        '- e
        '- sender
        '------------------------------------------------------------
        '- Local Variable Dictionary (alphabetically):              -
        '- (None)                                                   -
        '------------------------------------------------------------

        lstPrepped.Items.Clear()
        For Each entry As String In lstDishes.SelectedItem.value.keys
            lstPrepped.Items.Add(entry)
        Next
    End Sub



    Private Sub btnLeftUpper_Click(sender As Object, e As EventArgs) Handles btnLeftUpper.Click

        '------------------------------------------------------------
        '-            Subprogram Name: Add Prepped Item
        '------------------------------------------------------------
        '-                Written By: Justin Ganzak                 -
        '-                Written On: February 11, 2022             -
        '------------------------------------------------------------
        '- Subprogram Purpose:                                      -
        '-                                                          -
        '- This subroutine handles moving the data from prepped items
        '- being added to the items in the list under the main menu. 
        '- If the item is already in there it wont add it. 
        '------------------------------------------------------------
        '- Parameter Dictionary (in parameter order):               -
        '- e
        '- sender
        '------------------------------------------------------------
        '- Local Variable Dictionary (alphabetically):              -
        '- (None)                                                   -
        '------------------------------------------------------------

        For Each item In lstPreppedList.SelectedItems
            If (dicPrepped(item.Key).Count > 0) Then
                If dicOrder(lstDishes.SelectedItem.Key).ContainsKey(item.Key) = False Then
                    lstPrepped.Items.Add(item.Key)
                    dicOrder(lstDishes.SelectedItem.Key).Add(item.Key, dicPrepped(item.Key))
                End If
            Else
                MessageBox.Show("Please pick an ingredient")
            End If
        Next
    End Sub

    Private Sub btnRightUpper_Click(sender As Object, e As EventArgs) Handles btnRightUpper.Click

        '------------------------------------------------------------
        '-            Subprogram Name: Remove Prepped Item          -
        '------------------------------------------------------------
        '-                Written By: Justin Ganzak                 -
        '-                Written On: February 12, 2022             -
        '------------------------------------------------------------
        '- Subprogram Purpose:                                      -
        '-                                                          -
        '- This subroutine handles moving the data from prepped items
        '- being removed from items in the list under the main menu. 
        '------------------------------------------------------------
        '- Parameter Dictionary (in parameter order):               -
        '- e
        '- sender
        '------------------------------------------------------------
        '- Local Variable Dictionary (alphabetically):              -
        '- (None)                                                   -
        '------------------------------------------------------------

        If lstPrepped.SelectedItems.Count > 0 Then
            Dim lstFood As New List(Of String)
            For Each item In lstPrepped.SelectedItems
                If dicOrder(lstDishes.SelectedItem.Key).ContainsKey(item) = True Then
                    lstFood.Add(item)
                    dicOrder(lstDishes.SelectedItem.Key).Remove(item, dicPrepped(item))
                End If
            Next
            For Each item In lstFood
                lstPrepped.Items.Remove(item)
            Next
        End If
    End Sub

    Private Sub btnLowerLeft_Click(sender As Object, e As EventArgs) Handles btnLowerLeft.Click

        '------------------------------------------------------------
        '-            Subprogram Name: Add Raw Item                 -
        '------------------------------------------------------------
        '-                Written By: Justin Ganzak                 -
        '-                Written On: February 12, 2022             -
        '------------------------------------------------------------
        '- Subprogram Purpose:                                      -
        '- This subroutine handles moving the data from raw items
        '- being added to the items in the list under the main menu. 
        '- If the item is already in there it wont add it.                                                          -
        '- 
        '------------------------------------------------------------
        '- Parameter Dictionary (in parameter order):               -
        '- e
        '- sender
        '------------------------------------------------------------
        '- Local Variable Dictionary (alphabetically):              -
        '- (None)                                                   -
        '------------------------------------------------------------

        For Each item In lstRaw.SelectedItems
            If dicPrepped(lstPreppedList.SelectedItem.Key).ContainsKey(item.Key) = False Then
                lstRawPrepped.Items.Add(item.Key)
                dicPrepped(lstPreppedList.SelectedItem.Key).Add(item.Key, 0)
            End If
        Next
    End Sub

    Private Sub btnLowerRight_Click(sender As Object, e As EventArgs) Handles btnLowerRight.Click

        '------------------------------------------------------------
        '-            Subprogram Name: Remove Raw Item              -
        '------------------------------------------------------------
        '-                Written By: Justin Ganzak                 -
        '-                Written On: February 12, 2022             -
        '------------------------------------------------------------
        '- Subprogram Purpose:                                      -
        '-  This subroutine handles moving the data from raw items
        '- being removed from items in the list under the main menu.                                            
        '- 
        '------------------------------------------------------------
        '- Parameter Dictionary (in parameter order):               -
        '- e
        '- sender
        '------------------------------------------------------------
        '- Local Variable Dictionary (alphabetically):              -
        '- lstIng - holds list of ingredients to be removed                                        
        '------------------------------------------------------------

        If lstRawPrepped.SelectedItems.Count > 0 Then
            Dim lstIng As New List(Of String)
            For Each item In lstRawPrepped.SelectedItems

                If dicPrepped(lstPreppedList.SelectedItem.Key).ContainsKey(item) = True Then
                    lstIng.Add(item)
                    dicPrepped(lstPreppedList.SelectedItem.Key).Remove(item)
                End If

            Next
            For Each item In lstIng
                lstRawPrepped.Items.Remove(item)
            Next
        End If
    End Sub
    Private Sub btnNewDish_Click(sender As Object, e As EventArgs) Handles btnNewDish.Click

        '------------------------------------------------------------
        '-            Subprogram Name: New dish button              -
        '------------------------------------------------------------
        '-                Written By: Justin Ganzak                 -
        '-                Written On: February 12, 2022             -
        '------------------------------------------------------------
        '- Subprogram Purpose:                                      -
        '-                                                          -
        '- This subroutine handles adding new dishes to the lstDish -
        '- and makes sure they are not already added or blank
        '------------------------------------------------------------
        '- Parameter Dictionary (in parameter order):               -
        '- e
        '- sender
        '------------------------------------------------------------
        '- Local Variable Dictionary (alphabetically):              -
        '- dicNewDish - Holds the new dish being added to lstDishes -
        '------------------------------------------------------------

        Dim dicNewDish As New Dictionary(Of String, Dictionary(Of String, Integer))

        If (Not dicOrder.ContainsKey(txtNewDish.Text)) And (Not txtNewDish.Text = ("")) Then
            dicOrder.Add(txtNewDish.Text, dicNewDish)

            lstDishes.DataSource = New BindingSource(dicOrder, Nothing)
            lstDishes.DisplayMember = "Key"
            lstDishes.ValueMember = "Value"

            'MessageBox.Show("Sucessfully Added " & txtNewDish.Text)
            txtNewDish.Clear()
        Else
            txtNewDish.Clear()
            MessageBox.Show("Please enter a valid dish name.")
        End If

    End Sub

    Private Sub btnNewRaw_Click(sender As Object, e As EventArgs) Handles btnNewRaw.Click

        '------------------------------------------------------------
        '-            Subprogram Name: New Raw Ingredients          -
        '------------------------------------------------------------
        '-                Written By: Justin Ganzak                -
        '-                Written On: February 11, 2022             -
        '------------------------------------------------------------
        '- Subprogram Purpose:                                      -
        '-                                                          -
        '- This subroutine ehandles adding new raw ingredients.     -
        '- it makes sure the input isnt blank or already existing
        '------------------------------------------------------------
        '- Parameter Dictionary (in parameter order):               -
        '- e
        '- sender
        '------------------------------------------------------------
        '- Local Variable Dictionary (alphabetically):              -
        '- (None)                                                   -
        '------------------------------------------------------------

        If (Not dicRaw.ContainsKey(txtNewRaw.Text)) And (Not txtNewRaw.Text = ("")) Then
            dicRaw.Add(txtNewRaw.Text, 0)
            lstRaw.DataSource = New BindingSource(dicRaw, Nothing)
            lstRaw.DisplayMember = "Key"
            lstRaw.ValueMember = "Value"

            'MessageBox.Show("Sucessfully Added " & txtNewRaw.Text)
            txtNewRaw.Clear()
        Else
            txtNewRaw.Clear()
            MessageBox.Show("Please enter a valid ingredient name.")
        End If
    End Sub

    Private Sub btnAddPrepped_Click(sender As Object, e As EventArgs) Handles btnAddPrepped.Click

        '------------------------------------------------------------
        '-            Subprogram Name: Add new prepped item         -
        '------------------------------------------------------------
        '-                Written By: Justin Ganzak                 -
        '-                Written On: February 11, 2022             -
        '------------------------------------------------------------
        '- Subprogram Purpose:                                      -
        '-                                                          -
        '- This subroutine handles adding prepped items to the new  -
        '- dictionary and ensure they are not already existing or that
        '- the entry is blank
        '------------------------------------------------------------
        '- Parameter Dictionary (in parameter order):               -
        '- e
        '- sender
        '------------------------------------------------------------
        '- Local Variable Dictionary (alphabetically):              -
        '- dicNewPrepItem - Holds new prep items being added        -
        '------------------------------------------------------------

        Dim dicNewPrepItem As New Dictionary(Of String, Integer)

        If (Not dicPrepped.ContainsKey(txtNewPrepped.Text)) And (Not txtNewPrepped.Text = ("")) Then
            dicPrepped.Add(txtNewPrepped.Text, dicNewPrepItem)

            lstPreppedList.DataSource = New BindingSource(dicPrepped, Nothing)
            lstPreppedList.DisplayMember = "Key"
            lstPreppedList.ValueMember = "Value"

            'MessageBox.Show("Sucessfully Added " & txtNewPrepped.Text)
            txtNewPrepped.Clear()
        Else
            txtNewPrepped.Clear()
            MessageBox.Show("Please enter a valid item name.")
        End If
    End Sub
End Class
