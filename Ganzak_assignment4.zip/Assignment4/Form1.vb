﻿Public Class Form1

    Dim dicPrepped As New Dictionary(Of String, Dictionary(Of String, Integer))
    Dim dicRaw As New Dictionary(Of String, Integer)
    Dim dicOrder As New Dictionary(Of String, Dictionary(Of String, Dictionary(Of String, Integer)))


    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        PrepareItem()
        RawIngredients()
        ItemOrders()
    End Sub


    Sub PrepareItem()
        Dim dicHamburger As New Dictionary(Of String, Integer)
        dicPrepped.Add("Hamburger", dicHamburger)
        dicHamburger.Add("beef patty", 0)
        dicHamburger.Add("Bun", 0)
        dicHamburger.Add("Ketchup", 0)
        dicHamburger.Add("Mustard", 0)
        dicHamburger.Add("Onions", 0)
        dicHamburger.Add("Pickels", 0)
        dicHamburger.Add("Plate", 0)

        With lstPreppedList
            .DataSource = New BindingSource(dicPrepped, Nothing)
            .DisplayMember = "Key"
            .ValueMember = "Value"
        End With


    End Sub

    Sub RawIngredients()
        Dim dicRaw As New Dictionary(Of String, Integer)
        dicRaw.Add("beef patty", 0)
        dicRaw.Add("Bun", 0)
        dicRaw.Add("Ketchup", 0)
        dicRaw.Add("Mustard", 0)
        dicRaw.Add("Onions", 0)
        dicRaw.Add("Pickels", 0)
        dicRaw.Add("Plate", 0)
        dicRaw.Add("Chicken", 0)
        dicRaw.Add("Ranch Dressing", 0)
        dicRaw.Add("Cranberries", 0)
        dicRaw.Add("Onion", 0)
        dicRaw.Add("Baby Greens", 0)
        dicRaw.Add("Black Papper", 0)
        dicRaw.Add("Salad Dressing", 0)
        dicRaw.Add("Celery", 0)
        dicRaw.Add("Bowl", 0)

        With lstRawList
            .DataSource = New BindingSource(dicRaw, Nothing)
            .DisplayMember = "Key"
            .ValueMember = "Value"
        End With

    End Sub

    Sub ItemOrders()

    End Sub


    Private Sub lstPreppedList_SelectedIndexChanged(sender As Object, e As EventArgs) Handles lstPreppedList.SelectedIndexChanged
        Dim dicRawIng As New Dictionary(Of String, Integer)
        dicRawIng = lstPreppedList.SelectedItem.Value
        lstIngredients.Items.Clear()
        For Each Entry As KeyValuePair(Of String, Integer) In dicRawIng
            lstIngredients.Items.Add(Entry.Key.ToString())
        Next

    End Sub

End Class
