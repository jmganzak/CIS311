﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmChild
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.lblBinary1 = New System.Windows.Forms.Label()
        Me.lblDecimal = New System.Windows.Forms.Label()
        Me.lblHex = New System.Windows.Forms.Label()
        Me.lblBinary2 = New System.Windows.Forms.Label()
        Me.lblDecimal2 = New System.Windows.Forms.Label()
        Me.lblHex2 = New System.Windows.Forms.Label()
        Me.lblBinary3 = New System.Windows.Forms.Label()
        Me.lblDecimal3 = New System.Windows.Forms.Label()
        Me.lblHex3 = New System.Windows.Forms.Label()
        Me.lblValue1 = New System.Windows.Forms.Label()
        Me.lblValue2 = New System.Windows.Forms.Label()
        Me.lblResult = New System.Windows.Forms.Label()
        Me.txtBinary = New System.Windows.Forms.TextBox()
        Me.txtDecimal2 = New System.Windows.Forms.TextBox()
        Me.txtBinary2 = New System.Windows.Forms.TextBox()
        Me.txtHex2 = New System.Windows.Forms.TextBox()
        Me.txtHex = New System.Windows.Forms.TextBox()
        Me.txtDecimal = New System.Windows.Forms.TextBox()
        Me.txtHex3 = New System.Windows.Forms.TextBox()
        Me.txtDecimal3 = New System.Windows.Forms.TextBox()
        Me.txtBinary3 = New System.Windows.Forms.TextBox()
        Me.btnA = New System.Windows.Forms.Button()
        Me.btnB = New System.Windows.Forms.Button()
        Me.btnC = New System.Windows.Forms.Button()
        Me.btnD = New System.Windows.Forms.Button()
        Me.btnE = New System.Windows.Forms.Button()
        Me.btnF = New System.Windows.Forms.Button()
        Me.btn6 = New System.Windows.Forms.Button()
        Me.btn7 = New System.Windows.Forms.Button()
        Me.btn8 = New System.Windows.Forms.Button()
        Me.btn9 = New System.Windows.Forms.Button()
        Me.btn2 = New System.Windows.Forms.Button()
        Me.btn3 = New System.Windows.Forms.Button()
        Me.btn4 = New System.Windows.Forms.Button()
        Me.btn5 = New System.Windows.Forms.Button()
        Me.btn0 = New System.Windows.Forms.Button()
        Me.btn1 = New System.Windows.Forms.Button()
        Me.btnConvert = New System.Windows.Forms.Button()
        Me.btnClearValue1 = New System.Windows.Forms.Button()
        Me.btnClearValue2 = New System.Windows.Forms.Button()
        Me.btnClearResult = New System.Windows.Forms.Button()
        Me.btnAnd = New System.Windows.Forms.Button()
        Me.btnOr = New System.Windows.Forms.Button()
        Me.btnXor = New System.Windows.Forms.Button()
        Me.btnNotValue1 = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'lblBinary1
        '
        Me.lblBinary1.AutoSize = True
        Me.lblBinary1.Location = New System.Drawing.Point(15, 17)
        Me.lblBinary1.Name = "lblBinary1"
        Me.lblBinary1.Size = New System.Drawing.Size(53, 20)
        Me.lblBinary1.TabIndex = 0
        Me.lblBinary1.Text = "Binary:"
        '
        'lblDecimal
        '
        Me.lblDecimal.AutoSize = True
        Me.lblDecimal.Location = New System.Drawing.Point(15, 109)
        Me.lblDecimal.Name = "lblDecimal"
        Me.lblDecimal.Size = New System.Drawing.Size(67, 20)
        Me.lblDecimal.TabIndex = 1
        Me.lblDecimal.Text = "Decimal:"
        '
        'lblHex
        '
        Me.lblHex.AutoSize = True
        Me.lblHex.Location = New System.Drawing.Point(14, 196)
        Me.lblHex.Name = "lblHex"
        Me.lblHex.Size = New System.Drawing.Size(38, 20)
        Me.lblHex.TabIndex = 2
        Me.lblHex.Text = "Hex:"
        '
        'lblBinary2
        '
        Me.lblBinary2.AutoSize = True
        Me.lblBinary2.Location = New System.Drawing.Point(331, 19)
        Me.lblBinary2.Name = "lblBinary2"
        Me.lblBinary2.Size = New System.Drawing.Size(53, 20)
        Me.lblBinary2.TabIndex = 3
        Me.lblBinary2.Text = "Binary:"
        '
        'lblDecimal2
        '
        Me.lblDecimal2.AutoSize = True
        Me.lblDecimal2.Location = New System.Drawing.Point(331, 109)
        Me.lblDecimal2.Name = "lblDecimal2"
        Me.lblDecimal2.Size = New System.Drawing.Size(67, 20)
        Me.lblDecimal2.TabIndex = 4
        Me.lblDecimal2.Text = "Decimal:"
        '
        'lblHex2
        '
        Me.lblHex2.AutoSize = True
        Me.lblHex2.Location = New System.Drawing.Point(331, 196)
        Me.lblHex2.Name = "lblHex2"
        Me.lblHex2.Size = New System.Drawing.Size(38, 20)
        Me.lblHex2.TabIndex = 5
        Me.lblHex2.Text = "Hex:"
        '
        'lblBinary3
        '
        Me.lblBinary3.AutoSize = True
        Me.lblBinary3.Location = New System.Drawing.Point(655, 17)
        Me.lblBinary3.Name = "lblBinary3"
        Me.lblBinary3.Size = New System.Drawing.Size(53, 20)
        Me.lblBinary3.TabIndex = 6
        Me.lblBinary3.Text = "Binary:"
        '
        'lblDecimal3
        '
        Me.lblDecimal3.AutoSize = True
        Me.lblDecimal3.Location = New System.Drawing.Point(655, 109)
        Me.lblDecimal3.Name = "lblDecimal3"
        Me.lblDecimal3.Size = New System.Drawing.Size(67, 20)
        Me.lblDecimal3.TabIndex = 7
        Me.lblDecimal3.Text = "Decimal:"
        '
        'lblHex3
        '
        Me.lblHex3.AutoSize = True
        Me.lblHex3.Location = New System.Drawing.Point(655, 196)
        Me.lblHex3.Name = "lblHex3"
        Me.lblHex3.Size = New System.Drawing.Size(38, 20)
        Me.lblHex3.TabIndex = 8
        Me.lblHex3.Text = "Hex:"
        '
        'lblValue1
        '
        Me.lblValue1.AutoSize = True
        Me.lblValue1.Location = New System.Drawing.Point(97, 292)
        Me.lblValue1.Name = "lblValue1"
        Me.lblValue1.Size = New System.Drawing.Size(57, 20)
        Me.lblValue1.TabIndex = 9
        Me.lblValue1.Text = "Value 1"
        '
        'lblValue2
        '
        Me.lblValue2.AutoSize = True
        Me.lblValue2.Location = New System.Drawing.Point(445, 292)
        Me.lblValue2.Name = "lblValue2"
        Me.lblValue2.Size = New System.Drawing.Size(57, 20)
        Me.lblValue2.TabIndex = 10
        Me.lblValue2.Text = "Value 2"
        '
        'lblResult
        '
        Me.lblResult.AutoSize = True
        Me.lblResult.Location = New System.Drawing.Point(717, 292)
        Me.lblResult.Name = "lblResult"
        Me.lblResult.Size = New System.Drawing.Size(49, 20)
        Me.lblResult.TabIndex = 11
        Me.lblResult.Text = "Result"
        '
        'txtBinary
        '
        Me.txtBinary.Location = New System.Drawing.Point(15, 43)
        Me.txtBinary.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtBinary.Name = "txtBinary"
        Me.txtBinary.Size = New System.Drawing.Size(294, 27)
        Me.txtBinary.TabIndex = 1
        Me.txtBinary.Text = "0"
        '
        'txtDecimal2
        '
        Me.txtDecimal2.Location = New System.Drawing.Point(331, 133)
        Me.txtDecimal2.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtDecimal2.Name = "txtDecimal2"
        Me.txtDecimal2.Size = New System.Drawing.Size(286, 27)
        Me.txtDecimal2.TabIndex = 5
        Me.txtDecimal2.Text = "0"
        '
        'txtBinary2
        '
        Me.txtBinary2.Location = New System.Drawing.Point(333, 43)
        Me.txtBinary2.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtBinary2.Name = "txtBinary2"
        Me.txtBinary2.Size = New System.Drawing.Size(284, 27)
        Me.txtBinary2.TabIndex = 4
        Me.txtBinary2.Text = "0"
        '
        'txtHex2
        '
        Me.txtHex2.Location = New System.Drawing.Point(331, 220)
        Me.txtHex2.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtHex2.Name = "txtHex2"
        Me.txtHex2.Size = New System.Drawing.Size(286, 27)
        Me.txtHex2.TabIndex = 6
        Me.txtHex2.Text = "0"
        '
        'txtHex
        '
        Me.txtHex.Location = New System.Drawing.Point(15, 220)
        Me.txtHex.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtHex.Name = "txtHex"
        Me.txtHex.Size = New System.Drawing.Size(294, 27)
        Me.txtHex.TabIndex = 3
        Me.txtHex.Text = "0"
        '
        'txtDecimal
        '
        Me.txtDecimal.Location = New System.Drawing.Point(15, 133)
        Me.txtDecimal.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtDecimal.Name = "txtDecimal"
        Me.txtDecimal.Size = New System.Drawing.Size(294, 27)
        Me.txtDecimal.TabIndex = 2
        Me.txtDecimal.Text = "0"
        '
        'txtHex3
        '
        Me.txtHex3.Location = New System.Drawing.Point(655, 220)
        Me.txtHex3.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtHex3.Name = "txtHex3"
        Me.txtHex3.ReadOnly = True
        Me.txtHex3.Size = New System.Drawing.Size(245, 27)
        Me.txtHex3.TabIndex = 19
        Me.txtHex3.TabStop = False
        Me.txtHex3.Text = "0"
        '
        'txtDecimal3
        '
        Me.txtDecimal3.Location = New System.Drawing.Point(655, 133)
        Me.txtDecimal3.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtDecimal3.Name = "txtDecimal3"
        Me.txtDecimal3.ReadOnly = True
        Me.txtDecimal3.Size = New System.Drawing.Size(245, 27)
        Me.txtDecimal3.TabIndex = 20
        Me.txtDecimal3.TabStop = False
        Me.txtDecimal3.Text = "0"
        '
        'txtBinary3
        '
        Me.txtBinary3.Location = New System.Drawing.Point(655, 43)
        Me.txtBinary3.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtBinary3.Name = "txtBinary3"
        Me.txtBinary3.ReadOnly = True
        Me.txtBinary3.Size = New System.Drawing.Size(245, 27)
        Me.txtBinary3.TabIndex = 21
        Me.txtBinary3.TabStop = False
        Me.txtBinary3.Text = "0"
        '
        'btnA
        '
        Me.btnA.Location = New System.Drawing.Point(50, 331)
        Me.btnA.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.btnA.Name = "btnA"
        Me.btnA.Size = New System.Drawing.Size(53, 47)
        Me.btnA.TabIndex = 7
        Me.btnA.Text = "A"
        Me.btnA.UseVisualStyleBackColor = True
        '
        'btnB
        '
        Me.btnB.Location = New System.Drawing.Point(110, 331)
        Me.btnB.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.btnB.Name = "btnB"
        Me.btnB.Size = New System.Drawing.Size(53, 47)
        Me.btnB.TabIndex = 8
        Me.btnB.Text = "B"
        Me.btnB.UseVisualStyleBackColor = True
        '
        'btnC
        '
        Me.btnC.Location = New System.Drawing.Point(169, 331)
        Me.btnC.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.btnC.Name = "btnC"
        Me.btnC.Size = New System.Drawing.Size(53, 47)
        Me.btnC.TabIndex = 9
        Me.btnC.Text = "C"
        Me.btnC.UseVisualStyleBackColor = True
        '
        'btnD
        '
        Me.btnD.Location = New System.Drawing.Point(229, 331)
        Me.btnD.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.btnD.Name = "btnD"
        Me.btnD.Size = New System.Drawing.Size(53, 47)
        Me.btnD.TabIndex = 10
        Me.btnD.Text = "D"
        Me.btnD.UseVisualStyleBackColor = True
        '
        'btnE
        '
        Me.btnE.Location = New System.Drawing.Point(288, 331)
        Me.btnE.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.btnE.Name = "btnE"
        Me.btnE.Size = New System.Drawing.Size(53, 47)
        Me.btnE.TabIndex = 11
        Me.btnE.Text = "E"
        Me.btnE.UseVisualStyleBackColor = True
        '
        'btnF
        '
        Me.btnF.Location = New System.Drawing.Point(347, 331)
        Me.btnF.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.btnF.Name = "btnF"
        Me.btnF.Size = New System.Drawing.Size(53, 47)
        Me.btnF.TabIndex = 12
        Me.btnF.Text = "F"
        Me.btnF.UseVisualStyleBackColor = True
        '
        'btn6
        '
        Me.btn6.Location = New System.Drawing.Point(50, 385)
        Me.btn6.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.btn6.Name = "btn6"
        Me.btn6.Size = New System.Drawing.Size(53, 47)
        Me.btn6.TabIndex = 13
        Me.btn6.Text = "6"
        Me.btn6.UseVisualStyleBackColor = True
        '
        'btn7
        '
        Me.btn7.Location = New System.Drawing.Point(110, 385)
        Me.btn7.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.btn7.Name = "btn7"
        Me.btn7.Size = New System.Drawing.Size(53, 47)
        Me.btn7.TabIndex = 14
        Me.btn7.Text = "7"
        Me.btn7.UseVisualStyleBackColor = True
        '
        'btn8
        '
        Me.btn8.Location = New System.Drawing.Point(169, 385)
        Me.btn8.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.btn8.Name = "btn8"
        Me.btn8.Size = New System.Drawing.Size(53, 47)
        Me.btn8.TabIndex = 15
        Me.btn8.Text = "8"
        Me.btn8.UseVisualStyleBackColor = True
        '
        'btn9
        '
        Me.btn9.Location = New System.Drawing.Point(229, 384)
        Me.btn9.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.btn9.Name = "btn9"
        Me.btn9.Size = New System.Drawing.Size(53, 47)
        Me.btn9.TabIndex = 16
        Me.btn9.Text = "9"
        Me.btn9.UseVisualStyleBackColor = True
        '
        'btn2
        '
        Me.btn2.Location = New System.Drawing.Point(50, 440)
        Me.btn2.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.btn2.Name = "btn2"
        Me.btn2.Size = New System.Drawing.Size(53, 47)
        Me.btn2.TabIndex = 17
        Me.btn2.Text = "2"
        Me.btn2.UseVisualStyleBackColor = True
        '
        'btn3
        '
        Me.btn3.Location = New System.Drawing.Point(110, 440)
        Me.btn3.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.btn3.Name = "btn3"
        Me.btn3.Size = New System.Drawing.Size(53, 47)
        Me.btn3.TabIndex = 18
        Me.btn3.Text = "3"
        Me.btn3.UseVisualStyleBackColor = True
        '
        'btn4
        '
        Me.btn4.Location = New System.Drawing.Point(169, 440)
        Me.btn4.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.btn4.Name = "btn4"
        Me.btn4.Size = New System.Drawing.Size(53, 47)
        Me.btn4.TabIndex = 19
        Me.btn4.Text = "4"
        Me.btn4.UseVisualStyleBackColor = True
        '
        'btn5
        '
        Me.btn5.Location = New System.Drawing.Point(229, 440)
        Me.btn5.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.btn5.Name = "btn5"
        Me.btn5.Size = New System.Drawing.Size(53, 47)
        Me.btn5.TabIndex = 20
        Me.btn5.Text = "5"
        Me.btn5.UseVisualStyleBackColor = True
        '
        'btn0
        '
        Me.btn0.Location = New System.Drawing.Point(50, 495)
        Me.btn0.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.btn0.Name = "btn0"
        Me.btn0.Size = New System.Drawing.Size(53, 47)
        Me.btn0.TabIndex = 21
        Me.btn0.Text = "0"
        Me.btn0.UseVisualStyleBackColor = True
        '
        'btn1
        '
        Me.btn1.Location = New System.Drawing.Point(110, 495)
        Me.btn1.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.btn1.Name = "btn1"
        Me.btn1.Size = New System.Drawing.Size(53, 47)
        Me.btn1.TabIndex = 22
        Me.btn1.Text = "1"
        Me.btn1.UseVisualStyleBackColor = True
        '
        'btnConvert
        '
        Me.btnConvert.Location = New System.Drawing.Point(289, 384)
        Me.btnConvert.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.btnConvert.Name = "btnConvert"
        Me.btnConvert.Size = New System.Drawing.Size(111, 157)
        Me.btnConvert.TabIndex = 23
        Me.btnConvert.Text = "Convert"
        Me.btnConvert.UseVisualStyleBackColor = True
        '
        'btnClearValue1
        '
        Me.btnClearValue1.Location = New System.Drawing.Point(445, 331)
        Me.btnClearValue1.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.btnClearValue1.Name = "btnClearValue1"
        Me.btnClearValue1.Size = New System.Drawing.Size(133, 47)
        Me.btnClearValue1.TabIndex = 24
        Me.btnClearValue1.Text = "Clear Value 1"
        Me.btnClearValue1.UseVisualStyleBackColor = True
        '
        'btnClearValue2
        '
        Me.btnClearValue2.Location = New System.Drawing.Point(445, 385)
        Me.btnClearValue2.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.btnClearValue2.Name = "btnClearValue2"
        Me.btnClearValue2.Size = New System.Drawing.Size(133, 47)
        Me.btnClearValue2.TabIndex = 25
        Me.btnClearValue2.Text = "Clear Value 2"
        Me.btnClearValue2.UseVisualStyleBackColor = True
        '
        'btnClearResult
        '
        Me.btnClearResult.Location = New System.Drawing.Point(445, 440)
        Me.btnClearResult.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.btnClearResult.Name = "btnClearResult"
        Me.btnClearResult.Size = New System.Drawing.Size(133, 47)
        Me.btnClearResult.TabIndex = 26
        Me.btnClearResult.Text = "Clear Result"
        Me.btnClearResult.UseVisualStyleBackColor = True
        '
        'btnAnd
        '
        Me.btnAnd.Location = New System.Drawing.Point(673, 333)
        Me.btnAnd.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.btnAnd.Name = "btnAnd"
        Me.btnAnd.Size = New System.Drawing.Size(121, 44)
        Me.btnAnd.TabIndex = 27
        Me.btnAnd.Text = "And"
        Me.btnAnd.UseVisualStyleBackColor = True
        '
        'btnOr
        '
        Me.btnOr.Location = New System.Drawing.Point(673, 385)
        Me.btnOr.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.btnOr.Name = "btnOr"
        Me.btnOr.Size = New System.Drawing.Size(121, 47)
        Me.btnOr.TabIndex = 28
        Me.btnOr.Text = "Or"
        Me.btnOr.UseVisualStyleBackColor = True
        '
        'btnXor
        '
        Me.btnXor.Location = New System.Drawing.Point(673, 440)
        Me.btnXor.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.btnXor.Name = "btnXor"
        Me.btnXor.Size = New System.Drawing.Size(121, 45)
        Me.btnXor.TabIndex = 29
        Me.btnXor.Text = "Xor"
        Me.btnXor.UseVisualStyleBackColor = True
        '
        'btnNotValue1
        '
        Me.btnNotValue1.Location = New System.Drawing.Point(673, 493)
        Me.btnNotValue1.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.btnNotValue1.Name = "btnNotValue1"
        Me.btnNotValue1.Size = New System.Drawing.Size(121, 45)
        Me.btnNotValue1.TabIndex = 30
        Me.btnNotValue1.Text = "Not Value 1"
        Me.btnNotValue1.UseVisualStyleBackColor = True
        '
        'frmChild
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(914, 600)
        Me.Controls.Add(Me.btnNotValue1)
        Me.Controls.Add(Me.btnXor)
        Me.Controls.Add(Me.btnOr)
        Me.Controls.Add(Me.btnAnd)
        Me.Controls.Add(Me.btnClearResult)
        Me.Controls.Add(Me.btnClearValue2)
        Me.Controls.Add(Me.btnClearValue1)
        Me.Controls.Add(Me.btnConvert)
        Me.Controls.Add(Me.btn1)
        Me.Controls.Add(Me.btn0)
        Me.Controls.Add(Me.btn5)
        Me.Controls.Add(Me.btn4)
        Me.Controls.Add(Me.btn3)
        Me.Controls.Add(Me.btn2)
        Me.Controls.Add(Me.btn9)
        Me.Controls.Add(Me.btn8)
        Me.Controls.Add(Me.btn7)
        Me.Controls.Add(Me.btn6)
        Me.Controls.Add(Me.btnF)
        Me.Controls.Add(Me.btnE)
        Me.Controls.Add(Me.btnD)
        Me.Controls.Add(Me.btnC)
        Me.Controls.Add(Me.btnB)
        Me.Controls.Add(Me.btnA)
        Me.Controls.Add(Me.txtBinary3)
        Me.Controls.Add(Me.txtDecimal3)
        Me.Controls.Add(Me.txtHex3)
        Me.Controls.Add(Me.txtDecimal)
        Me.Controls.Add(Me.txtHex)
        Me.Controls.Add(Me.txtHex2)
        Me.Controls.Add(Me.txtBinary2)
        Me.Controls.Add(Me.txtDecimal2)
        Me.Controls.Add(Me.txtBinary)
        Me.Controls.Add(Me.lblResult)
        Me.Controls.Add(Me.lblValue2)
        Me.Controls.Add(Me.lblValue1)
        Me.Controls.Add(Me.lblHex3)
        Me.Controls.Add(Me.lblDecimal3)
        Me.Controls.Add(Me.lblBinary3)
        Me.Controls.Add(Me.lblHex2)
        Me.Controls.Add(Me.lblDecimal2)
        Me.Controls.Add(Me.lblBinary2)
        Me.Controls.Add(Me.lblHex)
        Me.Controls.Add(Me.lblDecimal)
        Me.Controls.Add(Me.lblBinary1)
        Me.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.Name = "frmChild"
        Me.Text = "frmChild"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lblBinary1 As Label
    Friend WithEvents lblDecimal As Label
    Friend WithEvents lblHex As Label
    Friend WithEvents lblBinary2 As Label
    Friend WithEvents lblDecimal2 As Label
    Friend WithEvents lblHex2 As Label
    Friend WithEvents lblBinary3 As Label
    Friend WithEvents lblDecimal3 As Label
    Friend WithEvents lblHex3 As Label
    Friend WithEvents lblValue1 As Label
    Friend WithEvents lblValue2 As Label
    Friend WithEvents lblResult As Label
    Friend WithEvents txtBinary As TextBox
    Friend WithEvents txtDecimal2 As TextBox
    Friend WithEvents txtBinary2 As TextBox
    Friend WithEvents txtHex2 As TextBox
    Friend WithEvents txtHex As TextBox
    Friend WithEvents txtDecimal As TextBox
    Friend WithEvents txtHex3 As TextBox
    Friend WithEvents txtDecimal3 As TextBox
    Friend WithEvents txtBinary3 As TextBox
    Friend WithEvents btnA As Button
    Friend WithEvents btnB As Button
    Friend WithEvents btnC As Button
    Friend WithEvents btnD As Button
    Friend WithEvents btnE As Button
    Friend WithEvents btnF As Button
    Friend WithEvents btn6 As Button
    Friend WithEvents btn7 As Button
    Friend WithEvents btn8 As Button
    Friend WithEvents btn9 As Button
    Friend WithEvents btn2 As Button
    Friend WithEvents btn3 As Button
    Friend WithEvents btn4 As Button
    Friend WithEvents btn5 As Button
    Friend WithEvents btn0 As Button
    Friend WithEvents btn1 As Button
    Friend WithEvents btnConvert As Button
    Friend WithEvents btnClearValue1 As Button
    Friend WithEvents btnClearValue2 As Button
    Friend WithEvents btnClearResult As Button
    Friend WithEvents btnAnd As Button
    Friend WithEvents btnOr As Button
    Friend WithEvents btnXor As Button
    Friend WithEvents btnNotValue1 As Button
End Class
