﻿Imports System.ComponentModel

Public Class frmChild

    '------------------------------------------------------------
    '-                File Name : frmChild.frm                  - 
    '-                Part of Project: Child Forms of Calc      -
    '------------------------------------------------------------
    '-                Written By: Justin Ganzak                 -
    '-                Written On: March 19, 2022                -
    '------------------------------------------------------------
    '- File Purpose:                                            -
    '-                                                          -
    '- This file contains the child forms of the calculator.    -
    '- These handle all the calculations and have all the buttons-
    '- and is where the user is going to be mainly using the    -
    '- application
    '------------------------------------------------------------
    '- Program Purpose:                                         -
    '-                                                          -
    '- The purpose of this program is to act as a binary conversion-
    '- calculator for the user to convert numbers over on a click-
    '------------------------------------------------------------
    '- Global Variable Dictionary (alphabetically):             -
    '- blnBinarySelected - Checks if user is on Value 1 Binary  -
    '- blnBinary2Selected - Checks if user is on Value 2 Binary -
    '- blnDecimalSelected - Checks if user is on Value 1 Decimal-
    '- blnDecimal2Selected - Checks if user is on Value 2 Decimal-
    '- blnHexSelected - Checks if user is on Value 1 Hex        -
    '- blnHex2Selected - Checks if user is on Value 2 Hex       -
    '------------------------------------------------------------
    '---------------------------------------------------------------------------------------
    '--- GLOBAL CONSTANTS --- GLOBAL CONSTANTS --- GLOBAL CONSTANTS --- GLOBAL CONSTANTS ---
    '--- GLOBAL CONSTANTS --- GLOBAL CONSTANTS --- GLOBAL CONSTANTS --- GLOBAL CONSTANTS ---
    '--- GLOBAL CONSTANTS --- GLOBAL CONSTANTS --- GLOBAL CONSTANTS --- GLOBAL CONSTANTS ---
    '---------------------------------------------------------------------------------------
    '- (None)                                                                              -
    '---------------------------------------------------------------------------------------
    '-------------------------------------------------------------------------------------------
    '--- GLOBAL STRUCTURES --- GLOBAL STRUCTURES --- GLOBAL STRUCTURES --- GLOBAL STRUCTURES ---
    '--- GLOBAL STRUCTURES --- GLOBAL STRUCTURES --- GLOBAL STRUCTURES --- GLOBAL STRUCTURES ---
    '--- GLOBAL STRUCTURES --- GLOBAL STRUCTURES --- GLOBAL STRUCTURES --- GLOBAL STRUCTURES ---
    '-------------------------------------------------------------------------------------------
    '- (None)                                                                                  -
    '-------------------------------------------------------------------------------------------
    '---------------------------------------------------------------------------------------
    '--- GLOBAL VARIABLES --- GLOBAL VARIABLES --- GLOBAL VARIABLES --- GLOBAL VARIABLES ---
    '--- GLOBAL VARIABLES --- GLOBAL VARIABLES --- GLOBAL VARIABLES --- GLOBAL VARIABLES ---
    '--- GLOBAL VARIABLES --- GLOBAL VARIABLES --- GLOBAL VARIABLES --- GLOBAL VARIABLES ---
    '---------------------------------------------------------------------------------------


    Dim blnBinarySelected As Boolean ' Checks if user is on Value 1 Binary
    Dim blnBinary2Selected As Boolean 'Checks if user is on Value 2 Binary
    Dim blnDecimalSelected As Boolean ' Checks if user is on Value 1 Decimal
    Dim blnDecimal2Selected As Boolean ' Checks if user is on Value 2 Decimal
    Dim blnHexSelected As Boolean 'Checks if user is on Value 1 Hex
    Dim blnHex2Selected As Boolean ' Checks if user is on Value 2 Hex



    Private Sub frmChild_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        '------------------------------------------------------------
        '-            Subprogram Name: frmChildLoad                 -
        '------------------------------------------------------------
        '-                Written By: Justin Ganzak                 -
        '-                Written On: March 20, 2022                -
        '------------------------------------------------------------
        '- Subprogram Purpose:                                      -
        '-                                                          -
        '- This subroutine handles setting up the program on load   -
        '- It hides certain buttons and puts blnBinarySelected to true-
        '- to start there as a default
        '------------------------------------------------------------
        '- Parameter Dictionary (in parameter order):               -
        '- sender -
        '- e
        '------------------------------------------------------------
        '- Local Variable Dictionary (alphabetically):              -
        '- (None)                                                   -
        '------------------------------------------------------------

        blnBinarySelected = True
        btnA.Visible = False
        btnB.Visible = False
        btnC.Visible = False
        btnD.Visible = False
        btnE.Visible = False
        btnF.Visible = False
        btn2.Visible = False
        btn3.Visible = False
        btn4.Visible = False
        btn5.Visible = False
        btn6.Visible = False
        btn7.Visible = False
        btn8.Visible = False
        btn9.Visible = False
        btn0.Visible = True
        btn1.Visible = True
    End Sub

    Private Sub btnClearValue1_Click(sender As Object, e As EventArgs) Handles btnClearValue1.Click
        '------------------------------------------------------------
        '-            Subprogram Name: ClearValue1                  -
        '------------------------------------------------------------
        '-                Written By: Justin Ganzak                 -
        '-                Written On: March 20, 2022                -
        '------------------------------------------------------------
        '- Subprogram Purpose:                                      -
        '-                                                          -
        '- This subroutine handles clearing the values in the value1-
        '- txt Boxes
        '------------------------------------------------------------
        '- Parameter Dictionary (in parameter order):               -
        '- sender -
        '- e
        '------------------------------------------------------------
        '- Local Variable Dictionary (alphabetically):              -
        '- (None)                                                   -
        '------------------------------------------------------------

        txtBinary.Text = "0"
        txtDecimal.Text = "0"
        txtHex.Text = "0"
    End Sub

    Private Sub btnClearValue2_Click(sender As Object, e As EventArgs) Handles btnClearValue2.Click
        '------------------------------------------------------------
        '-            Subprogram Name: ClearValue2                  -
        '------------------------------------------------------------
        '-                Written By: Justin Ganzak                 -
        '-                Written On: March 20, 2022                -
        '------------------------------------------------------------
        '- Subprogram Purpose:                                      -
        '-                                                          -
        '- This subroutine handles clearing the values in the value2-
        '- txt Boxes
        '------------------------------------------------------------
        '- Parameter Dictionary (in parameter order):               -
        '- sender -
        '- e
        '------------------------------------------------------------
        '- Local Variable Dictionary (alphabetically):              -
        '- (None)                                                   -
        '------------------------------------------------------------
        txtBinary2.Text = "0"
        txtDecimal2.Text = "0"
        txtHex2.Text = "0"
    End Sub

    Private Sub btnClearResult_Click(sender As Object, e As EventArgs) Handles btnClearResult.Click
        '------------------------------------------------------------
        '-            Subprogram Name: ClearValueResult             -
        '------------------------------------------------------------
        '-                Written By: Justin Ganzak                 -
        '-                Written On: March 20, 2022                -
        '------------------------------------------------------------
        '- Subprogram Purpose:                                      -
        '-                                                          -
        '- This subroutine handles clearing the values in the result-
        '- txt Boxes
        '------------------------------------------------------------
        '- Parameter Dictionary (in parameter order):               -
        '- sender -
        '- e
        '------------------------------------------------------------
        '- Local Variable Dictionary (alphabetically):              -
        '- (None)                                                   -
        '------------------------------------------------------------
        txtBinary3.Text = "0"
        txtDecimal3.Text = "0"
        txtHex3.Text = "0"
    End Sub

    Private Sub txtBinary_Click(sender As Object, e As EventArgs) Handles txtBinary.Click
        '------------------------------------------------------------
        '-            Subprogram Name: Binary1 Click                -
        '------------------------------------------------------------
        '-                Written By: Justin Ganzak                 -
        '-                Written On: March 20, 2022                -
        '------------------------------------------------------------
        '- Subprogram Purpose:                                      -
        '-                                                          -
        '- This subroutine handles checking if the user has clicked -
        '- on the value 1 binary box, and sets the correct buttons  -
        '- visibility and changes the boolean to true and the rest to-
        '- False to make sure the information goes to the right spot-
        '------------------------------------------------------------
        '- Parameter Dictionary (in parameter order):               -
        '- sender -
        '- e
        '------------------------------------------------------------
        '- Local Variable Dictionary (alphabetically):              -
        '- (None)                                                   -
        '------------------------------------------------------------
        blnBinarySelected = True
        blnBinary2Selected = False
        blnHex2Selected = False
        blnHexSelected = False
        blnDecimalSelected = False
        blnDecimal2Selected = False

        btnA.Visible = False
        btnB.Visible = False
        btnC.Visible = False
        btnD.Visible = False
        btnE.Visible = False
        btnF.Visible = False
        btn2.Visible = False
        btn3.Visible = False
        btn4.Visible = False
        btn5.Visible = False
        btn6.Visible = False
        btn7.Visible = False
        btn8.Visible = False
        btn9.Visible = False
        btn0.Visible = True
        btn1.Visible = True
    End Sub

    Private Sub txtBinary2_Click(sender As Object, e As EventArgs) Handles txtBinary2.Click
        '------------------------------------------------------------
        '-            Subprogram Name: Binary2 Click                -
        '------------------------------------------------------------
        '-                Written By: Justin Ganzak                 -
        '-                Written On: March 20, 2022                -
        '------------------------------------------------------------
        '- Subprogram Purpose:                                      -
        '-                                                          -
        '- This subroutine handles checking if the user has clicked -
        '- on the value 2 binary box, and sets the correct buttons  -
        '- visibility and changes the boolean to true and the rest to-
        '- False to make sure the information goes to the right spot-
        '------------------------------------------------------------
        '- Parameter Dictionary (in parameter order):               -
        '- sender -
        '- e
        '------------------------------------------------------------
        '- Local Variable Dictionary (alphabetically):              -
        '- (None)                                                   -
        '------------------------------------------------------------
        blnBinarySelected = False
        blnBinary2Selected = True
        blnHex2Selected = False
        blnHexSelected = False
        blnDecimalSelected = False
        blnDecimal2Selected = False

        btnA.Visible = False
        btnB.Visible = False
        btnC.Visible = False
        btnD.Visible = False
        btnE.Visible = False
        btnF.Visible = False
        btn2.Visible = False
        btn3.Visible = False
        btn4.Visible = False
        btn5.Visible = False
        btn6.Visible = False
        btn7.Visible = False
        btn8.Visible = False
        btn9.Visible = False
        btn0.Visible = True
        btn1.Visible = True
    End Sub

    Private Sub txtDecimal_Click(sender As Object, e As EventArgs) Handles txtDecimal.Click
        '------------------------------------------------------------
        '-            Subprogram Name: Decimal1 Click               -
        '------------------------------------------------------------
        '-                Written By: Justin Ganzak                 -
        '-                Written On: March 20, 2022                -
        '------------------------------------------------------------
        '- Subprogram Purpose:                                      -
        '-                                                          -
        '- This subroutine handles checking if the user has clicked -
        '- on the value 1 decimal box, and sets the correct buttons  -
        '- visibility and changes the boolean to true and the rest to-
        '- False to make sure the information goes to the right spot-
        '------------------------------------------------------------
        '- Parameter Dictionary (in parameter order):               -
        '- sender -
        '- e
        '------------------------------------------------------------
        '- Local Variable Dictionary (alphabetically):              -
        '- (None)                                                   -
        '------------------------------------------------------------
        blnBinarySelected = False
        blnBinary2Selected = False
        blnHex2Selected = False
        blnHexSelected = False
        blnDecimalSelected = True
        blnDecimal2Selected = False

        btnA.Visible = False
        btnB.Visible = False
        btnC.Visible = False
        btnD.Visible = False
        btnE.Visible = False
        btnF.Visible = False
        btn2.Visible = True
        btn3.Visible = True
        btn4.Visible = True
        btn5.Visible = True
        btn6.Visible = True
        btn7.Visible = True
        btn8.Visible = True
        btn9.Visible = True
        btn0.Visible = True
        btn1.Visible = True
    End Sub

    Private Sub txtDecimal2_Click(sender As Object, e As EventArgs) Handles txtDecimal2.Click
        '------------------------------------------------------------
        '-            Subprogram Name: Decimal2 Click                -
        '------------------------------------------------------------
        '-                Written By: Justin Ganzak                 -
        '-                Written On: March 20, 2022                -
        '------------------------------------------------------------
        '- Subprogram Purpose:                                      -
        '-                                                          -
        '- This subroutine handles checking if the user has clicked -
        '- on the value 2 Decimal box, and sets the correct buttons  -
        '- visibility and changes the boolean to true and the rest to-
        '- False to make sure the information goes to the right spot-
        '------------------------------------------------------------
        '- Parameter Dictionary (in parameter order):               -
        '- sender -
        '- e
        '------------------------------------------------------------
        '- Local Variable Dictionary (alphabetically):              -
        '- (None)                                                   -
        '------------------------------------------------------------
        blnBinarySelected = False
        blnBinary2Selected = False
        blnHex2Selected = False
        blnHexSelected = False
        blnDecimalSelected = False
        blnDecimal2Selected = True

        btnA.Visible = False
        btnB.Visible = False
        btnC.Visible = False
        btnD.Visible = False
        btnE.Visible = False
        btnF.Visible = False
        btn2.Visible = True
        btn3.Visible = True
        btn4.Visible = True
        btn5.Visible = True
        btn6.Visible = True
        btn7.Visible = True
        btn8.Visible = True
        btn9.Visible = True
        btn0.Visible = True
        btn1.Visible = True
    End Sub

    Private Sub txtHex_Click(sender As Object, e As EventArgs) Handles txtHex.Click
        '------------------------------------------------------------
        '-            Subprogram Name: Hex1 Click                   -
        '------------------------------------------------------------
        '-                Written By: Justin Ganzak                 -
        '-                Written On: March 20, 2022                -
        '------------------------------------------------------------
        '- Subprogram Purpose:                                      -
        '-                                                          -
        '- This subroutine handles checking if the user has clicked -
        '- on the value 1 Hex box, and sets the correct buttons     -
        '- visibility and changes the boolean to true and the rest to-
        '- False to make sure the information goes to the right spot-
        '------------------------------------------------------------
        '- Parameter Dictionary (in parameter order):               -
        '- sender -
        '- e
        '------------------------------------------------------------
        '- Local Variable Dictionary (alphabetically):              -
        '- (None)                                                   -
        '------------------------------------------------------------
        blnBinarySelected = False
        blnBinary2Selected = False
        blnHex2Selected = False
        blnHexSelected = True
        blnDecimalSelected = False
        blnDecimal2Selected = False

        btnA.Visible = True
        btnB.Visible = True
        btnC.Visible = True
        btnD.Visible = True
        btnE.Visible = True
        btnF.Visible = True
        btn2.Visible = True
        btn3.Visible = True
        btn4.Visible = True
        btn5.Visible = True
        btn6.Visible = True
        btn7.Visible = True
        btn8.Visible = True
        btn9.Visible = True
        btn0.Visible = True
        btn1.Visible = True
    End Sub

    Private Sub txtHex2_Click(sender As Object, e As EventArgs) Handles txtHex2.Click
        '------------------------------------------------------------
        '-            Subprogram Name: Hex2 Click                   -
        '------------------------------------------------------------
        '-                Written By: Justin Ganzak                 -
        '-                Written On: March 20, 2022                -
        '------------------------------------------------------------
        '- Subprogram Purpose:                                      -
        '-                                                          -
        '- This subroutine handles checking if the user has clicked -
        '- on the value 2 Hex box, and sets the correct buttons     -
        '- visibility and changes the boolean to true and the rest to-
        '- False to make sure the information goes to the right spot-
        '------------------------------------------------------------
        '- Parameter Dictionary (in parameter order):               -
        '- sender -
        '- e
        '------------------------------------------------------------
        '- Local Variable Dictionary (alphabetically):              -
        '- (None)                                                   -
        '------------------------------------------------------------
        blnBinarySelected = False
        blnBinary2Selected = False
        blnHex2Selected = True
        blnHexSelected = False
        blnDecimalSelected = False
        blnDecimal2Selected = False

        btnA.Visible = True
        btnB.Visible = True
        btnC.Visible = True
        btnD.Visible = True
        btnE.Visible = True
        btnF.Visible = True
        btn2.Visible = True
        btn3.Visible = True
        btn4.Visible = True
        btn5.Visible = True
        btn6.Visible = True
        btn7.Visible = True
        btn8.Visible = True
        btn9.Visible = True
        btn0.Visible = True
        btn1.Visible = True
    End Sub

    Private Sub btn0_Click(sender As Object, e As EventArgs) Handles btn0.Click
        '------------------------------------------------------------
        '-            Subprogram Name: Btn0 Click                   -
        '------------------------------------------------------------
        '-                Written By: Justin Ganzak                 -
        '-                Written On: March 20, 2022                -
        '------------------------------------------------------------
        '- Subprogram Purpose:                                      -
        '-                                                          -
        '- This subroutine handles checking what box the user is on,-
        '- and then inserts a 0 into the corresponding txtbox.
        '------------------------------------------------------------
        '- Parameter Dictionary (in parameter order):               -
        '- sender -
        '- e
        '------------------------------------------------------------
        '- Local Variable Dictionary (alphabetically):              -
        '- (None)                                                   -
        '------------------------------------------------------------
        If blnBinarySelected = True Then
            txtBinary.Text += "0"
        End If

        If blnBinary2Selected = True Then

            txtBinary2.Text += "0"
        End If

        If blnDecimal2Selected = True Then

            txtDecimal2.Text += "0"
        End If

        If blnDecimalSelected = True Then
            txtDecimal.Text += "0"
        End If

        If blnHexSelected = True Then
            txtHex.Text += "0"
        End If

        If blnHex2Selected = True Then
            txtHex2.Text += "0"
        End If

    End Sub

    Private Sub btn1_Click(sender As Object, e As EventArgs) Handles btn1.Click
        '------------------------------------------------------------
        '-            Subprogram Name: Btn1 Click                   -
        '------------------------------------------------------------
        '-                Written By: Justin Ganzak                 -
        '-                Written On: March 20, 2022                -
        '------------------------------------------------------------
        '- Subprogram Purpose:                                      -
        '-                                                          -
        '- This subroutine handles checking what box the user is on,-
        '- and then inserts a 1 into the corresponding txtbox.
        '------------------------------------------------------------
        '- Parameter Dictionary (in parameter order):               -
        '- sender -
        '- e
        '------------------------------------------------------------
        '- Local Variable Dictionary (alphabetically):              -
        '- (None)                                                   -
        '------------------------------------------------------------
        If blnBinarySelected = True Then

            txtBinary.Text += "1"
        End If

        If blnBinary2Selected = True Then

            txtBinary2.Text += "1"
        End If

        If blnDecimal2Selected = True Then
            txtDecimal2.Text += "1"
        End If

        If blnDecimalSelected = True Then
            txtDecimal.Text += "1"
        End If

        If blnHexSelected = True Then
            txtHex.Text += "1"
        End If

        If blnHex2Selected = True Then
            txtHex2.Text += "1"
        End If
    End Sub

    Private Sub btn2_Click(sender As Object, e As EventArgs) Handles btn2.Click
        '------------------------------------------------------------
        '-            Subprogram Name: Btn2 Click                   -
        '------------------------------------------------------------
        '-                Written By: Justin Ganzak                 -
        '-                Written On: March 20, 2022                -
        '------------------------------------------------------------
        '- Subprogram Purpose:                                      -
        '-                                                          -
        '- This subroutine handles checking what box the user is on,-
        '- and then inserts a 2 into the corresponding txtbox.
        '------------------------------------------------------------
        '- Parameter Dictionary (in parameter order):               -
        '- sender -
        '- e
        '------------------------------------------------------------
        '- Local Variable Dictionary (alphabetically):              -
        '- (None)                                                   -
        '------------------------------------------------------------
        If blnDecimal2Selected = True Then
            txtDecimal2.Text += "2"
        End If

        If blnDecimalSelected = True Then
            txtDecimal.Text += "2"
        End If

        If blnHexSelected = True Then
            txtHex.Text += "2"
        End If

        If blnHex2Selected = True Then
            txtHex2.Text += "2"
        End If
    End Sub

    Private Sub btn3_Click(sender As Object, e As EventArgs) Handles btn3.Click
        '------------------------------------------------------------
        '-            Subprogram Name: Btn3 Click                   -
        '------------------------------------------------------------
        '-                Written By: Justin Ganzak                 -
        '-                Written On: March 20, 2022                -
        '------------------------------------------------------------
        '- Subprogram Purpose:                                      -
        '-                                                          -
        '- This subroutine handles checking what box the user is on,-
        '- and then inserts a 3 into the corresponding txtbox.
        '------------------------------------------------------------
        '- Parameter Dictionary (in parameter order):               -
        '- sender -
        '- e
        '------------------------------------------------------------
        '- Local Variable Dictionary (alphabetically):              -
        '- (None)                                                   -
        '------------------------------------------------------------
        If blnDecimal2Selected = True Then
            txtDecimal2.Text += "3"
        End If

        If blnDecimalSelected = True Then
            txtDecimal.Text += "3"
        End If

        If blnHexSelected = True Then
            txtHex.Text += "3"
        End If

        If blnHex2Selected = True Then
            txtHex2.Text += "3"
        End If
    End Sub

    Private Sub btn4_Click(sender As Object, e As EventArgs) Handles btn4.Click
        '------------------------------------------------------------
        '-            Subprogram Name: Btn4 Click                   -
        '------------------------------------------------------------
        '-                Written By: Justin Ganzak                 -
        '-                Written On: March 20, 2022                -
        '------------------------------------------------------------
        '- Subprogram Purpose:                                      -
        '-                                                          -
        '- This subroutine handles checking what box the user is on,-
        '- and then inserts a 4 into the corresponding txtbox.
        '------------------------------------------------------------
        '- Parameter Dictionary (in parameter order):               -
        '- sender -
        '- e
        '------------------------------------------------------------
        '- Local Variable Dictionary (alphabetically):              -
        '- (None)                                                   -
        '------------------------------------------------------------
        If blnDecimal2Selected = True Then
            txtDecimal2.Text += "4"
        End If

        If blnDecimalSelected = True Then
            txtDecimal.Text += "4"
        End If

        If blnHexSelected = True Then
            txtHex.Text += "4"
        End If

        If blnHex2Selected = True Then
            txtHex2.Text += "4"
        End If
    End Sub

    Private Sub btn5_Click(sender As Object, e As EventArgs) Handles btn5.Click
        '------------------------------------------------------------
        '-            Subprogram Name: Btn5 Click                   -
        '------------------------------------------------------------
        '-                Written By: Justin Ganzak                 -
        '-                Written On: March 20, 2022                -
        '------------------------------------------------------------
        '- Subprogram Purpose:                                      -
        '-                                                          -
        '- This subroutine handles checking what box the user is on,-
        '- and then inserts a 5 into the corresponding txtbox.
        '------------------------------------------------------------
        '- Parameter Dictionary (in parameter order):               -
        '- sender -
        '- e
        '------------------------------------------------------------
        '- Local Variable Dictionary (alphabetically):              -
        '- (None)                                                   -
        '------------------------------------------------------------
        If blnDecimal2Selected = True Then
            txtDecimal2.Text += "5"
        End If

        If blnDecimalSelected = True Then
            txtDecimal.Text += "5"
        End If

        If blnHexSelected = True Then
            txtHex.Text += "5"
        End If

        If blnHex2Selected = True Then
            txtHex2.Text += "5"
        End If
    End Sub

    Private Sub btn6_Click(sender As Object, e As EventArgs) Handles btn6.Click
        '------------------------------------------------------------
        '-            Subprogram Name: Btn6 Click                   -
        '------------------------------------------------------------
        '-                Written By: Justin Ganzak                 -
        '-                Written On: March 20, 2022                -
        '------------------------------------------------------------
        '- Subprogram Purpose:                                      -
        '-                                                          -
        '- This subroutine handles checking what box the user is on,-
        '- and then inserts a 6 into the corresponding txtbox.
        '------------------------------------------------------------
        '- Parameter Dictionary (in parameter order):               -
        '- sender -
        '- e
        '------------------------------------------------------------
        '- Local Variable Dictionary (alphabetically):              -
        '- (None)                                                   -
        '------------------------------------------------------------
        If blnDecimal2Selected = True Then
            txtDecimal2.Text += "6"
        End If

        If blnDecimalSelected = True Then
            txtDecimal.Text += "6"
        End If

        If blnHexSelected = True Then
            txtHex.Text += "6"
        End If

        If blnHex2Selected = True Then
            txtHex2.Text += "6"
        End If
    End Sub

    Private Sub btn7_Click(sender As Object, e As EventArgs) Handles btn7.Click
        '------------------------------------------------------------
        '-            Subprogram Name: Btn7 Click                   -
        '------------------------------------------------------------
        '-                Written By: Justin Ganzak                 -
        '-                Written On: March 20, 2022                -
        '------------------------------------------------------------
        '- Subprogram Purpose:                                      -
        '-                                                          -
        '- This subroutine handles checking what box the user is on,-
        '- and then inserts a 7 into the corresponding txtbox.
        '------------------------------------------------------------
        '- Parameter Dictionary (in parameter order):               -
        '- sender -
        '- e
        '------------------------------------------------------------
        '- Local Variable Dictionary (alphabetically):              -
        '- (None)                                                   -
        '------------------------------------------------------------
        If blnDecimal2Selected = True Then
            txtDecimal2.Text += "7"
        End If

        If blnDecimalSelected = True Then
            txtDecimal.Text += "7"
        End If

        If blnHexSelected = True Then
            txtHex.Text += "7"
        End If

        If blnHex2Selected = True Then
            txtHex2.Text += "7"
        End If
    End Sub

    Private Sub btn8_Click(sender As Object, e As EventArgs) Handles btn8.Click
        '------------------------------------------------------------
        '-            Subprogram Name: Btn8 Click                   -
        '------------------------------------------------------------
        '-                Written By: Justin Ganzak                 -
        '-                Written On: March 20, 2022                -
        '------------------------------------------------------------
        '- Subprogram Purpose:                                      -
        '-                                                          -
        '- This subroutine handles checking what box the user is on,-
        '- and then inserts a 8 into the corresponding txtbox.
        '------------------------------------------------------------
        '- Parameter Dictionary (in parameter order):               -
        '- sender -
        '- e
        '------------------------------------------------------------
        '- Local Variable Dictionary (alphabetically):              -
        '- (None)                                                   -
        '------------------------------------------------------------
        If blnDecimal2Selected = True Then
            txtDecimal2.Text += "8"
        End If

        If blnDecimalSelected = True Then
            txtDecimal.Text += "8"
        End If

        If blnHexSelected = True Then
            txtHex.Text += "8"
        End If

        If blnHex2Selected = True Then
            txtHex2.Text += "8"
        End If
    End Sub

    Private Sub btn9_Click(sender As Object, e As EventArgs) Handles btn9.Click
        '------------------------------------------------------------
        '-            Subprogram Name: Btn9 Click                   -
        '------------------------------------------------------------
        '-                Written By: Justin Ganzak                 -
        '-                Written On: March 20, 2022                -
        '------------------------------------------------------------
        '- Subprogram Purpose:                                      -
        '-                                                          -
        '- This subroutine handles checking what box the user is on,-
        '- and then inserts a 9 into the corresponding txtbox.
        '------------------------------------------------------------
        '- Parameter Dictionary (in parameter order):               -
        '- sender -
        '- e
        '------------------------------------------------------------
        '- Local Variable Dictionary (alphabetically):              -
        '- (None)                                                   -
        '------------------------------------------------------------
        If blnDecimal2Selected = True Then
            txtDecimal2.Text += "9"
        End If

        If blnDecimalSelected = True Then
            txtDecimal.Text += "9"
        End If

        If blnHexSelected = True Then
            txtHex.Text += "9"
        End If

        If blnHex2Selected = True Then
            txtHex2.Text += "9"
        End If
    End Sub

    Private Sub btnA_Click(sender As Object, e As EventArgs) Handles btnA.Click
        '------------------------------------------------------------
        '-            Subprogram Name: BtnA Click                   -
        '------------------------------------------------------------
        '-                Written By: Justin Ganzak                 -
        '-                Written On: March 20, 2022                -
        '------------------------------------------------------------
        '- Subprogram Purpose:                                      -
        '-                                                          -
        '- This subroutine handles checking what box the user is on,-
        '- and then inserts a A into the corresponding txtbox.
        '------------------------------------------------------------
        '- Parameter Dictionary (in parameter order):               -
        '- sender -
        '- e
        '------------------------------------------------------------
        '- Local Variable Dictionary (alphabetically):              -
        '- (None)                                                   -
        '------------------------------------------------------------
        If blnHexSelected = True Then
            txtHex.Text += "A"
        End If

        If blnHex2Selected = True Then
            txtHex2.Text += "A"
        End If
    End Sub

    Private Sub btnB_Click(sender As Object, e As EventArgs) Handles btnB.Click
        '------------------------------------------------------------
        '-            Subprogram Name: BtnB Click                   -
        '------------------------------------------------------------
        '-                Written By: Justin Ganzak                 -
        '-                Written On: March 20, 2022                -
        '------------------------------------------------------------
        '- Subprogram Purpose:                                      -
        '-                                                          -
        '- This subroutine handles checking what box the user is on,-
        '- and then inserts a B into the corresponding txtbox.
        '------------------------------------------------------------
        '- Parameter Dictionary (in parameter order):               -
        '- sender -
        '- e
        '------------------------------------------------------------
        '- Local Variable Dictionary (alphabetically):              -
        '- (None)                                                   -
        '------------------------------------------------------------
        If blnHexSelected = True Then
            txtHex.Text += "B"
        End If

        If blnHex2Selected = True Then
            txtHex2.Text += "B"
        End If
    End Sub

    Private Sub btnC_Click(sender As Object, e As EventArgs) Handles btnC.Click
        '------------------------------------------------------------
        '-            Subprogram Name: BtnC Click                   -
        '------------------------------------------------------------
        '-                Written By: Justin Ganzak                 -
        '-                Written On: March 20, 2022                -
        '------------------------------------------------------------
        '- Subprogram Purpose:                                      -
        '-                                                          -
        '- This subroutine handles checking what box the user is on,-
        '- and then inserts a C into the corresponding txtbox.
        '------------------------------------------------------------
        '- Parameter Dictionary (in parameter order):               -
        '- sender -
        '- e
        '------------------------------------------------------------
        '- Local Variable Dictionary (alphabetically):              -
        '- (None)                                                   -
        '------------------------------------------------------------
        If blnHexSelected = True Then
            txtHex.Text += "C"
        End If

        If blnHex2Selected = True Then
            txtHex2.Text += "C"
        End If
    End Sub

    Private Sub btnD_Click(sender As Object, e As EventArgs) Handles btnD.Click
        '------------------------------------------------------------
        '-            Subprogram Name: BtnD Click                   -
        '------------------------------------------------------------
        '-                Written By: Justin Ganzak                 -
        '-                Written On: March 20, 2022                -
        '------------------------------------------------------------
        '- Subprogram Purpose:                                      -
        '-                                                          -
        '- This subroutine handles checking what box the user is on,-
        '- and then inserts a D into the corresponding txtbox.
        '------------------------------------------------------------
        '- Parameter Dictionary (in parameter order):               -
        '- sender -
        '- e
        '------------------------------------------------------------
        '- Local Variable Dictionary (alphabetically):              -
        '- (None)                                                   -
        '------------------------------------------------------------
        If blnHexSelected = True Then
            txtHex.Text += "D"
        End If

        If blnHex2Selected = True Then
            txtHex2.Text += "D"
        End If
    End Sub

    Private Sub btnE_Click(sender As Object, e As EventArgs) Handles btnE.Click
        '------------------------------------------------------------
        '-            Subprogram Name: BtnE Click                   -
        '------------------------------------------------------------
        '-                Written By: Justin Ganzak                 -
        '-                Written On: March 20, 2022                -
        '------------------------------------------------------------
        '- Subprogram Purpose:                                      -
        '-                                                          -
        '- This subroutine handles checking what box the user is on,-
        '- and then inserts a E into the corresponding txtbox.
        '------------------------------------------------------------
        '- Parameter Dictionary (in parameter order):               -
        '- sender -
        '- e
        '------------------------------------------------------------
        '- Local Variable Dictionary (alphabetically):              -
        '- (None)                                                   -
        '------------------------------------------------------------
        If blnHexSelected = True Then
            txtHex.Text += "E"
        End If

        If blnHex2Selected = True Then
            txtHex2.Text += "E"
        End If
    End Sub

    Private Sub btnF_Click(sender As Object, e As EventArgs) Handles btnF.Click
        '------------------------------------------------------------
        '-            Subprogram Name: BtnF Click                   -
        '------------------------------------------------------------
        '-                Written By: Justin Ganzak                 -
        '-                Written On: March 20, 2022                -
        '------------------------------------------------------------
        '- Subprogram Purpose:                                      -
        '-                                                          -
        '- This subroutine handles checking what box the user is on,-
        '- and then inserts a F into the corresponding txtbox.
        '------------------------------------------------------------
        '- Parameter Dictionary (in parameter order):               -
        '- sender -
        '- e
        '------------------------------------------------------------
        '- Local Variable Dictionary (alphabetically):              -
        '- (None)                                                   -
        '------------------------------------------------------------
        If blnHexSelected = True Then
            txtHex.Text += "F"
        End If

        If blnHex2Selected = True Then
            txtHex2.Text += "F"
        End If
    End Sub


    Private Sub btnConvert_Click(sender As Object, e As EventArgs) Handles btnConvert.Click
        '------------------------------------------------------------
        '-            Subprogram Name: BtnConvert Click             -
        '------------------------------------------------------------
        '-                Written By: Justin Ganzak                 -
        '-                Written On: March 20, 2022                -
        '------------------------------------------------------------
        '- Subprogram Purpose:                                      -
        '-                                                          -
        '- This subroutine handles converting the values based on what-
        '- txtBox the user had most recently click on. It updates the-
        '- corresponding text boxes and calls functions to convert the-
        '- data to its proper form
        '------------------------------------------------------------
        '- Parameter Dictionary (in parameter order):               -
        '- sender -
        '- e
        '------------------------------------------------------------
        '- Local Variable Dictionary (alphabetically):              -
        '- (None)                                                   -
        '------------------------------------------------------------
        If blnBinarySelected = True Or blnBinary2Selected = True Then
            txtDecimal.Text = BinaryToDecimal(txtBinary.Text)
            txtHex.Text = Hex(txtDecimal.Text)
            txtDecimal2.Text = BinaryToDecimal(txtBinary2.Text)
            txtHex2.Text = Hex(txtDecimal2.Text)
        End If

        If blnDecimalSelected = True Or blnDecimal2Selected = True Then
            txtBinary.Text = DecToBin(txtDecimal.Text)
            txtHex.Text = Hex(txtDecimal.Text)
            txtBinary2.Text = DecToBin(txtDecimal2.Text)
            txtHex2.Text = Hex(txtDecimal2.Text)
        End If

        If blnHex2Selected = True Or blnHexSelected = True Then
            txtDecimal2.Text = CInt("&H" & txtHex2.Text)
            txtBinary2.Text = DecToBin(txtDecimal2.Text)
            txtDecimal.Text = CInt("&H" & txtHex.Text)
            txtBinary.Text = DecToBin(txtDecimal.Text)
        End If

    End Sub

    Private Function DecToBin(i As Integer) As String
        '------------------------------------------------------------
        '-            Function Name: DecToBin                      -
        '------------------------------------------------------------
        '-                Written By: Justin Ganzak                 -
        '-                Written On: March 20, 2022                -
        '------------------------------------------------------------
        '- Function   Purpose:                                      -
        '-                                                          -
        '- This functions handles converting decimal numbers to     -
        '- binary. It pulls the data from the txtBox and converts the-
        '- number to binary
        '------------------------------------------------------------
        '- Parameter Dictionary (in parameter order):               -
        '- i - holds as a counter to make sure it loops the correct -
        '- number of times
        '------------------------------------------------------------
        '- Local Variable Dictionary (alphabetically):              -
        '- strDecimalToBinary - Holds the string that needs to be converted-
        '------------------------------------------------------------
        Dim strDecimalToBinary As String
        strDecimalToBinary = ""
        Do While i > 0
            strDecimalToBinary = i Mod 2 & strDecimalToBinary
            i = i \ 2
        Loop
        Return strDecimalToBinary
    End Function

    Private Function BinaryToDecimal(temp) As Long

        '------------------------------------------------------------
        '-            Function Name: BinaryToDecimal                -
        '------------------------------------------------------------
        '-                Written By: Justin Ganzak                 -
        '-                Written On: March 20, 2022                -
        '------------------------------------------------------------
        '- Function   Purpose:                                      -
        '-                                                          -
        '- This functions handles converting binary  numbers to     -
        '- decimal. It pulls the data from the txtBox and converts the-
        '- number to decimal
        '------------------------------------------------------------
        '- Parameter Dictionary (in parameter order):               -
        '- temp - holds as a counter to make sure it loops the correct -
        '- number of times
        '------------------------------------------------------------
        '- Local Variable Dictionary (alphabetically):              -
        '- intX - Part of the counter, adds up until it hits intTemp-
        '- intTemp - Loops until this number is hit, ensures conversions is proper-
        '------------------------------------------------------------

        Dim intX As Integer
        Dim intTemp As Integer

        intTemp = Len(temp) - 1
        For intX = 0 To intTemp
            BinaryToDecimal = BinaryToDecimal +
        Mid(temp, intTemp - intX + 1, 1) * 2 ^ intX
        Next

    End Function

    Private Sub btnAnd_Click(sender As Object, e As EventArgs) Handles btnAnd.Click
        '------------------------------------------------------------
        '-            Subprogram Name: btnAnd Click                 -
        '------------------------------------------------------------
        '-                Written By: Justin Ganzak                 -
        '-                Written On: March 20, 2022                -
        '------------------------------------------------------------
        '- Subprogram Purpose:                                      -
        '-                                                          -
        '- This subroutine handles converting the two values with the-
        '- and operator and displaying the proper value in the result boxes.  -
        '- It converts the values the decimal then converts them back-
        '- to their original form after calculations                -
        '------------------------------------------------------------
        '- Parameter Dictionary (in parameter order):               -
        '- sender -
        '- e
        '------------------------------------------------------------
        '- Local Variable Dictionary (alphabetically):              -
        '- intDec - Holds the decimal value temporarily for conversions-
        '- intTempBin1 - Acts as a temp value for binary values     -
        '- intTempBin2 - Acts as a temp value for binary value      -
        '- intTempBin3 - Acts as a temp value for binary value      -
        '- intTempHex1 - Acts as a temp value for Hex value         -
        '- intTempHex2 - Acts as a temp value for Hex value         -
        '- intTempHex3 - Acts as a temp value for Hex  value        -
        '------------------------------------------------------------
        Dim intTempBin1, intTempBin2, intTempBin3 As Integer
        Dim intTempHex1, intTempHex2, intTempHex3 As Integer
        Dim intDec As Integer

        If blnDecimalSelected = True Or blnDecimal2Selected = True Then
            intDec = Val(txtDecimal.Text) And Val(txtDecimal2.Text)
            txtDecimal3.Text = intDec
            txtBinary3.Text = DecToBin(intDec)
            txtHex3.Text = Hex(intDec)
        End If

        If blnBinarySelected = True Or blnBinary2Selected = True Then
            intTempBin1 = BinaryToDecimal(txtBinary.Text)
            intTempBin2 = BinaryToDecimal(txtBinary2.Text)
            intTempBin3 = intTempBin1 And intTempBin2
            txtBinary3.Text = DecToBin(intTempBin3)
            txtDecimal3.Text = intTempBin3
            txtHex3.Text = Hex(intTempBin3)
        End If

        If blnHex2Selected = True Or blnHexSelected = True Then
            intTempHex1 = CInt("&H" & txtHex.Text)
            intTempHex2 = CInt("&H" & txtHex2.Text)
            intTempHex3 = (intTempHex1 And intTempHex2)
            txtHex3.Text = Hex(intTempHex3)
            txtDecimal3.Text = intTempHex3
            txtBinary3.Text = DecToBin(intTempHex3)
        End If


    End Sub

    Private Sub btnOr_Click(sender As Object, e As EventArgs) Handles btnOr.Click
        '------------------------------------------------------------
        '-            Subprogram Name: btnOr Click                  -
        '------------------------------------------------------------
        '-                Written By: Justin Ganzak                 -
        '-                Written On: March 20, 2022                -
        '------------------------------------------------------------
        '- Subprogram Purpose:                                      -
        '-                                                          -
        '- This subroutine handles converting the two values with the-
        '- or operator and displaying the proper value in the result boxes.  -
        '- It converts the values the decimal then converts them back-
        '- to their original form after calculations                -
        '------------------------------------------------------------
        '- Parameter Dictionary (in parameter order):               -
        '- sender -
        '- e
        '------------------------------------------------------------
        '- Local Variable Dictionary (alphabetically):              -
        '- intDec - Holds the decimal value temporarily for conversions-
        '- intTempBin1 - Acts as a temp value for binary values     -
        '- intTempBin2 - Acts as a temp value for binary value      -
        '- intTempBin3 - Acts as a temp value for binary value      -
        '- intTempHex1 - Acts as a temp value for Hex value         -
        '- intTempHex2 - Acts as a temp value for Hex value         -
        '- intTempHex3 - Acts as a temp value for Hex  value        -
        '------------------------------------------------------------
        Dim intTempBin1, intTempBin2, intTempBin3 As Integer
        Dim intTempHex1, intTempHex2, intTempHex3 As Integer
        Dim intDec As Integer

        If blnDecimalSelected = True Or blnDecimal2Selected = True Then
            intDec = Val(txtDecimal.Text) Or Val(txtDecimal2.Text)
            txtDecimal3.Text = intDec
            txtBinary3.Text = DecToBin(intDec)
            txtHex3.Text = Hex(intDec)
        End If

        If blnBinarySelected = True Or blnBinary2Selected = True Then
            intTempBin1 = BinaryToDecimal(txtBinary.Text)
            intTempBin2 = BinaryToDecimal(txtBinary2.Text)
            intTempBin3 = intTempBin1 Or intTempBin2
            txtBinary3.Text = DecToBin(intTempBin3)
            txtDecimal3.Text = intTempBin3
            txtHex3.Text = Hex(intTempBin3)

        End If

        If blnHex2Selected = True Or blnHexSelected = True Then
            intTempHex1 = CInt("&H" & txtHex.Text)
            intTempHex2 = CInt("&H" & txtHex2.Text)
            intTempHex3 = (intTempHex1 Or intTempHex2)
            txtHex3.Text = intTempHex3
            intTempBin1 = CInt("&H" & txtHex3.Text)
            txtDecimal3.Text = intTempBin1
            intTempBin1 = DecToBin(intTempBin1)
            txtBinary3.Text = intTempBin1
        End If
    End Sub

    Private Sub btnXor_Click(sender As Object, e As EventArgs) Handles btnXor.Click
        '------------------------------------------------------------
        '-            Subprogram Name: btnXor Click                 -
        '------------------------------------------------------------
        '-                Written By: Justin Ganzak                 -
        '-                Written On: March 20, 2022                -
        '------------------------------------------------------------
        '- Subprogram Purpose:                                      -
        '-                                                          -
        '- This subroutine handles converting the two values with the-
        '- Xor operator and displaying the proper value in the result boxes.  -
        '- It converts the values the decimal then converts them back-
        '- to their original form after calculations                -
        '------------------------------------------------------------
        '- Parameter Dictionary (in parameter order):               -
        '- sender -
        '- e
        '------------------------------------------------------------
        '- Local Variable Dictionary (alphabetically):              -
        '- intDec - Holds the decimal value temporarily for conversions-
        '- intTempBin1 - Acts as a temp value for binary values     -
        '- intTempBin2 - Acts as a temp value for binary value      -
        '- intTempBin3 - Acts as a temp value for binary value      -
        '- intTempHex1 - Acts as a temp value for Hex value         -
        '- intTempHex2 - Acts as a temp value for Hex value         -
        '- intTempHex3 - Acts as a temp value for Hex  value        -
        '------------------------------------------------------------
        Dim intTempBin1, intTempBin2, intTempBin3 As Integer
        Dim intTempHex1, intTempHex2, intTempHex3 As Integer
        Dim intDec As Integer

        If blnDecimalSelected = True Or blnDecimal2Selected = True Then
            intDec = Val(txtDecimal.Text) Xor Val(txtDecimal2.Text)
            txtDecimal3.Text = intDec
            txtBinary3.Text = DecToBin(intDec)
            txtHex3.Text = Hex(intDec)
        End If

        If blnBinarySelected = True Or blnBinary2Selected = True Then
            intTempBin1 = BinaryToDecimal(txtBinary.Text)
            intTempBin2 = BinaryToDecimal(txtBinary2.Text)
            intTempBin3 = intTempBin1 Xor intTempBin2
            txtBinary3.Text = DecToBin(intTempBin3)
            txtDecimal3.Text = intTempBin3
            txtHex3.Text = Hex(intTempBin3)
        End If

        If blnHex2Selected = True Or blnHexSelected = True Then
            intTempHex1 = CInt("&H" & txtHex.Text)
            intTempHex2 = CInt("&H" & txtHex2.Text)
            intTempHex3 = (intTempHex1 Xor intTempHex2)
            txtHex3.Text = Hex(intTempHex3)
            txtDecimal3.Text = intTempHex3
            txtBinary3.Text = DecToBin(intTempHex3)
        End If


    End Sub

    Private Sub btnNotValue1_Click(sender As Object, e As EventArgs) Handles btnNotValue1.Click
        '------------------------------------------------------------
        '-            Subprogram Name: btnNotValue1 Click           -
        '------------------------------------------------------------
        '-                Written By: Justin Ganzak                 -
        '-                Written On: March 20, 2022                -
        '------------------------------------------------------------
        '- Subprogram Purpose:                                      -
        '-                                                          -
        '- This subroutine handles converting the two values with the-
        '- Not operator and displaying the proper value in the result boxes.  -
        '- It converts the values the decimal then converts them back-
        '- to their original form after calculations                -
        '------------------------------------------------------------
        '- Parameter Dictionary (in parameter order):               -
        '- sender -
        '- e
        '------------------------------------------------------------
        '- Local Variable Dictionary (alphabetically):              -
        '- intTemp1 - Acts as a temp value for conversions          -
        '- intTemp2 - Holds the string inputted from user for conversions-
        '------------------------------------------------------------
        Dim intTemp1 As Integer
        Dim intTemp2 As String

        For Each element As Char In txtBinary.Text
            If element = "0" Then
                element = "1"
            Else
                element = "0"
            End If
            intTemp2 += element
        Next
        txtBinary3.Text = intTemp2
        intTemp1 = BinaryToDecimal(txtBinary3.Text)
        txtDecimal3.Text = Not (intTemp1)
        txtHex3.Text = Hex(intTemp1)


    End Sub

    Private Sub frmChild_Closing(sender As Object, e As CancelEventArgs) Handles Me.Closing
        '------------------------------------------------------------
        '-            Subprogram Name: frmChild Closing             -
        '------------------------------------------------------------
        '-                Written By: Justin Ganzak                 -
        '-                Written On: March 20, 2022                -
        '------------------------------------------------------------
        '- Subprogram Purpose:                                      -
        '-                                                          -
        '- This subroutine handles closing of the child forms. It   -
        '- checks if the txtboxes have anything in them, and if not -
        '- close them. If they do, display a message asking if they -
        '- want to close the childform.
        '------------------------------------------------------------
        '- Parameter Dictionary (in parameter order):               -
        '- sender -
        '- e
        '------------------------------------------------------------
        '- Local Variable Dictionary (alphabetically):              -
        '- answer - holds the dialogresult answer from the user to be-
        '- checked in the if loop
        '------------------------------------------------------------
        If txtDecimal.Text <> "0" Or txtDecimal2.Text <> "0" Or txtHex.Text <> "0" Or txtHex2.Text <> "0" Or txtBinary.Text <> "0" Or txtBinary2.Text <> "0" Then
            If txtDecimal.Text.Length > 0 Or txtBinary.Text.Length > 0 Or txtBinary2.Text.Length > 0 Or txtDecimal2.Text.Length > 0 Or txtHex.Text.Length > 0 Or txtHex2.Text.Length > 0 Then
                Dim answer As DialogResult = MessageBox.Show("Are you sure you want to close?", "Exit", MessageBoxButtons.YesNo)
                If answer = DialogResult.Yes Then
                    'MessageBox.Show("Yes")
                    Me.Hide()
                Else
                    ' MessageBox.Show("No")
                    e.Cancel = True
                End If
            End If
        End If
    End Sub
End Class