﻿Imports System.ComponentModel

Public Class Form1

    '------------------------------------------------------------
    '-                File Name : frmMain.frm                   - 
    '-                Part of Project: Main Menu of Calc        -
    '------------------------------------------------------------
    '-                Written By: Justin Ganzak                 -
    '-                Written On: March 19, 2022                -
    '------------------------------------------------------------
    '- File Purpose:                                            -
    '-                                                          -
    '- This file contains the main form for the entire appli-   -
    '- cation.  All user input is gathered on this form.  The   -
    '- calculations which are performed by the application      -
    '- reside in this file as well.  Finally all generated      -
    '- output is contained here too.                            -
    '------------------------------------------------------------
    '- Program Purpose:                                         -
    '-                                                          -
    '- The purpose of this program is to act as a menu for the  -
    '- child forms. It holds a file, new, exit, about, window,  -
    '- and help tabs. This allows the user to navigate through  -
    '- the program properly
    '------------------------------------------------------------
    '- Global Variable Dictionary (alphabetically):             -
    '- intChildCount - This variable holds the amount of child  -
    '- forms created to keep a count and name them properly.
    '------------------------------------------------------------
    '---------------------------------------------------------------------------------------
    '--- GLOBAL CONSTANTS --- GLOBAL CONSTANTS --- GLOBAL CONSTANTS --- GLOBAL CONSTANTS ---
    '--- GLOBAL CONSTANTS --- GLOBAL CONSTANTS --- GLOBAL CONSTANTS --- GLOBAL CONSTANTS ---
    '--- GLOBAL CONSTANTS --- GLOBAL CONSTANTS --- GLOBAL CONSTANTS --- GLOBAL CONSTANTS ---
    '---------------------------------------------------------------------------------------
    '- (None)                                                                              -
    '---------------------------------------------------------------------------------------
    '-------------------------------------------------------------------------------------------
    '--- GLOBAL STRUCTURES --- GLOBAL STRUCTURES --- GLOBAL STRUCTURES --- GLOBAL STRUCTURES ---
    '--- GLOBAL STRUCTURES --- GLOBAL STRUCTURES --- GLOBAL STRUCTURES --- GLOBAL STRUCTURES ---
    '--- GLOBAL STRUCTURES --- GLOBAL STRUCTURES --- GLOBAL STRUCTURES --- GLOBAL STRUCTURES ---
    '-------------------------------------------------------------------------------------------
    '- (None)                                                                                  -
    '-------------------------------------------------------------------------------------------

    Private Sub mnuAbout_Click(sender As Object, e As EventArgs) Handles mnuAbout.Click
        '------------------------------------------------------------
        '-            Subprogram Name: Menu About                   -
        '------------------------------------------------------------
        '-                Written By: Justin Ganzak                 -
        '-                Written On: March 19, 2022                -
        '------------------------------------------------------------
        '- Subprogram Purpose:                                      -
        '-                                                          -
        '- This subroutine handles the click event of the about btn. -
        '- It opens the corresponding form to allow the user to view -
        '------------------------------------------------------------
        '- Parameter Dictionary (in parameter order):               -
        '- sender -
        '- e
        '------------------------------------------------------------
        '- Local Variable Dictionary (alphabetically):              -
        '- (None)                                                   -
        '------------------------------------------------------------

        frmAbout.ShowDialog()
    End Sub

    Public intChildCount As Integer ' Holds count of children 


    Private Sub mnuFileNew_Click(sender As Object, e As EventArgs) Handles mnuFileNew.Click
        '------------------------------------------------------------
        '-            Subprogram Name: Menu New File                -
        '------------------------------------------------------------
        '-                Written By: Justin Ganzak                 -
        '-                Written On: March 19, 2022                -
        '------------------------------------------------------------
        '- Subprogram Purpose:                                      -
        '-                                                          -
        '- This subroutine handles the click event of the File btn. -
        '- It opens the corresponding form to allow the user to make -
        '- new files
        '------------------------------------------------------------
        '- Parameter Dictionary (in parameter order):               -
        '- sender -
        '- e
        '------------------------------------------------------------
        '- Local Variable Dictionary (alphabetically):              -
        '- aNewChildForm - Child form of main form, holds any new forms created-
        '------------------------------------------------------------

        Dim aNewChildForm As frmChild = New frmChild()

        aNewChildForm.MdiParent = Me

        intChildCount += 1

        aNewChildForm.Text = "Calculator " & intChildCount

        aNewChildForm.Show()

    End Sub

    Private Sub mnuWindowCascade_Click(sender As Object, e As EventArgs) Handles mnuWindowCascade.Click
        '------------------------------------------------------------
        '-            Subprogram Name: Menu Cascade                 -
        '------------------------------------------------------------
        '-                Written By: Justin Ganzak                 -
        '-                Written On: March 19, 2022                -
        '------------------------------------------------------------
        '- Subprogram Purpose:                                      -
        '-                                                          -
        '- This subroutine handles the click event of the Cascade   -
        '- button
        '- It rearranges the windows                                -
        '------------------------------------------------------------
        '- Parameter Dictionary (in parameter order):               -
        '- sender -
        '- e
        '------------------------------------------------------------
        '- Local Variable Dictionary (alphabetically):              -
        '- (None)                                                   -
        '------------------------------------------------------------
        Me.LayoutMdi(MdiLayout.Cascade)
    End Sub

    Private Sub mnuWindowHorizontal_Click(sender As Object, e As EventArgs) Handles mnuWindowHorizontal.Click
        '------------------------------------------------------------
        '-            Subprogram Name: Menu Horizontal              -
        '------------------------------------------------------------
        '-                Written By: Justin Ganzak                 -
        '-                Written On: March 19, 2022                -
        '------------------------------------------------------------
        '- Subprogram Purpose:                                      -
        '-                                                          -
        '- This subroutine handles the click event of the Hotizontal-
        '- button
        '- It rearranges the windows horizontally                   -
        '------------------------------------------------------------
        '- Parameter Dictionary (in parameter order):               -
        '- sender -
        '- e
        '------------------------------------------------------------
        '- Local Variable Dictionary (alphabetically):              -
        '- (None)                                                   -
        '------------------------------------------------------------
        Me.LayoutMdi(MdiLayout.TileHorizontal)
    End Sub

    Private Sub mnuWindowVertical_Click(sender As Object, e As EventArgs) Handles mnuWindowVertical.Click
        '------------------------------------------------------------
        '-            Subprogram Name: Menu Vertical               -
        '------------------------------------------------------------
        '-                Written By: Justin Ganzak                 -
        '-                Written On: March 19, 2022                -
        '------------------------------------------------------------
        '- Subprogram Purpose:                                      -
        '-                                                          -
        '- This subroutine handles the click event of the Vertical  -
        '- button
        '- It rearranges the windows Vertically                     -
        '------------------------------------------------------------
        '- Parameter Dictionary (in parameter order):               -
        '- sender -
        '- e
        '------------------------------------------------------------
        '- Local Variable Dictionary (alphabetically):              -
        '- (None)                                                   -
        '------------------------------------------------------------
        Me.LayoutMdi(MdiLayout.TileVertical)
    End Sub



    Private Sub mnuFileExit_Click(sender As Object, e As EventArgs) Handles mnuFileExit.Click
        '------------------------------------------------------------
        '-            Subprogram Name: Menu Exit Btn                -
        '------------------------------------------------------------
        '-                Written By: Justin Ganzak                 -
        '-                Written On: March 19, 2022                -
        '------------------------------------------------------------
        '- Subprogram Purpose:                                      -
        '-                                                          -
        '- This subroutine handles the click event of the Exit button-
        '- It loops through the child forms and if they have text in-
        '- them, it displays a msgbox with yesno if they want to close-
        '------------------------------------------------------------
        '- Parameter Dictionary (in parameter order):               -
        '- sender -
        '- e
        '------------------------------------------------------------
        '- Local Variable Dictionary (alphabetically):              -
        '- answer - Holds dialogresult from user                    -
        '------------------------------------------------------------
        For Each ChildForm As Form In Me.MdiChildren
            If frmChild.txtBinary.Text = "0" Or frmChild.txtBinary2.Text = "0" Or frmChild.txtDecimal2.Text = "0" Or frmChild.txtDecimal.Text = "0" Or frmChild.txtHex2.Text = "0" Or frmChild.txtHex.Text = "0" Then
                ChildForm.Close()
                intChildCount -= 1
            Else
                Dim answer As DialogResult = MessageBox.Show("Are you sure you want to close?", "Exit", MessageBoxButtons.YesNo)
                If answer = DialogResult.Yes Then
                    ChildForm.Close()
                    intChildCount -= 1
                Else

                End If
            End If
        Next
        If intChildCount = 0 Then
            Me.Close()
        End If
    End Sub

End Class
