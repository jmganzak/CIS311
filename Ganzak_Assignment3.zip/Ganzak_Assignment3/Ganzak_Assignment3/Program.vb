Imports System
Imports System.IO
Imports System.Text
Imports System.Text.RegularExpressions

Module Program

    '------------------------------------------------------------
    '-                File Name : Ganzak_Assignment3            - 
    '-                Part of Project: Global Variables         -
    '------------------------------------------------------------
    '-                Written By: Justin Ganzak                 -
    '-                Written On: January 28, 2022              -
    '------------------------------------------------------------
    '- File Purpose:                                            -
    '-                                                          -
    '- This file contains the main form for the entire appli-   -
    '- cation. All major variables are declared here. This      -
    '- reads a txt file and rites it into the console if the    -
    '- users decides on it. It also shows average words and most-
    '- used and least used words.                               -
    '------------------------------------------------------------
    '- Program Purpose:                                         -
    '-                                                          -
    '- The purpose of this program is to handle the a txt file  -
    '- and re print it into the console and another file.       -
    '- When reprinting it categorizes them alphabetically and   -
    '- counts how many times they are used.
    '------------------------------------------------------------
    '- Global Variable Dictionary (alphabetically):             -
    '-                                                          -
    '- dicWordDictionary - Holds all unique words and keeps     -
    '-          count of their interations in the txt file      -
    '- maxWords - Contains all the words used the most          -
    '- minWords - Contains all the words used the least         -  
    '- objReader - reads the file into the program              -
    '- objWriter - Writes the file into the new report txt      -
    '- strDisplay - Holds the new file contents to display in   -
    '-                          console at the end              -
    '- strReport - Holds the path of the new file               -
    '- strResponse - Holds if they say Y or N on seeing file    -
    '- strStore - Temporary store array of words                -
    '------------------------------------------------------------

    '---------------------------------------------------------------------------------------
    '--- GLOBAL CONSTANTS --- GLOBAL CONSTANTS --- GLOBAL CONSTANTS --- GLOBAL CONSTANTS ---
    '--- GLOBAL CONSTANTS --- GLOBAL CONSTANTS --- GLOBAL CONSTANTS --- GLOBAL CONSTANTS ---
    '--- GLOBAL CONSTANTS --- GLOBAL CONSTANTS --- GLOBAL CONSTANTS --- GLOBAL CONSTANTS ---
    '---------------------------------------------------------------------------------------
    Const intMaxStar As Integer = 50                        'Holds star values

    '---------------------------------------------------------------------------------------
    '--- GLOBAL VARIABLES --- GLOBAL VARIABLES --- GLOBAL VARIABLES --- GLOBAL VARIABLES ---
    '--- GLOBAL VARIABLES --- GLOBAL VARIABLES --- GLOBAL VARIABLES --- GLOBAL VARIABLES ---
    '--- GLOBAL VARIABLES --- GLOBAL VARIABLES --- GLOBAL VARIABLES --- GLOBAL VARIABLES ---
    '---------------------------------------------------------------------------------------

    Dim objReader As System.IO.StreamReader  'Reads File
    Dim objWriter As System.IO.StreamWriter    'Writes to file
    Dim strProcess As String 'test file
    Dim strReport As String ' report file
    Dim strStore As String 'temporary store
    Dim dicWordDictionary As New Dictionary(Of String, Integer)    'Word Dictionary
    Dim maxWords As ArrayList = New ArrayList()      'Array of words used the most
    Dim minWords As ArrayList = New ArrayList()      'Array of words used to the least
    Dim strResponse As String 'holds y/n
    Dim strDisplay As String 'holds final display

    '--- SUBPROGRAMS --- SUBPROGRAMS --- SUBPROGRAMS --- SUBPROGRAMS --- SUBPROGRAMS ---
    '--- SUBPROGRAMS --- SUBPROGRAMS --- SUBPROGRAMS --- SUBPROGRAMS --- SUBPROGRAMS ---
    '--- SUBPROGRAMS --- SUBPROGRAMS --- SUBPROGRAMS --- SUBPROGRAMS --- SUBPROGRAMS ---
    '-----------------------------------------------------------------------------------

    Sub OpenFile()     'Function for opening and reading the file

        '------------------------------------------------------------
        '-            Subprogram Name: OpenFile                     -
        '------------------------------------------------------------
        '-                Written By: Justin Ganzak                 -
        '-                Written On: January 28, 2022              -
        '------------------------------------------------------------
        '- Subprogram Purpose:                                      -
        '-                                                          -
        '- This subroutine focuses on reading the file that the user-
        '- inputs and storing the path to be used later. It also    -
        '- splits the words in the array and keeps count of their   -
        '- iterations.
        '------------------------------------------------------------
        '- Parameter Dictionary (in parameter order):               -
        '- (None)
        '------------------------------------------------------------
        '- Local Variable Dictionary (alphabetically):              -
        '- arrayString - Holds array of words from the given txt    -
        '- fileStream - Creates the new file for the text to go into-
        '------------------------------------------------------------


        Dim arrayString() As String

        objReader = New StreamReader(strProcess)                                'Read path from user input

        strStore = Regex.Replace(objReader.ReadLine().ToUpper, "[^A-Z\-\ /]", "").Trim()            'Spliting words by letters and trimming extra space

        strStore = Regex.Replace(strStore, " {2,}", " ")                        'Providing proper spacing

        arrayString = strStore.Split(" ")                       'Splitting array up

        Array.Sort(arrayString)                         'Sort Array Alphabetically

        For Each strString In arrayString
            If dicWordDictionary.ContainsKey(strString) Then
                dicWordDictionary(strString) += 1
                'Loop to check if the words math and if so add one to count
            Else
                dicWordDictionary.Add(strString, 1)
            End If
        Next
        Console.WriteLine(" ")
        Console.WriteLine(" ")
        Console.WriteLine("Processing Completed...")
        Console.WriteLine(" ")                                                                      'Handles outputting text into console
        Console.WriteLine(" ")
        Console.WriteLine("Please enter the path and name of the report file to generate:")
        strReport = Console.ReadLine()
        Dim fileStream As FileStream = File.Create(strReport)
        fileStream.Close()
        Console.WriteLine(" ")
        Console.WriteLine("Report File Generation Completed...")

    End Sub


    Sub createFile()

        '------------------------------------------------------------
        '-                Subprogram Name: createFile               -
        '------------------------------------------------------------
        '-                Written By: Justin Ganzak                 -
        '-                Written On: January 28, 2022              -
        '------------------------------------------------------------
        '- Subprogram Purpose:                                      -
        '-                                                          -
        '- This function writes the file to the new txt file as     -
        '- the user enters the path. It enters in all the words and -
        '- handles the output in the console
        '------------------------------------------------------------
        '- Parameter Dictionary (in parameter order):               -
        '- (None)                                                    -
        '------------------------------------------------------------
        '- Local Variable Dictionary (alphabetically):              -
        '- intStarNum -holds number of stars to be printed based on -
        '- equation down below.
        '------------------------------------------------------------


        objWriter = New StreamWriter(strReport)

        Console.WriteLine()

        Dim intStarNum As Integer = 0

        objWriter.WriteLine(StrDup(30, " ") & "Word Analysis Dictionary")
        objWriter.WriteLine(" ")
        objWriter.WriteLine("There were a total of " & dicWordDictionary.Count & " unique words encountered.")                  'Displays total unique words at end
        objWriter.WriteLine(" ")

        For Each strString In dicWordDictionary.Keys()
            intStarNum = Math.Round(dicWordDictionary(strString) / dicWordDictionary.Values.Max * intMaxStar)
            objWriter.WriteLine(String.Format("{0,-10}: {1:D4} {2}", strString, dicWordDictionary(strString), StrDup(intStarNum, "*")))         'Handles printing stars
            If dicWordDictionary(strString) = dicWordDictionary.Values.Max Then
                maxWords.Add(strString)
            ElseIf dicWordDictionary(strString) = dicWordDictionary.Values.Min Then
                minWords.Add(strString)
            End If

        Next
        objWriter.WriteLine(" ")
        objWriter.WriteLine("Average Word Utilization: " & dicWordDictionary.Values.Average)
        objWriter.WriteLine("Highest Word Utilization: " & dicWordDictionary.Values.Max & " on " & Strings.Join(maxWords.ToArray, ", "))            'Displaying avg,high,low at end
        objWriter.WriteLine("Lowest Word Utilization: " & dicWordDictionary.Values.Min & " on " & Strings.Join(minWords.ToArray, ", "))
        objWriter.WriteLine(" ")
        objWriter.WriteLine("Application Completed. Press any key to end ")
        objWriter.Close()
        viewFile()
    End Sub


    Sub viewFile()
        '------------------------------------------------------------
        '-                Subprogram Name: viewFile                 -
        '------------------------------------------------------------
        '-                Written By: Justin Ganzak                 -
        '-                Written On: January 28, 2022              -
        '------------------------------------------------------------
        '- Subprogram Purpose:                                      -
        '-                                                          -
        '- This function handles the user viewing the newely created-
        '- file.
        '------------------------------------------------------------
        '- Parameter Dictionary (in parameter order):               -
        '- (None)                                                   -
        '------------------------------------------------------------
        '- Local Variable Dictionary (alphabetically):              -
        '- (None)                                                   -
        '------------------------------------------------------------

        Console.WriteLine("Would you like to see the report file? [Y/n]")
        strResponse = Console.ReadLine()
        If strResponse.ToLower.Equals("y") Then
            strDisplay = IO.File.ReadAllText(strReport)
            Console.WriteLine(strDisplay)                                       'Checking if user wants to see the report file
        ElseIf strResponse.ToLower.Equals("n") Then
            Console.WriteLine("Application ended. Press any key to close")
        Else
            Console.WriteLine("Please enter either 'y' or 'n'")
            viewFile()
        End If


    End Sub



    Sub Main(args As String())
        '------------------------------------------------------------
        '-                Subprogram Name: Main                     -
        '------------------------------------------------------------
        '-                Written By: Justin Ganzak                 -
        '-                Written On: January 28, 2022              -
        '------------------------------------------------------------
        '- Subprogram Purpose:                                      -
        '-                                                          -
        '- This function handles clearing console and setting the   -
        '- correct colors of the console. Also checks if the file   -
        '- exists or not
        '------------------------------------------------------------
        '- Parameter Dictionary (in parameter order):               -
        '- args                                                     -
        '------------------------------------------------------------
        '- Local Variable Dictionary (alphabetically):              -
        '- (None)                                                   -
        '------------------------------------------------------------

        Console.Title = "Word Analysis Process Application"
        Console.BackgroundColor = ConsoleColor.White
        Console.ForegroundColor = ConsoleColor.Blue
        Console.Clear()

        Try
            Console.WriteLine("Please enter the path and name of the file to process: ")
            strProcess = Console.ReadLine()

            If System.IO.File.Exists(strProcess) = True Then                                    'Checking if path name is valid for txt file
                OpenFile()

                If System.IO.File.Exists(strReport) = True Then
                    createFile()
                End If
            Else
                Console.WriteLine("Processing Failed. Press any key to exit")
            End If

        Catch ex As Exception

        End Try

    End Sub


End Module
