Imports System
Imports System.IO
Imports System.Text
Imports System.Text.RegularExpressions

Module Program

    '------------------------------------------------------------
    '-                File Name : Assignment5.frm               - 
    '-                Part of Project: Book sorting             -
    '------------------------------------------------------------
    '-                Written By: Justin Ganzak                 -
    '-                Written On: February 23, 2022             -
    '------------------------------------------------------------
    '- File Purpose:                                            -
    '-                                                          -
    '- This file contains the main form for the entire appli-   -
    '- cation.  All user input is gathered on this form.  The   -
    '- calculations which are performed by the application      -
    '- reside in this file as well.  Finally all generated      -
    '- output is contained here too.                            -
    '------------------------------------------------------------
    '- Program Purpose:                                         -
    '-                                                          -
    '- The purpose of this program is to handle a txt file that -
    '- holds a list of books and this program sorts them by     -
    '- title, price, quantity, and genre. It displays the stats -
    '- about the books such as priciest and cheaptest, and the  -
    '- books that have the lowest quantity and highest quantity -
    '------------------------------------------------------------
    '- Global Variable Dictionary (alphabetically):             -
    '- book - List of books that holds all the books for use    -
    '- objReader - This handles reading in the txt file         -
    '- strBookArray - This holds the books in an array          -
    '- strBook - Holds the file after its read in               -
    '- strPath - Holds the path inputted by the user            -
    '------------------------------------------------------------
    '---------------------------------------------------------------------------------------
    '--- GLOBAL CONSTANTS --- GLOBAL CONSTANTS --- GLOBAL CONSTANTS --- GLOBAL CONSTANTS ---
    '--- GLOBAL CONSTANTS --- GLOBAL CONSTANTS --- GLOBAL CONSTANTS --- GLOBAL CONSTANTS ---
    '--- GLOBAL CONSTANTS --- GLOBAL CONSTANTS --- GLOBAL CONSTANTS --- GLOBAL CONSTANTS ---
    '---------------------------------------------------------------------------------------
    ' (None)                                                                               -
    '---------------------------------------------------------------------------------------


    '---------------------------------------------------------------------------------------
    '--- GLOBAL VARIABLES --- GLOBAL VARIABLES --- GLOBAL VARIABLES --- GLOBAL VARIABLES ---
    '--- GLOBAL VARIABLES --- GLOBAL VARIABLES --- GLOBAL VARIABLES --- GLOBAL VARIABLES ---
    '--- GLOBAL VARIABLES --- GLOBAL VARIABLES --- GLOBAL VARIABLES --- GLOBAL VARIABLES ---
    '---------------------------------------------------------------------------------------
    '- 
    Dim objReader As System.IO.StreamReader  'Reads File
    Dim strPath As String 'Path for file c:/temp/books.txt
    Dim strBook As String 'Actual file
    Dim strBookArray() As String       'Array of Books
    Dim book As New List(Of clsBook)            'Book list

    '--------------------------------------------------------------------------------------
    '--- GLOBAL CLASS --- GLOBAL CLASS --- GLOBAL CLASS --- GLOBAL CLASS --- GLOBAL CLASS -
    '--- GLOBAL CLASS --- GLOBAL CLASS --- GLOBAL CLASS --- GLOBAL CLASS --- GLOBAL CLASS -
    '--- GLOBAL CLASS --- GLOBAL CLASS --- GLOBAL CLASS --- GLOBAL CLASS --- GLOBAL CLASS -
    '--------------------------------------------------------------------------------------
    '- clsBook - This class handles all the parts of the books, like category quantity,etc-
    '- It is used for referencing in the queries later on in the code to allow each part  -
    '- to have its own property for future use                                            -
    '--------------------------------------------------------------------------------------
    Public Class clsBook                            'Book class
        Public Property strCategory As String       'Category 
        Public Property intQuantity As Integer       'Quantinty
        Public Property sngPrice As Single          'Price
        Public Property strTitle As String          'Title
        Public Property sngInventoryTotal As Single 'Amount

        '--- SUBPROGRAMS --- SUBPROGRAMS --- SUBPROGRAMS --- SUBPROGRAMS --- SUBPROGRAMS ---
        '--- SUBPROGRAMS --- SUBPROGRAMS --- SUBPROGRAMS --- SUBPROGRAMS --- SUBPROGRAMS ---
        '--- SUBPROGRAMS --- SUBPROGRAMS --- SUBPROGRAMS --- SUBPROGRAMS --- SUBPROGRAMS ---
        '-----------------------------------------------------------------------------------

        Public Sub New(ByVal Category As String, ByVal Quantity As Single, ByVal Price As Single, ByVal Title As String, ByVal Total As Single)
            '------------------------------------------------------------
            '-            Subprogram Name: Properties                   -
            '------------------------------------------------------------
            '-                Written By: Justin Ganzak                 -
            '-                Written On: February 23, 2022             -
            '------------------------------------------------------------
            '- Subprogram Purpose:                                      -
            '-                                                          -
            '- This subroutine sets the properties of the class equal to-
            '- the form to be accessed later. It sets each property as  -
            '- the correct data type ie string single, etc to allow them-
            '- to be accessed later and used properly. 
            '------------------------------------------------------------
            '- Parameter Dictionary (in parameter order):               -
            '- Category - Holds the books category as a String          -
            '- Quantity - Holds the number of books as a Single         -
            '- Price - Holds the price of the book as A single          -
            '- Title - Holds the title of each book as a String         -
            '- Total - Holds the total cost of the book as a Single
            '------------------------------------------------------------
            '- Local Variable Dictionary (alphabetically):              -
            '- (None)                                                   -
            '------------------------------------------------------------

            Me.strTitle = Title
            Me.strCategory = Category
            Me.sngInventoryTotal = Total        'Referenced notes, settings values
            Me.sngPrice = Price
            Me.intQuantity = Quantity
        End Sub

        Public Overrides Function ToString() As String
            '------------------------------------------------------------
            '-            Subprogram Name: Override ToString            -
            '------------------------------------------------------------
            '-                Written By: Justin Ganzak                 -
            '-                Written On: February 23, 2022             -
            '------------------------------------------------------------
            '- Subprogram Purpose:                                      -
            '-                                                          -
            '- This subroutine allows the contents of the clsBook to be -
            '- returned as a string and displayed properly when needed  -
            '------------------------------------------------------------
            '- Parameter Dictionary (in parameter order):               -
            '- (None)                                                   -
            '------------------------------------------------------------
            '- Local Variable Dictionary (alphabetically):              -
            '- (None)                                                   -
            '------------------------------------------------------------

            Return String.Format(" {0,-30}  {1,10} {2,10} {3,12} {4,15}",       'Set title to 0, Category to 1, quantity to 2, price to 3, Total to 4
        strTitle, strCategory, intQuantity, sngPrice, sngInventoryTotal)
        End Function

    End Class



    Sub openingHeader() 'Header subroutine
        '------------------------------------------------------------
        '-            Subprogram Name: Header                       -
        '------------------------------------------------------------
        '-                Written By: Justin Ganzak                 -
        '-                Written On: February 23, 2022             -
        '------------------------------------------------------------
        '- Subprogram Purpose:                                      -
        '-                                                          -
        '- This subroutine handles printing out the opening header  -
        '- of the program.                                          -
        '------------------------------------------------------------
        '- Parameter Dictionary (in parameter order):               -
        '- (None)                                                   -
        '------------------------------------------------------------
        '- Local Variable Dictionary (alphabetically):              -
        '- (None)                                                   -
        '------------------------------------------------------------

        Console.WriteLine(StrDup(51, " ") & "Books 'R' Us")
        Console.WriteLine(StrDup(45, " ") & "***  Inventory Report  ***")
        Console.WriteLine(StrDup(43, " ") & "-----------------------------")
        Console.WriteLine(" ")
        Console.WriteLine(StrDup(8, " ") & "Title" & StrDup(25, " ") & "Category" & "    Quantity" & "  Unit Cost" & "   Extended Cost")
        Console.WriteLine((StrDup(1, " ") & (StrDup(23, "-")) & "               " & "--------") & "  " & (StrDup(8, "-")) & "    " & (StrDup(9, "-")) & "   " & (StrDup(13, "-")))
    End Sub



    Sub displayFile()           'Displaying the file
        '------------------------------------------------------------
        '-            Subprogram Name: DisplayFile                  -
        '------------------------------------------------------------
        '-                Written By: Justin Ganzak                 -
        '-                Written On: February 23, 2022             -
        '------------------------------------------------------------
        '- Subprogram Purpose:                                      -
        '-                                                          -
        '- This subroutine handles displaying the files basic info  -
        '- and splits in up by spaces. It then adds a new element   -
        '- into clsBook which holds the title, quantity, etc info   -
        '- Lastly it calls the first query subroutine to begin      -
        '- pulling the information out
        '------------------------------------------------------------
        '- Parameter Dictionary (in parameter order):               -
        '- (None)                                                   -
        '------------------------------------------------------------
        '- Local Variable Dictionary (alphabetically):              -
        '- objReader - Reads in file path                           -
        '------------------------------------------------------------

        objReader = New StreamReader(strPath)
        Do Until objReader.EndOfStream          'Repeat until end of read file
            strBook = objReader.ReadLine()
            strBookArray = strBook.Split(" ", 4)       'Split the file and provide proper spacing
            book.Add(New clsBook(strBookArray(0), strBookArray(1), strBookArray(2), strBookArray(3), strBookArray(1) * strBookArray(2)))  'Title, Category, Quantity, Cost, Ext Cost
        Loop
        Query()     'Call query subroutine - display all the books their information
    End Sub



    Sub Query()
        '------------------------------------------------------------
        '-            Subprogram Name: Query                        -
        '------------------------------------------------------------
        '-                Written By: Justin Ganzak                 -
        '-                Written On: February 23, 2022             -
        '------------------------------------------------------------
        '- Subprogram Purpose:                                      -
        '-                                                          -
        '- This subroutine using LINQ to pull information from      -
        '- book list, and displays them alphabetically
        '------------------------------------------------------------
        '- Parameter Dictionary (in parameter order):               -
        '- (none)                                                   -
        '------------------------------------------------------------
        '- Local Variable Dictionary (alphabetically):              -
        '- everyBook - Holds all the books from the txt file        -
        '- tempBook - temp variable to hold books that qualify      -
        '------------------------------------------------------------

        Dim everyBook = From tempBook In book       'Go through every book in list, order by the title alphabetically, and display them
                        Order By tempBook.strTitle
        For Each tempBook In everyBook              'For each book, print it to console
            Console.WriteLine(tempBook.ToString)

        Next

        queryTwo() 'call query2 subroutine - books in 50 range


    End Sub



    Sub queryTwo() ' Handles books in low range ie <= 50
        '------------------------------------------------------------
        '-            Subprogram Name: queryTwo                     -
        '------------------------------------------------------------
        '-                Written By: Justin Ganzak                 -
        '-                Written On: February 23, 2022             -
        '------------------------------------------------------------
        '- Subprogram Purpose:                                      -
        '-                                                          -
        '- This subroutine using pulls all the books that are withtin-
        '- the price range of 50 or less. It orders them by price,  -
        '- and displays the book title and price in order. It also  -
        '- checks to see if there are any books in this range, and if-
        '- not it sends a message.
        '------------------------------------------------------------
        '- Parameter Dictionary (in parameter order):               -
        '- (none)                                                   -
        '------------------------------------------------------------
        '- Local Variable Dictionary (alphabetically):              -
        '- lowPriceBook - Holds all the books from the txt file     -
        '- tempLowPrice - temp variable to hold books that are within-
        '- the price range of 50 or less
        '------------------------------------------------------------
        Console.WriteLine(vbTab & vbTab & "-------------------------------------------------------------------------")
        Console.WriteLine(vbTab & vbTab & vbTab & "Total Inventory Value (Quantity * Unit Price) Statistics")           'Heading for Part 2
        Console.WriteLine(vbTab& & vbTab & "-------------------------------------------------------------------------")
        Console.WriteLine("Those books in the range of 0.00 - 50.00 are:")

        Dim lowPriceBook = From tempLowPrice In book                    'Query to find low price books
                           Order By tempLowPrice.sngInventoryTotal          'Order by total price
                           Where tempLowPrice.sngInventoryTotal <= 50.0         'Grab price <= 50
                           Select tempLowPrice.strTitle, tempLowPrice.sngInventoryTotal         'Select title and total
        If lowPriceBook.Count > 0 Then          'Loop to check if theres any books in this range, if not display no books
            For Each tempLowPrice In lowPriceBook
                Console.WriteLine(String.Format("{0, -40} Price: ${1, 5}", tempLowPrice.strTitle, tempLowPrice.sngInventoryTotal))
            Next
        Else
            Console.WriteLine(" ")
            Console.WriteLine("There are no books in this range")
        End If

        Console.WriteLine(" ")
        queryThree()    'Call query3 subroutine - books in 50 to 100

    End Sub



    Sub queryThree()            'Handles books in mid range ie 50 - 100
        '------------------------------------------------------------
        '-            Subprogram Name: queryThree                   -
        '------------------------------------------------------------
        '-                Written By: Justin Ganzak                 -
        '-                Written On: February 23, 2022             -
        '------------------------------------------------------------
        '- Subprogram Purpose:                                      -
        '-                                                          -
        '- This subroutine using LINQ grab all the books in the mid -
        '- price range ie 50 to 100 and display them by title and   -
        '- price. It also has a loop to check if any books are in this-
        '- category, and if not send a message
        '------------------------------------------------------------
        '- Parameter Dictionary (in parameter order):               -
        '- (none)                                                   -
        '------------------------------------------------------------
        '- Local Variable Dictionary (alphabetically):              -
        '- midPriceBook - Holds all the books from the txt file     -
        '- tempMidPrice - temp variable to hold books that are within-
        '- the price range of 50 to 100
        '------------------------------------------------------------
        Console.WriteLine("Those books in the range of 50.00 - 100.00 are:")
        Console.WriteLine(" ")
        Dim midPriceBook = From tempMidPrice In book            'Query for mid range books ie 50 to 100
                           Order By tempMidPrice.sngInventoryTotal      'Order by total price
                           Where tempMidPrice.sngInventoryTotal >= 50.0 And tempMidPrice.sngInventoryTotal <= 100.0 'Price >= 50 and <= 100
                           Select tempMidPrice.strTitle, tempMidPrice.sngInventoryTotal 'Select title and total
        If midPriceBook.Count > 0 Then      'Loop to check if theres any books in this range, if not display no books 
            For Each tempMidPrice In midPriceBook
                Console.WriteLine(String.Format("{0, -40} Price: ${1, 5}", tempMidPrice.strTitle, tempMidPrice.sngInventoryTotal))
            Next
        Else
            Console.WriteLine(" ")
            Console.WriteLine("There are no books in this range")
        End If
        Console.WriteLine(" ")
        queryFour() 'call query4 subroutine - books 100 to 150

    End Sub



    Sub queryFour()     'Handles books in price range of 100 to 150
        '------------------------------------------------------------
        '-            Subprogram Name: queryFour                    -
        '------------------------------------------------------------
        '-                Written By: Justin Ganzak                 -
        '-                Written On: February 23, 2022             -
        '------------------------------------------------------------
        '- Subprogram Purpose:                                      -
        '-                                                          -
        '- This subroutine using LINQ to grab books that are within -
        '- the price range of 100 to 150. It then orders them by price-
        '- and runs to loop to see if there any books in this range.-
        '- if not, display message
        '------------------------------------------------------------
        '- Parameter Dictionary (in parameter order):               -
        '- (none)                                                   -
        '------------------------------------------------------------
        '- Local Variable Dictionary (alphabetically):              -
        '- highPriceBook - Holds all the books from the txt file    -
        '- tempHighPrice - temp variable to hold books that qualify -
        '- in the price range of 100 to 150
        '------------------------------------------------------------
        Console.WriteLine("Those books in the range of 100.00 - 150.00 are:")
        Console.WriteLine(" ")
        Dim highPriceBook = From tempHighPrice In book          'Query for upper range books ie 100 to 150
                            Order By tempHighPrice.sngInventoryTotal        'Order by total price
                            Where tempHighPrice.sngInventoryTotal >= 100.0 And tempHighPrice.sngInventoryTotal <= 150.0 'Price >= 150
                            Select tempHighPrice.strTitle, tempHighPrice.sngInventoryTotal      'Select title and total
        If highPriceBook.Count > 0 Then 'Loop to check if theres any books in this range, if not display no books
            For Each tempHighPrice In highPriceBook
                Console.WriteLine(String.Format("{0, -40} Price: ${1, 5}", tempHighPrice.strTitle, tempHighPrice.sngInventoryTotal))
            Next
        Else
            Console.WriteLine(" ")
            Console.WriteLine("There are no books in this range")
        End If


        Console.WriteLine(" ")
        queryFive()  'Call query5 subroutine - Price 150 and above books


    End Sub

    Sub queryFive() 'handles books in price range of 150 and above
        '------------------------------------------------------------
        '-            Subprogram Name: queryFive                    -
        '------------------------------------------------------------
        '-                Written By: Justin Ganzak                 -
        '-                Written On: February 23, 2022             -
        '------------------------------------------------------------
        '- Subprogram Purpose:                                      -
        '-                                                          -
        '- This subroutine using LINQ to pull books within the price-
        '- range of 150 or above. It displays these by price and title-
        '- and has a loop to count the number of books. If there are-
        '- none, display message
        '------------------------------------------------------------
        '- Parameter Dictionary (in parameter order):               -
        '- (none)                                                   -
        '------------------------------------------------------------
        '- Local Variable Dictionary (alphabetically):              -
        '- highestPriceBook - Holds all the books from the txt file -
        '- tempHighestPrice - temp variable to hold books that      -
        '- are above the price range of 150 or more. 
        '------------------------------------------------------------
        Console.WriteLine("Those books in the range of 150.00 and above are:")
        Console.Write(" ")
        Dim highestPriceBook = From tempHighestPrice In book                'Query for highest price books >= 150
                               Order By tempHighestPrice.sngInventoryTotal          'Order by total price
                               Where tempHighestPrice.sngInventoryTotal >= 150.0            'Grab total price >= 150
                               Select tempHighestPrice.strTitle, tempHighestPrice.sngInventoryTotal     'Select Title and Total Price
        If highestPriceBook.Count > 0 Then      'This loop checks if there are any books in the price rane, if not display no books
            For Each tempHighestPrice In highestPriceBook
                Console.WriteLine(String.Format("{0, -40} Price: ${1, 5}", tempHighestPrice.strTitle, tempHighestPrice.sngInventoryTotal))
            Next
        Else
            Console.WriteLine(" ")
            Console.WriteLine("There are no books in this range")
            Console.WriteLine(" ")

        End If
        querySix() 'Call query six subroutine - Unit Price range by category
    End Sub

    Sub querySix()          'This query handles displaying unit price range stats
        '------------------------------------------------------------
        '-            Subprogram Name: querySix                     -
        '------------------------------------------------------------
        '-                Written By: Justin Ganzak                 -
        '-                Written On: February 23, 2022             -
        '------------------------------------------------------------
        '- Subprogram Purpose:                                      -
        '-                                                          -
        '- This subroutine using LINQ to pull the statistics of the -
        '- books and display them properly. It searches for books   -
        '- with the categories of F, S, N and displays the price,   -
        '- amount, low, avg, high of these categories.
        '------------------------------------------------------------
        '- Parameter Dictionary (in parameter order):               -
        '- (none)                                                   -
        '------------------------------------------------------------
        '- Local Variable Dictionary (alphabetically):              -
        '- fAvg - Holds the average of genre f                      -
        '- fCategory - holds list of books                          -
        '- fCategories - Holds books with genre f                   -
        '- fCatTotal - Holds total price of genre f books           -
        '- fMax - Holds max of genre f                              -
        '- fMin - holds min of genre f                              -
        '- nAvg - Holds avg of genre N                              -
        '- nCategory - Holds list of books                          -
        '- nCategories - holds list of books with genre N           -
        '- nCatTotal - Holds total of genre N                       -
        '- nMax - Holds max of genre N                              -
        '- nMin - Holds min of genre N                              -
        '- sAvg - Holds avg of Genre s                              -
        '- sCategory - holds list of books                          -
        '- sCategories - holds list of books in genre s             -
        '- sCatTotal - holds total of genre s                       -
        '- sMax - holds max of genre s                              -
        '- sMin - holds min of genre s                              -
        '------------------------------------------------------------
        Console.WriteLine(vbTab & vbTab & "-------------------------------------------------------------------------")
        Console.WriteLine(vbTab & vbTab & vbTab & vbTab & "Unit Price Range By Category Statistics")
        Console.WriteLine(vbTab & vbTab & "-------------------------------------------------------------------------")

        Dim Fcategory = From Fcategories In book            'Pull out any book in "f" category
                        Where Fcategories.strCategory = "F"
                        Select Fcategories

        Dim fMin = Aggregate Min In Fcategory       'Find min of Category f
                       Into Min(Min.sngPrice)
        Dim fMax = Aggregate Max In Fcategory       'Find max of category f
                       Into Max(Max.sngPrice)
        Dim fAvg = Aggregate Avg In Fcategory       'Find avg of category f
                       Into Average(Avg.sngPrice)
        Dim fCatTotal = Fcategory.Count             'Holds number of books in category
        Console.WriteLine(String.Format("{0, -15} {1, 10} {2, 20} {3, 20} {4, 20}", "Category", "# of Titles", "Low", "Ave", "High"))
        Console.WriteLine(String.Format("{0, -15} {1, 10} {2, 20} {3, 20} {4, 20}", "F", fCatTotal, fMin, Math.Round(fAvg, 2), fMax))

        Dim Ncategory = From Ncategories In book            'Pull out any book in "N" category
                        Where Ncategories.strCategory = "N"
                        Select Ncategories
        Dim nMin = Aggregate Min In Ncategory               'Find min of N
                       Into Min(Min.sngPrice)
        Dim nMax = Aggregate Max In Ncategory               'Find max of N
                       Into Max(Max.sngPrice)
        Dim nAvg = Aggregate Avg In Ncategory               'Find Avg of N
                       Into Average(Avg.sngPrice)
        Dim nCatTotal = Ncategory.Count                     'Count of books in N category
        Console.WriteLine(String.Format("{0, -15} {1, 10} {2, 20} {3, 20} {4, 20}", "N", nCatTotal, nMin, Math.Round(nAvg, 2), nMax))

        Dim sCategory = From Scategories In book            'Pull books in "S" category
                        Where Scategories.strCategory = "S"
                        Select Scategories

        Dim sMin = Aggregate Min In sCategory               'Find min of S
                       Into Min(Min.sngPrice)
        Dim sMax = Aggregate Max In sCategory               'FInd Max of S
                       Into Max(Max.sngPrice)
        Dim sAvg = Aggregate Avg In sCategory               'Find avg of S
                       Into Average(Avg.sngPrice)
        Dim sCatTotal = sCategory.Count                     'Count of books in S category
        Console.WriteLine(String.Format("{0, -15} {1, 10} {2, 20} {3, 20} {4, 20}", "S", sCatTotal, sMin, Math.Round(sAvg, 2), sMax))

        Console.WriteLine(" ")
        querySeven()                        'Call query 7 - Overall book stats
    End Sub

    Sub querySeven()        'Handles book statistics
        '------------------------------------------------------------
        '-            Subprogram Name: querySeven                   -
        '------------------------------------------------------------
        '-                Written By: Justin Ganzak                 -
        '-                Written On: February 23, 2022             -
        '------------------------------------------------------------
        '- Subprogram Purpose:                                      -
        '-                                                          -
        '- This subroutine using LINQ to pull the overall book stats-
        '- like cheapest, priceist, amount and display them by genre-
        '- They each have loops to display all the the books that   -
        '- meet these qualifications                                -
        '------------------------------------------------------------
        '- Parameter Dictionary (in parameter order):               -
        '- (none)                                                   -
        '------------------------------------------------------------
        '- Local Variable Dictionary (alphabetically):              -
        '- cheapestBooks - Holds list of books                      -
        '- cheapCategories - Holds list of books that qualify       -
        '- chCategories - temp variable that holds lowest price book-
        '- expensiveBooks - holds list of books                     -
        '- expensiveCategories - holds list of books that qualify   -
        '- exCategories - temp variable holds expensive books       -
        '- leastBooks - holds list of books                         -
        '- leastCat - holds list of books that qualify              -
        '- lCat - temp variable that holds least amounts books      -
        '- mostBooks - holds list of books                          -
        '- mostCat - holds list of books that qualify               -
        '- mCat - temp variable holds most amount of books          -
        '------------------------------------------------------------
        Console.WriteLine(vbTab & vbTab & "-------------------------------------------------------------------------")
        Console.WriteLine(vbTab & vbTab & vbTab & vbTab & "Overall Book Statistics")
        Console.WriteLine(vbTab & vbTab & "-------------------------------------------------------------------------")

        Dim cheapestBooks = Aggregate Min In book Into Min(Min.sngPrice)            'Find cheapest book
        Dim cheapCategories = From chCategories In book                     'Pull out cheapest books that match lowest price
                              Where chCategories.sngPrice = cheapestBooks
                              Select chCategories, chCategories.strTitle        'Select categories and title
        Console.WriteLine("The cheapest book title(s) at a unit price of $" & cheapestBooks & " are:")
        For Each cheap In cheapCategories       'Loop until each book is printed
            Console.WriteLine(cheap.strTitle)
        Next
        Console.WriteLine(" ")

        Dim expensiveBooks = Aggregate Max In book Into Max(Max.sngPrice)       'Find priciest book
        Dim expensiveCategories = From exCategories In book                     'Pull out expensive books that match
                                  Where exCategories.sngPrice = expensiveBooks
                                  Select exCategories, exCategories.strTitle        'Select category and title
        Console.WriteLine("The priciest book title(s) at a unit price of $" & expensiveBooks & " are:")
        For Each pricey In expensiveCategories          'Loop until each book is printed
            Console.WriteLine(pricey.strTitle)
        Next
        Console.WriteLine(" ")

        Dim leastBooks = Aggregate Count In book Into Min(Count.intQuantity)        'Find lowest quantity books
        Dim leastCat = From lCat In book
                       Where lCat.intQuantity = leastBooks          'Set the number value
                       Select lCat, lCat.strTitle
        Console.WriteLine("The title(s) with the least quantity on hand at " & leastBooks & " units are:")
        For Each least In leastCat              'Loop until all books are printed
            Console.WriteLine(least.strTitle)
        Next
        Console.WriteLine(" ")

        Dim mostBooks = Aggregate Count In book Into Max(Count.intQuantity)         'Find highest quantity books
        Dim mostCat = From mCat In book
                      Where mCat.intQuantity = mostBooks
                      Select mCat, mCat.strTitle
        Console.WriteLine("The title(s) with the most quantity on hand at " & mostBooks & " units are:")
        For Each most In mostCat                'Loop until all books printed
            Console.WriteLine(most.strTitle)
        Next

    End Sub

    Sub createFile()
        '------------------------------------------------------------
        '-            Subprogram Name: createFile                   -
        '------------------------------------------------------------
        '-                Written By: Justin Ganzak                 -
        '-                Written On: February 23, 2022             -
        '------------------------------------------------------------
        '- Subprogram Purpose:                                      -
        '-                                                          -
        '- This subroutine handles creating the basics of the file  -
        '- It calls the header routine and and display file routine -
        '------------------------------------------------------------
        '- Parameter Dictionary (in parameter order):               -
        '- (none)                                                   -
        '------------------------------------------------------------
        '- Local Variable Dictionary (alphabetically):              -
        '- (None)                                                   -
        '------------------------------------------------------------
        openingHeader()     'Call header subroutine
        displayFile()       'Call displayFile subroutine
        Console.WriteLine(" ")
        Console.WriteLine("Application Completed. Press any key to end ")
    End Sub

    Sub checkFile()
        '------------------------------------------------------------
        '-            Subprogram Name: checkFile                    -
        '------------------------------------------------------------
        '-                Written By: Justin Ganzak                 -
        '-                Written On: February 23, 2022             -
        '------------------------------------------------------------
        '- Subprogram Purpose:                                      -
        '-                                                          -
        '- This subroutine handles checking the user inputted file  -
        '- to check if the path or file name is valid. If not,      -
        '- end the application
        '------------------------------------------------------------
        '- Parameter Dictionary (in parameter order):               -
        '- (none)                                                   -
        '------------------------------------------------------------
        '- Local Variable Dictionary (alphabetically):              -
        '- (None)                                                   -
        '------------------------------------------------------------
        Try
            Console.WriteLine("Please enter the path and name of the file to process: ")
            strPath = Console.ReadLine()
            If File.Exists(strPath) Then               'Checking if path name is valid for txt file
                Console.WriteLine("Path exists... Generating File")
                Console.WriteLine(" ")
                createFile()        'If path exists, call createFile subroutine
            Else
                Console.WriteLine("Processing Failed. Press any key to exit")   'If file path is invalid, Display message and wait to end

            End If

        Catch ex As Exception

        End Try
    End Sub

    Sub Main(args As String())
        '------------------------------------------------------------
        '-            Subprogram Name: Main                         -
        '------------------------------------------------------------
        '-                Written By: Justin Ganzak                 -
        '-                Written On: February 23, 2022             -
        '------------------------------------------------------------
        '- Subprogram Purpose:                                      -
        '-                                                          -
        '- This subroutine handles configuring the console and calls-
        '- the first subroutine to begin the process of printing out-
        '- the information
        '------------------------------------------------------------
        '- Parameter Dictionary (in parameter order):               -
        '- args                                                     -
        '------------------------------------------------------------
        '- Local Variable Dictionary (alphabetically):              -
        '- (none)                                                  -
        '------------------------------------------------------------
        Console.Title = "Books 'R' Us Inventory Report"     'Title
        Console.BackgroundColor = ConsoleColor.Black        'Background to black
        Console.ForegroundColor = ConsoleColor.White        'Font Color to white
        Console.Clear()                                     'Clear console
        checkFile()                                         'Call subroutine to check file path
    End Sub

End Module