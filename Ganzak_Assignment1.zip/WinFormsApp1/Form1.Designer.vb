﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmPayrollSystem
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnCalc = New System.Windows.Forms.Button()
        Me.btnBack = New System.Windows.Forms.Button()
        Me.btnNext = New System.Windows.Forms.Button()
        Me.btnNew = New System.Windows.Forms.Button()
        Me.btnSave = New System.Windows.Forms.Button()
        Me.btnCancel = New System.Windows.Forms.Button()
        Me.chkSalary = New System.Windows.Forms.CheckBox()
        Me.lblName = New System.Windows.Forms.Label()
        Me.lblID = New System.Windows.Forms.Label()
        Me.lblHours = New System.Windows.Forms.Label()
        Me.lblWage = New System.Windows.Forms.Label()
        Me.txtName = New System.Windows.Forms.TextBox()
        Me.txtID = New System.Windows.Forms.TextBox()
        Me.txtHours = New System.Windows.Forms.TextBox()
        Me.txtWage = New System.Windows.Forms.TextBox()
        Me.lblOutput = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'btnCalc
        '
        Me.btnCalc.Location = New System.Drawing.Point(12, 175)
        Me.btnCalc.Name = "btnCalc"
        Me.btnCalc.Size = New System.Drawing.Size(342, 45)
        Me.btnCalc.TabIndex = 0
        Me.btnCalc.Text = "Calculate Wage"
        Me.btnCalc.UseVisualStyleBackColor = True
        '
        'btnBack
        '
        Me.btnBack.Location = New System.Drawing.Point(12, 226)
        Me.btnBack.Name = "btnBack"
        Me.btnBack.Size = New System.Drawing.Size(112, 48)
        Me.btnBack.TabIndex = 1
        Me.btnBack.Text = "<<"
        Me.btnBack.UseVisualStyleBackColor = True
        '
        'btnNext
        '
        Me.btnNext.Location = New System.Drawing.Point(242, 226)
        Me.btnNext.Name = "btnNext"
        Me.btnNext.Size = New System.Drawing.Size(112, 48)
        Me.btnNext.TabIndex = 2
        Me.btnNext.Text = ">>"
        Me.btnNext.UseVisualStyleBackColor = True
        '
        'btnNew
        '
        Me.btnNew.Location = New System.Drawing.Point(130, 226)
        Me.btnNew.Name = "btnNew"
        Me.btnNew.Size = New System.Drawing.Size(106, 48)
        Me.btnNew.TabIndex = 3
        Me.btnNew.Text = "Add New Employee"
        Me.btnNew.UseVisualStyleBackColor = True
        '
        'btnSave
        '
        Me.btnSave.Location = New System.Drawing.Point(12, 290)
        Me.btnSave.Name = "btnSave"
        Me.btnSave.Size = New System.Drawing.Size(138, 49)
        Me.btnSave.TabIndex = 4
        Me.btnSave.Text = "Save"
        Me.btnSave.UseVisualStyleBackColor = True
        '
        'btnCancel
        '
        Me.btnCancel.Location = New System.Drawing.Point(216, 290)
        Me.btnCancel.Name = "btnCancel"
        Me.btnCancel.Size = New System.Drawing.Size(138, 49)
        Me.btnCancel.TabIndex = 5
        Me.btnCancel.Text = "Cancel"
        Me.btnCancel.UseVisualStyleBackColor = True
        '
        'chkSalary
        '
        Me.chkSalary.AutoSize = True
        Me.chkSalary.Location = New System.Drawing.Point(12, 134)
        Me.chkSalary.Name = "chkSalary"
        Me.chkSalary.Size = New System.Drawing.Size(118, 19)
        Me.chkSalary.TabIndex = 6
        Me.chkSalary.Text = "Salaried Position?"
        Me.chkSalary.UseVisualStyleBackColor = True
        '
        'lblName
        '
        Me.lblName.AutoSize = True
        Me.lblName.Location = New System.Drawing.Point(13, 13)
        Me.lblName.Name = "lblName"
        Me.lblName.Size = New System.Drawing.Size(45, 15)
        Me.lblName.TabIndex = 7
        Me.lblName.Text = "Name :"
        '
        'lblID
        '
        Me.lblID.AutoSize = True
        Me.lblID.Location = New System.Drawing.Point(13, 42)
        Me.lblID.Name = "lblID"
        Me.lblID.Size = New System.Drawing.Size(24, 15)
        Me.lblID.TabIndex = 8
        Me.lblID.Text = "ID :"
        '
        'lblHours
        '
        Me.lblHours.AutoSize = True
        Me.lblHours.Location = New System.Drawing.Point(13, 74)
        Me.lblHours.Name = "lblHours"
        Me.lblHours.Size = New System.Drawing.Size(48, 15)
        Me.lblHours.TabIndex = 9
        Me.lblHours.Text = "Hours : "
        '
        'lblWage
        '
        Me.lblWage.AutoSize = True
        Me.lblWage.Location = New System.Drawing.Point(13, 103)
        Me.lblWage.Name = "lblWage"
        Me.lblWage.Size = New System.Drawing.Size(46, 15)
        Me.lblWage.TabIndex = 10
        Me.lblWage.Text = "Wage : "
        '
        'txtName
        '
        Me.txtName.Location = New System.Drawing.Point(97, 10)
        Me.txtName.Name = "txtName"
        Me.txtName.Size = New System.Drawing.Size(200, 23)
        Me.txtName.TabIndex = 11
        '
        'txtID
        '
        Me.txtID.Location = New System.Drawing.Point(97, 39)
        Me.txtID.Name = "txtID"
        Me.txtID.Size = New System.Drawing.Size(200, 23)
        Me.txtID.TabIndex = 12
        '
        'txtHours
        '
        Me.txtHours.Location = New System.Drawing.Point(97, 71)
        Me.txtHours.Name = "txtHours"
        Me.txtHours.Size = New System.Drawing.Size(200, 23)
        Me.txtHours.TabIndex = 13
        '
        'txtWage
        '
        Me.txtWage.Location = New System.Drawing.Point(97, 100)
        Me.txtWage.Name = "txtWage"
        Me.txtWage.Size = New System.Drawing.Size(200, 23)
        Me.txtWage.TabIndex = 14
        '
        'lblOutput
        '
        Me.lblOutput.AutoSize = True
        Me.lblOutput.Location = New System.Drawing.Point(206, 134)
        Me.lblOutput.Name = "lblOutput"
        Me.lblOutput.Size = New System.Drawing.Size(50, 15)
        Me.lblOutput.TabIndex = 15
        Me.lblOutput.Text = "lblWage"
        Me.lblOutput.Visible = False
        '
        'frmPayrollSystem
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 15.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(366, 364)
        Me.Controls.Add(Me.lblOutput)
        Me.Controls.Add(Me.txtWage)
        Me.Controls.Add(Me.txtHours)
        Me.Controls.Add(Me.txtID)
        Me.Controls.Add(Me.txtName)
        Me.Controls.Add(Me.lblWage)
        Me.Controls.Add(Me.lblHours)
        Me.Controls.Add(Me.lblID)
        Me.Controls.Add(Me.lblName)
        Me.Controls.Add(Me.chkSalary)
        Me.Controls.Add(Me.btnCancel)
        Me.Controls.Add(Me.btnSave)
        Me.Controls.Add(Me.btnNew)
        Me.Controls.Add(Me.btnNext)
        Me.Controls.Add(Me.btnBack)
        Me.Controls.Add(Me.btnCalc)
        Me.Name = "frmPayrollSystem"
        Me.Text = "Payroll System"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents btnCalc As Button
    Friend WithEvents btnBack As Button
    Friend WithEvents btnNext As Button
    Friend WithEvents btnNew As Button
    Friend WithEvents btnSave As Button
    Friend WithEvents btnCancel As Button
    Friend WithEvents chkSalary As CheckBox
    Friend WithEvents lblName As Label
    Friend WithEvents lblID As Label
    Friend WithEvents lblHours As Label
    Friend WithEvents lblWage As Label
    Friend WithEvents txtName As TextBox
    Friend WithEvents txtID As TextBox
    Friend WithEvents txtHours As TextBox
    Friend WithEvents txtWage As TextBox
    Friend WithEvents lblOutput As Label
End Class
