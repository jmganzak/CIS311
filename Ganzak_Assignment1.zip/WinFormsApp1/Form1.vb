﻿Public Class frmPayrollSystem
    '------------------------------------------------------------
    '-                File Name : Ganzak_Assignment1.frm        - 
    '-                Part of Project: Employee Information     -
    '------------------------------------------------------------
    '-                Written By: Justin Ganzak                 -
    '-                Written On: January 16, 2022              -
    '------------------------------------------------------------
    '- File Purpose:                                            -
    '-                                                          -
    '- This file contains the main form for the entire appli-   -
    '- cation.  All user input is gathered on this form.  The   -
    '- calculations which are performed by the application      -
    '- reside in this file as well.  Finally all generated      -
    '- output is contained here too.                            -
    '------------------------------------------------------------
    '- Program Purpose:                                         -
    '- The purpose of this program is to handle the calculations-
    '- of employees wages and their payout. It takes their hours-
    '- wages, ID, and Name to create a personal file for them to-
    '- access and view the data as needed. Once the data has    -
    '- been inputted the user can instruct the program to view  -
    '- select employees information at will. It calculates the  -
    '- employees payout based on salaries based pay or not, and -
    '- uses variables to hold the users information.
    '------------------------------------------------------------
    '- Global Variable Dictionary (alphabetically):             -
    '- count - This variable holds the total count of employees -
    '-                   to prevent users from going too far in -
    '-                   the count when going forward/backwards.-
    '- people - This variable acts as a counter for switching   -
    '-                   between tables and makign sure the user-
    '-                   does not go too far back or forward.   -
    '-                   It holds the current value or tab that -
    '-                   the user is currently on.              -
    '------------------------------------------------------------


    '-------------------------------------------------------------------------------------------
    '--- GLOBAL STRUCTURES --- GLOBAL STRUCTURES --- GLOBAL STRUCTURES --- GLOBAL STRUCTURES ---
    '--- GLOBAL STRUCTURES --- GLOBAL STRUCTURES --- GLOBAL STRUCTURES --- GLOBAL STRUCTURES ---
    '--- GLOBAL STRUCTURES --- GLOBAL STRUCTURES --- GLOBAL STRUCTURES --- GLOBAL STRUCTURES ---
    '-------------------------------------------------------------------------------------------

    'This structure will hold all information related to a given project that is being calculated
    'by the program.


    Structure udtEmployeeInfo
        Dim decWage As Decimal
        Dim strEmpName As String                                'Structure holds basic information for the program to allow future subroutines to access it
        Dim intID As Integer
        Dim decHours As Decimal
        Dim decTotal As Decimal
    End Structure

    Dim lstEmployees As New List(Of udtEmployeeInfo)
    Dim intIndex As Integer = 0


    '---------------------------------------------------------------------------------------
    '--- GLOBAL VARIABLES --- GLOBAL VARIABLES --- GLOBAL VARIABLES --- GLOBAL VARIABLES ---
    '--- GLOBAL VARIABLES --- GLOBAL VARIABLES --- GLOBAL VARIABLES --- GLOBAL VARIABLES ---
    '--- GLOBAL VARIABLES --- GLOBAL VARIABLES --- GLOBAL VARIABLES --- GLOBAL VARIABLES ---
    '---------------------------------------------------------------------------------------

    '- These variables hold the count for switching between tabs on all the employees currently stored within the program. 
    Public intPeople As Integer       'Serves as the current number or tab that the user is on.
    Public intCount As Integer        'Holds count of all the employees entered into the program.


    '--- SUBPROGRAMS --- SUBPROGRAMS --- SUBPROGRAMS --- SUBPROGRAMS --- SUBPROGRAMS ---
    '--- SUBPROGRAMS --- SUBPROGRAMS --- SUBPROGRAMS --- SUBPROGRAMS --- SUBPROGRAMS ---
    '--- SUBPROGRAMS --- SUBPROGRAMS --- SUBPROGRAMS --- SUBPROGRAMS --- SUBPROGRAMS ---
    '-----------------------------------------------------------------------------------

    Private Sub btnCalc_Click(sender As Object, e As EventArgs) Handles btnCalc.Click
        '------------------------------------------------------------
        '-            Subprogram Name: Calculate payout             -
        '------------------------------------------------------------
        '-                Written By: Justin Ganzak                 -
        '-                Written On: January 16, 2022              -
        '------------------------------------------------------------
        '- Subprogram Purpose:                                      -
        '-                                                          -
        '- This subroutine extracts the values entered from the user-
        '- into the form and places them in the global structure    –
        '- variable.  Any data conversions from string to numeric   -
        '- which are necessary are performed here as well.          -
        '------------------------------------------------------------
        '- Parameter Dictionary (in parameter order):               -
        '-                                                          -
        '------------------------------------------------------------
        '- Local Variable Dictionary (alphabetically):              -
        '- basepay - This variable holds the basepay for employees  -
        '-                     who are on salary pay and do not     -
        '-                     qualify for overtime.                -
        '- hours - This variable holds the number of hours worked   -
        '-                     that week by the user.               -
        '- ot - This variable is for calculating overtime pay when  -
        '-                     the user qualifies for it.           -
        '- total -The structure variable which contains             -
        '-                    all information for the project from  -
        '-                    which the program is creating a       -
        '-                    employee list.                        -
        '- wage - This variable holds the wage inputted from the    -
        '-                     user.                                -
        '-                                                          -
        '------------------------------------------------------------
        Dim decWage As Decimal = txtWage.Text      'Holds employees wage
        Dim decHours As Decimal = txtHours.Text    ' Holds the number of hours worked that week for said employee
        Dim decTotal As Decimal                    'Holds the total payout for the employee after calculations
        Dim decOt As Decimal                       'Holds OT payout after calculations for non-salary employees
        Dim decBasePay As Decimal = 40 * decWage      'Contains basepay for salary workers

        If chkSalary.Checked = False Then      'Checks if the salary box is checked or not, then proceeds if false
            If decHours > 40 Then                 'If the hours are over 40, they qualify for overtime
                decOt = decHours - 40
                decOt = (decWage * 1.5) * decOt
                decTotal = decTotal + decOt + decBasePay
            Else
                decTotal = decWage * decHours            'If not, then the total is just wage*hours
            End If
        Else
            decTotal = decWage * 40

        End If
        lblOutput.Text = "Employee is Due $" + CStr(decTotal)           'Output the total after calculations and make the label visible
        lblOutput.Visible = True
    End Sub

    Private Sub btnSave_Click(sender As Object, e As EventArgs) Handles btnSave.Click

        '------------------------------------------------------------
        '-                Subprogram Name: Save Data                -
        '------------------------------------------------------------
        '-                Written By: Justin Ganzak                 -
        '-                Written On: January 16, 2022              -
        '------------------------------------------------------------
        '- Subprogram Purpose:                                      -
        '-                                                          -
        '- This subroutine will generate a txt file to store  data  -
        '-                       inputted by the user and allow the -
        '-                       user to access the data at will.   -
        '-                       This lets the user switch between  -
        '-                       tabs on the program and view       -
        '-                       different employee profiles.       -
        '------------------------------------------------------------
        '- Parameter Dictionary (in parameter order):               -
        '- sender                                                   -
        '- e                                                        -
        '------------------------------------------------------------
        '- Local Variable Dictionary (alphabetically):              -
        '- Hours - Contains the hours worked this week inputted by  -
        '-                                the user. This is used for-
        '-                                future calculations.       -
        '- ID - This variable holds the ID number entered by the    -
        '-                                user for future use.      -
        '- List - This creates the file containing the employees    -
        '-                                information to be accessed-
        '-                                later in the program.     -
        '- name - This variable holds the name of the employee after-
        '-                                it is entered.            -
        '- Wage - Contains the wage of the employee entered by the  -
        '-                                user. It is used in       -
        '-                                calculating payout.       -
        '------------------------------------------------------------

        btnBack.Visible = True
        btnNext.Visible = True
        Dim strName As String = txtName.Text
        Dim intID As Integer = txtID.Text                           'Declare basic variables for holding information. 
        Dim decHours As Decimal = txtHours.Text                     'ID, name, wage, hours inputted by user.
        Dim decWage As Decimal = txtWage.Text
        Dim list As System.IO.StreamWriter                       'Create txt file to hold data saved from user and write the data to it.
        list = My.Computer.FileSystem.OpenTextFileWriter("C:\Users\jmganzak\source\repos\WinFormsApp1\file.txt", True)
        list.WriteLine(txtName.Text + vbTab + txtHours.Text + vbTab + txtWage.Text + vbTab + txtID.Text)
        list.Close()

        txtName.Text = strName
        txtID.Text = intID                                     'Setting text in text box to correct values.
        txtHours.Text = decHours
        txtWage.Text = decWage
        btnCancel.Visible = False
        btnSave.Visible = False
        btnBack.Visible = True
        btnNext.Visible = True                             'Changing visibility so certain buttons appear in certain situations.
        btnNew.Visible = True                              'Changing read only so the user does not overtype previous data.
        txtName.ReadOnly = True
        txtID.ReadOnly = True
        txtHours.ReadOnly = True
        txtWage.ReadOnly = True
        chkSalary.Enabled = False
        intCount = intCount + 1                                   'Increase total count of employees in system to keep track.
        Dim udtEmployee As New udtEmployeeInfo()
        udtEmployee.strEmpName = txtName.Text
        udtEmployee.intID = txtID.Text
        udtEmployee.decHours = txtHours.Text
        udtEmployee.decWage = txtWage.Text
        lstEmployees.Add(udtEmployee)
        viewEmployee(lstEmployees.Count - 1)
    End Sub
    Private Sub viewEmployee(intEmployeeIndex As Integer)
        '------------------------------------------------------------
        '-                Subprogram Name: Cancel New Entry         -
        '------------------------------------------------------------
        '-                Written By: Justin Ganzak                 -
        '-                Written On: January 16, 2022              -
        '------------------------------------------------------------
        '- Subprogram Purpose:                                      -
        '- This subroutine puts the info into a list to be accessed -
        '-                          by the program for future use.  -
        '------------------------------------------------------------
        '- Parameter Dictionary (in parameter order):               -
        '- intEmployeeIndex - Index to get list of employees        -
        '------------------------------------------------------------
        '- Local Variable Dictionary (alphabetically):              -
        '- (None)                                                   -
        '------------------------------------------------------------
        intIndex = intEmployeeIndex
        txtName.Text = lstEmployees(intEmployeeIndex).strEmpName
        txtHours.Text = lstEmployees(intEmployeeIndex).decHours 'Display proper form title with profile number on it
        txtID.Text = lstEmployees(intEmployeeIndex).intID
        txtWage.Text = lstEmployees(intEmployeeIndex).decWage
        Me.Text = "Payroll System - Employee " + (intIndex + 1).ToString + "/" + lstEmployees.Count.ToString
    End Sub


    Private Sub btnCancel_Click(sender As Object, e As EventArgs) Handles btnCancel.Click

        '------------------------------------------------------------
        '-                Subprogram Name: Cancel New Entry         -
        '------------------------------------------------------------
        '-                Written By: Justin Ganzak                 -
        '-                Written On: January 16, 2022              -
        '------------------------------------------------------------
        '- Subprogram Purpose:                                      -
        '-                                                          -
        '- This subroutine will clear the input boxes when the user -
        '-                      clicks the button. In doing so      -
        '-                      prevents data overlapping and keeps -
        '-                      the program running smoothly. Also, -
        '-                      notifies the user when they cancel  -
        '-                      the input of new employee data.     -
        '------------------------------------------------------------
        '- Parameter Dictionary (in parameter order):               -
        '- e                                                        -
        '- sender                                                   -
        '------------------------------------------------------------
        '- Local Variable Dictionary (alphabetically):              -
        '- (None)                                                   -
        '------------------------------------------------------------

        txtName.Text = " "
        txtID.Text = " "
        txtHours.Text = " "                         'Clear text boxes for future use
        txtWage.Text = " "
        chkSalary.Checked = False                   'Uncheck salary check box for future use
        MessageBox.Show("Addition of New Employee has been Canceled")               'Alert user that entry fields have been cleared
    End Sub

    Private Sub btnNew_Click(sender As Object, e As EventArgs) Handles btnNew.Click

        '------------------------------------------------------------
        '-                Subprogram Name: New Data Entry           -
        '------------------------------------------------------------
        '-                Written By: Justin Ganzak                 -
        '-                Written On: January 16, 2022              -
        '------------------------------------------------------------
        '- Subprogram Purpose:                                      -
        '-                                                          -
        '- This subroutine will change the program display to the   -
        '-                      new employee screen allowing the    -
        '-                      user to input new data into the     -
        '-                      system to be stored in the txt file.-
        '------------------------------------------------------------
        '- Parameter Dictionary (in parameter order):               -
        '- sender                                                   -
        '- e                                                        -
        '------------------------------------------------------------
        '- Local Variable Dictionary (alphabetically):              -
        '- Intpeople - This variables acts as a counter to add new  -
        '-                  employee entries into the system without-
        '-                  overcounting or undercounting.          -
        '------------------------------------------------------------

        intPeople = 0                                                  'Sets People counter to 0 for base set. 
        Me.Text = ("Payroll System - Add New Employee")             'Change form text to proper title
        txtName.Text = " "
        txtID.Text = " "
        txtHours.Text = " "
        txtWage.Text = " "
        chkSalary.Checked = False                                   '<-----
        lblOutput.Text = " "                                        '<-----
        txtName.ReadOnly = False                                    '<-----Clear text boxes for future usage and reset other input methods.
        txtID.ReadOnly = False                                      '<-----            
        txtHours.ReadOnly = False                                   '<-----
        txtWage.ReadOnly = False
        btnSave.Visible = True
        btnCancel.Visible = True
        chkSalary.Enabled = True

    End Sub


    Private Sub frmPayrollSystem_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        '------------------------------------------------------------
        '-                Subprogram Name: Initialize Program       -
        '------------------------------------------------------------
        '-                Written By: Justin Ganzak                 -
        '-                Written On: January 16, 2022              -
        '------------------------------------------------------------
        '- Subprogram Purpose:                                      -
        '-                                                          -
        '- This subroutine will set up the programs basics to ensure-
        '-                      that it can run properly upon       -
        '-                      launch. It sets the counters and    -
        '-                      changes the form title to the proper-
        '-                      name.                               -
        '------------------------------------------------------------
        '- Parameter Dictionary (in parameter order):               -
        '- sender                                                   -
        '- e                                                        -
        '------------------------------------------------------------
        '- Local Variable Dictionary (alphabetically):              -
        '- count - holds the total count of employees enetered into -
        '-                  into the program to maintain a proper   -
        '-                  total for switching between them.       -
        '- people - This variables acts as a counter to add new     -
        '-                  employee entries into the system without-
        '-                  overcounting or undercounting.          -
        '------------------------------------------------------------
        intPeople = 0
        intCount = 0                                                   'Set people and count to 0 to start and change visibility 
        btnNext.Visible = False
        btnBack.Visible = False
        btnNew.Visible = False
        Me.Text = "Payroll System - Add New Employee"               'Set form title to proper title on launch

    End Sub

    Private Sub btnNext_Click(sender As Object, e As EventArgs) Handles btnNext.Click

        '------------------------------------------------------------
        '-                Subprogram Name: Next Employee            -
        '------------------------------------------------------------
        '-                Written By: Justin Ganzak                 -
        '-                Written On: January 16, 2022              -
        '------------------------------------------------------------
        '- Subprogram Purpose:                                      -
        '-                                                          -
        '- This subroutine will manage the next button to allow the -
        '-                      user to move forward in between the -
        '-                      employee tabs. It prevents the user -
        '-                      from going to far, and only allows  -
        '-                      for the correct amount of profiles.  -
        '------------------------------------------------------------
        '- Parameter Dictionary (in parameter order):               -
        '- sender                                                   -
        '- e                                                        -
        '------------------------------------------------------------
        '- Local Variable Dictionary (alphabetically):              -
        '- (None)                                                   -
        '------------------------------------------------------------
        If intIndex < lstEmployees.Count - 1 Then        'Tests to if current active profile is less than the total to allow them to go to the next profile.
            viewEmployee(intIndex + 1)
        Else
            MessageBox.Show("You cannot move past the last record!") 'Alert user if they go too far forward
        End If


    End Sub

    Private Sub btnBack_Click(sender As Object, e As EventArgs) Handles btnBack.Click

        '------------------------------------------------------------
        '-                Subprogram Name: Previous Employee        -
        '------------------------------------------------------------
        '-                Written By: Justin Ganzak                 -
        '-                Written On: January 16, 2022              -
        '------------------------------------------------------------
        '- Subprogram Purpose:                                      -
        '-                                                          -
        '- This subroutine will manage the back button to allow the -
        '-                      user to move backwards  between the -
        '-                      employee tabs. It prevents the user -
        '-                      from going to far, and only allows  -
        '-                      for the correct amount of profiles. -
        '-                      If the user goes too far back, the  -
        '-                      user is notifed through a message.  -
        '------------------------------------------------------------
        '- Parameter Dictionary (in parameter order):               -
        '- sender                                                   -
        '- e                                                        -
        '------------------------------------------------------------
        '- Local Variable Dictionary (alphabetically):              -
        '- (None)                                                   -
        '------------------------------------------------------------

        If intIndex > 0 Then                             'Tests if count/people are at the correct count for switching tabs
            viewEmployee(intIndex - 1)
        Else
            MessageBox.Show("You cannot move past the first record!") 'Alert user if they go too far back
        End If

    End Sub
End Class
