﻿Public Class myClock

    '------------------------------------------------------------
    '-                File Name : myClock.frm                   - 
    '-                Part of Project: Clock                    -
    '------------------------------------------------------------
    '-                Written By: Justin Ganzak                 -
    '-                Written On: April 17, 2022                -
    '------------------------------------------------------------
    '- File Purpose:                                            -
    '-                                                          -
    '- This file contains the main form for the entire appli-   -
    '- cation.  It handles generating the control, and display the-
    '- information properly
    '------------------------------------------------------------
    '- Program Purpose:                                         -
    '-                                                          -
    '- The purpose of this program is to demonstrates controls  -
    '- in vb and how to create/use them
    '------------------------------------------------------------
    '- Global Variable Dictionary (alphabetically):             -
    '- ArialFont - Holds the font                               
    '- CurrentForceColor - Holds current color
    '- myBrush - Holds brush
    '------------------------------------------------------------

    '---------------------------------------------------------------------------------------
    '--- GLOBAL VARIABLES --- GLOBAL VARIABLES --- GLOBAL VARIABLES --- GLOBAL VARIABLES ---
    '--- GLOBAL VARIABLES --- GLOBAL VARIABLES --- GLOBAL VARIABLES --- GLOBAL VARIABLES ---
    '--- GLOBAL VARIABLES --- GLOBAL VARIABLES --- GLOBAL VARIABLES --- GLOBAL VARIABLES ---
    '---------------------------------------------------------------------------------------
    Dim ArialFont As New Font("Arial", 12, FontStyle.Regular)
    Dim myBrush As New SolidBrush(Color.Black)
    Dim CurrentForceColor As Color = Color.Black

    Public Overrides Property ForeColor As Color
        Get
            Return CurrentForceColor
        End Get
        Set(value As Color)
            CurrentForceColor = value
            'Me.Invalidate()
            Me.Refresh()
        End Set
    End Property

    '-----------------------------------------------------------------------------------
    '--- SUBPROGRAMS --- SUBPROGRAMS --- SUBPROGRAMS --- SUBPROGRAMS --- SUBPROGRAMS ---
    '--- SUBPROGRAMS --- SUBPROGRAMS --- SUBPROGRAMS --- SUBPROGRAMS --- SUBPROGRAMS ---
    '--- SUBPROGRAMS --- SUBPROGRAMS --- SUBPROGRAMS --- SUBPROGRAMS --- SUBPROGRAMS ---
    '-----------------------------------------------------------------------------------


    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick

        '------------------------------------------------------------
        '-            Subprogram Name: Timer1Tick                   -
        '------------------------------------------------------------
        '-                Written By: Justin Ganzak                 -
        '-                Written On: April 17, 2022                -
        '------------------------------------------------------------
        '- Subprogram Purpose:                                      -
        '-                                                          -
        '- This subroutine refreshes the control everytime to timer -
        '- ticks to keep it updated to the users reqeusts
        '------------------------------------------------------------
        '- Parameter Dictionary (in parameter order):               -
        '- sender
        '- e
        '------------------------------------------------------------
        '- Local Variable Dictionary (alphabetically):              -
        '- (None)                                                   -
        '------------------------------------------------------------


        Me.Refresh()

    End Sub

    Protected Overrides Sub OnPaint(e As PaintEventArgs)

        '------------------------------------------------------------
        '-            Subprogram Name: OnPaint                      -
        '------------------------------------------------------------
        '-                Written By: Justin Ganzak                 -
        '-                Written On: April 17, 2022                -
        '------------------------------------------------------------
        '- Subprogram Purpose:                                      -
        '-                                                          -
        '- This subroutine handles setting the graphics and brushcolor,-
        '- as well as actually drawing the clock. It pulls the other variables
        '- and uses the .DrawString to make it
        '------------------------------------------------------------
        '- Parameter Dictionary (in parameter order):               -
        '- e -
        '------------------------------------------------------------
        '- Local Variable Dictionary (alphabetically):              -
        '- (None)                                                   -
        '------------------------------------------------------------


        Dim myGfx As Graphics = e.Graphics
        myBrush.Color = CurrentForceColor
        myGfx.DrawString(DateTime.Now.ToLongTimeString, ArialFont, myBrush, 10, 10)
    End Sub

End Class
