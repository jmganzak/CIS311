﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.grpMain = New System.Windows.Forms.GroupBox()
        Me.btnSave = New System.Windows.Forms.Button()
        Me.btnCancel = New System.Windows.Forms.Button()
        Me.btnUpdate = New System.Windows.Forms.Button()
        Me.btnDelete = New System.Windows.Forms.Button()
        Me.btnAdd = New System.Windows.Forms.Button()
        Me.btnRight = New System.Windows.Forms.Button()
        Me.btnRightMax = New System.Windows.Forms.Button()
        Me.btnLeftMax = New System.Windows.Forms.Button()
        Me.btnLeft = New System.Windows.Forms.Button()
        Me.txtID = New System.Windows.Forms.TextBox()
        Me.txtZip = New System.Windows.Forms.TextBox()
        Me.txtState = New System.Windows.Forms.TextBox()
        Me.txtAddr = New System.Windows.Forms.TextBox()
        Me.txtCity = New System.Windows.Forms.TextBox()
        Me.txtLast = New System.Windows.Forms.TextBox()
        Me.txtFirst = New System.Windows.Forms.TextBox()
        Me.lblID = New System.Windows.Forms.Label()
        Me.lblAddress = New System.Windows.Forms.Label()
        Me.lblName = New System.Windows.Forms.Label()
        Me.dgvVehicles = New System.Windows.Forms.DataGridView()
        Me.grpMain.SuspendLayout()
        CType(Me.dgvVehicles, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'grpMain
        '
        Me.grpMain.Controls.Add(Me.btnSave)
        Me.grpMain.Controls.Add(Me.btnCancel)
        Me.grpMain.Controls.Add(Me.btnUpdate)
        Me.grpMain.Controls.Add(Me.btnDelete)
        Me.grpMain.Controls.Add(Me.btnAdd)
        Me.grpMain.Controls.Add(Me.btnRight)
        Me.grpMain.Controls.Add(Me.btnRightMax)
        Me.grpMain.Controls.Add(Me.btnLeftMax)
        Me.grpMain.Controls.Add(Me.btnLeft)
        Me.grpMain.Controls.Add(Me.txtID)
        Me.grpMain.Controls.Add(Me.txtZip)
        Me.grpMain.Controls.Add(Me.txtState)
        Me.grpMain.Controls.Add(Me.txtAddr)
        Me.grpMain.Controls.Add(Me.txtCity)
        Me.grpMain.Controls.Add(Me.txtLast)
        Me.grpMain.Controls.Add(Me.txtFirst)
        Me.grpMain.Controls.Add(Me.lblID)
        Me.grpMain.Controls.Add(Me.lblAddress)
        Me.grpMain.Controls.Add(Me.lblName)
        Me.grpMain.Location = New System.Drawing.Point(13, 13)
        Me.grpMain.Name = "grpMain"
        Me.grpMain.Size = New System.Drawing.Size(938, 357)
        Me.grpMain.TabIndex = 0
        Me.grpMain.TabStop = False
        Me.grpMain.Text = "Owner Information:"
        '
        'btnSave
        '
        Me.btnSave.Location = New System.Drawing.Point(445, 307)
        Me.btnSave.Name = "btnSave"
        Me.btnSave.Size = New System.Drawing.Size(94, 29)
        Me.btnSave.TabIndex = 15
        Me.btnSave.Text = "Save"
        Me.btnSave.UseVisualStyleBackColor = True
        '
        'btnCancel
        '
        Me.btnCancel.Location = New System.Drawing.Point(275, 307)
        Me.btnCancel.Name = "btnCancel"
        Me.btnCancel.Size = New System.Drawing.Size(94, 29)
        Me.btnCancel.TabIndex = 14
        Me.btnCancel.Text = "Cancel"
        Me.btnCancel.UseVisualStyleBackColor = True
        '
        'btnUpdate
        '
        Me.btnUpdate.Location = New System.Drawing.Point(525, 230)
        Me.btnUpdate.Name = "btnUpdate"
        Me.btnUpdate.Size = New System.Drawing.Size(108, 49)
        Me.btnUpdate.TabIndex = 11
        Me.btnUpdate.Text = "Update"
        Me.btnUpdate.UseVisualStyleBackColor = True
        '
        'btnDelete
        '
        Me.btnDelete.Location = New System.Drawing.Point(355, 230)
        Me.btnDelete.Name = "btnDelete"
        Me.btnDelete.Size = New System.Drawing.Size(108, 49)
        Me.btnDelete.TabIndex = 10
        Me.btnDelete.Text = "Delete"
        Me.btnDelete.UseVisualStyleBackColor = True
        '
        'btnAdd
        '
        Me.btnAdd.Location = New System.Drawing.Point(194, 230)
        Me.btnAdd.Name = "btnAdd"
        Me.btnAdd.Size = New System.Drawing.Size(108, 49)
        Me.btnAdd.TabIndex = 9
        Me.btnAdd.Text = "Add"
        Me.btnAdd.UseVisualStyleBackColor = True
        '
        'btnRight
        '
        Me.btnRight.Location = New System.Drawing.Point(773, 230)
        Me.btnRight.Name = "btnRight"
        Me.btnRight.Size = New System.Drawing.Size(37, 49)
        Me.btnRight.TabIndex = 12
        Me.btnRight.Text = ">>"
        Me.btnRight.UseVisualStyleBackColor = True
        '
        'btnRightMax
        '
        Me.btnRightMax.Location = New System.Drawing.Point(816, 230)
        Me.btnRightMax.Name = "btnRightMax"
        Me.btnRightMax.Size = New System.Drawing.Size(37, 49)
        Me.btnRightMax.TabIndex = 13
        Me.btnRightMax.Text = "|>"
        Me.btnRightMax.UseVisualStyleBackColor = True
        '
        'btnLeftMax
        '
        Me.btnLeftMax.Location = New System.Drawing.Point(51, 230)
        Me.btnLeftMax.Name = "btnLeftMax"
        Me.btnLeftMax.Size = New System.Drawing.Size(37, 49)
        Me.btnLeftMax.TabIndex = 7
        Me.btnLeftMax.Text = "<|"
        Me.btnLeftMax.UseVisualStyleBackColor = True
        '
        'btnLeft
        '
        Me.btnLeft.Location = New System.Drawing.Point(94, 230)
        Me.btnLeft.Name = "btnLeft"
        Me.btnLeft.Size = New System.Drawing.Size(37, 49)
        Me.btnLeft.TabIndex = 8
        Me.btnLeft.Text = "<<"
        Me.btnLeft.UseVisualStyleBackColor = True
        '
        'txtID
        '
        Me.txtID.Location = New System.Drawing.Point(816, 45)
        Me.txtID.Name = "txtID"
        Me.txtID.Size = New System.Drawing.Size(116, 27)
        Me.txtID.TabIndex = 9
        '
        'txtZip
        '
        Me.txtZip.Location = New System.Drawing.Point(500, 136)
        Me.txtZip.Name = "txtZip"
        Me.txtZip.Size = New System.Drawing.Size(133, 27)
        Me.txtZip.TabIndex = 6
        '
        'txtState
        '
        Me.txtState.Location = New System.Drawing.Point(390, 136)
        Me.txtState.Name = "txtState"
        Me.txtState.Size = New System.Drawing.Size(104, 27)
        Me.txtState.TabIndex = 5
        '
        'txtAddr
        '
        Me.txtAddr.Location = New System.Drawing.Point(141, 93)
        Me.txtAddr.Name = "txtAddr"
        Me.txtAddr.Size = New System.Drawing.Size(492, 27)
        Me.txtAddr.TabIndex = 3
        '
        'txtCity
        '
        Me.txtCity.Location = New System.Drawing.Point(141, 136)
        Me.txtCity.Name = "txtCity"
        Me.txtCity.Size = New System.Drawing.Size(243, 27)
        Me.txtCity.TabIndex = 4
        '
        'txtLast
        '
        Me.txtLast.Location = New System.Drawing.Point(390, 45)
        Me.txtLast.Name = "txtLast"
        Me.txtLast.Size = New System.Drawing.Size(243, 27)
        Me.txtLast.TabIndex = 2
        '
        'txtFirst
        '
        Me.txtFirst.Location = New System.Drawing.Point(141, 45)
        Me.txtFirst.Name = "txtFirst"
        Me.txtFirst.Size = New System.Drawing.Size(243, 27)
        Me.txtFirst.TabIndex = 1
        '
        'lblID
        '
        Me.lblID.AutoSize = True
        Me.lblID.Location = New System.Drawing.Point(725, 48)
        Me.lblID.Name = "lblID"
        Me.lblID.Size = New System.Drawing.Size(85, 20)
        Me.lblID.TabIndex = 2
        Me.lblID.Text = "ID Number:"
        '
        'lblAddress
        '
        Me.lblAddress.AutoSize = True
        Me.lblAddress.Location = New System.Drawing.Point(36, 100)
        Me.lblAddress.Name = "lblAddress"
        Me.lblAddress.Size = New System.Drawing.Size(65, 20)
        Me.lblAddress.TabIndex = 1
        Me.lblAddress.Text = "Address:"
        '
        'lblName
        '
        Me.lblName.AutoSize = True
        Me.lblName.Location = New System.Drawing.Point(36, 45)
        Me.lblName.Name = "lblName"
        Me.lblName.Size = New System.Drawing.Size(52, 20)
        Me.lblName.TabIndex = 0
        Me.lblName.Text = "Name:"
        '
        'dgvVehicles
        '
        Me.dgvVehicles.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgvVehicles.Location = New System.Drawing.Point(12, 376)
        Me.dgvVehicles.Name = "dgvVehicles"
        Me.dgvVehicles.ReadOnly = True
        Me.dgvVehicles.RowHeadersWidth = 51
        Me.dgvVehicles.RowTemplate.Height = 29
        Me.dgvVehicles.Size = New System.Drawing.Size(939, 276)
        Me.dgvVehicles.TabIndex = 1
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(963, 664)
        Me.Controls.Add(Me.dgvVehicles)
        Me.Controls.Add(Me.grpMain)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.grpMain.ResumeLayout(False)
        Me.grpMain.PerformLayout()
        CType(Me.dgvVehicles, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents grpMain As GroupBox
    Friend WithEvents btnLeftMax As Button
    Friend WithEvents btnLeft As Button
    Friend WithEvents txtID As TextBox
    Friend WithEvents txtZip As TextBox
    Friend WithEvents txtState As TextBox
    Friend WithEvents txtAddr As TextBox
    Friend WithEvents txtCity As TextBox
    Friend WithEvents txtLast As TextBox
    Friend WithEvents txtFirst As TextBox
    Friend WithEvents lblID As Label
    Friend WithEvents lblAddress As Label
    Friend WithEvents lblName As Label
    Friend WithEvents btnSave As Button
    Friend WithEvents btnCancel As Button
    Friend WithEvents btnUpdate As Button
    Friend WithEvents btnDelete As Button
    Friend WithEvents btnAdd As Button
    Friend WithEvents btnRight As Button
    Friend WithEvents btnRightMax As Button
    Friend WithEvents dgvVehicles As DataGridView
End Class
