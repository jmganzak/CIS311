﻿Imports System.Data.SqlClient

Public Class Form1

    '------------------------------------------------------------
    '-                File Name : frmMain.frm                   - 
    '-                Part of Project: SQL Databases            -
    '------------------------------------------------------------
    '-                Written By: Justin Ganzak                 -
    '-                Written On: April 2, 2022                 -
    '------------------------------------------------------------
    '- File Purpose:                                            -
    '-                                                          -
    '- This file contains the main form for the entire appli-   -
    '- cation.  This program handles adding, updating, deleting -
    ''- and changing data within a database through the app     -
    '------------------------------------------------------------
    '- Program Purpose:                                         -
    '-                                                          -
    '- The purpose of this program is to handle the changing of -
    '- owners.dbo and vehicles.dbo. It allows the user to add new-
    '- owners and edit/delete current ones
    '------------------------------------------------------------
    '- Global Variable Dictionary (alphabetically):             -
    '- DBAdaptOwners - Data adapter for Owners
    '- DBAdaptVehicles - Data adatper for Vehicles
    '- DBPath - File path
    '- dsOwners - Owners dataset
    '- dsVehicles - Vehicles Dataset
    '- intTemp - Temp variable used in saving
    '- strCONNECTION - Connection string
    '------------------------------------------------------------
    '---------------------------------------------------------------------------------------
    '--- GLOBAL CONSTANTS --- GLOBAL CONSTANTS --- GLOBAL CONSTANTS --- GLOBAL CONSTANTS ---
    '--- GLOBAL CONSTANTS --- GLOBAL CONSTANTS --- GLOBAL CONSTANTS --- GLOBAL CONSTANTS ---
    '--- GLOBAL CONSTANTS --- GLOBAL CONSTANTS --- GLOBAL CONSTANTS --- GLOBAL CONSTANTS ---
    '---------------------------------------------------------------------------------------

    Public Const strDBName As String = "Assign8"        'Database name
    Public Const strServer As String = "(localdb)\MSSQLLocalDB"         'Server location

    '---------------------------------------------------------------------------------------
    '--- GLOBAL VARIABLES --- GLOBAL VARIABLES --- GLOBAL VARIABLES --- GLOBAL VARIABLES ---
    '--- GLOBAL VARIABLES --- GLOBAL VARIABLES --- GLOBAL VARIABLES --- GLOBAL VARIABLES ---
    '--- GLOBAL VARIABLES --- GLOBAL VARIABLES --- GLOBAL VARIABLES --- GLOBAL VARIABLES ---
    '---------------------------------------------------------------------------------------


    Dim DBPath As String = My.Application.Info.DirectoryPath & "\" & strDBName & ".mdf"     'Path

    Dim strCONNECTION As String = "SERVER=" & strServer & ";DATABASE=" &                    'Connection String
                 strDBName & ";Integrated Security=SSPI;AttachDbFileName=" & DBPath


    Dim intTemp As Integer = 0          'Temp Counter variable
    Dim dsOwners As New DataSet         'Owner Database
    Dim dsVehicles As New DataSet       'Vehicle Database

    Dim DBAdaptOwners As SqlDataAdapter         'Adapter for Owners
    Dim DBAdaptVehicles As SqlDataAdapter       'Adapter for Vehicles

    '--- SUBPROGRAMS --- SUBPROGRAMS --- SUBPROGRAMS --- SUBPROGRAMS --- SUBPROGRAMS ---
    '--- SUBPROGRAMS --- SUBPROGRAMS --- SUBPROGRAMS --- SUBPROGRAMS --- SUBPROGRAMS ---
    '--- SUBPROGRAMS --- SUBPROGRAMS --- SUBPROGRAMS --- SUBPROGRAMS --- SUBPROGRAMS ---
    '-----------------------------------------------------------------------------------

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles Me.Load

        '------------------------------------------------------------
        '-            Subprogram Name: FormLoad                     -
        '------------------------------------------------------------
        '-                Written By: Justin Ganzak                 -
        '-                Written On: April 2, 2022                 -
        '------------------------------------------------------------
        '- Subprogram Purpose:                                      -
        '-                                                          -
        '- This subroutine handles setting up the data to be used   -
        '- and accessed later. It calls two subroutines to do so    -
        '------------------------------------------------------------
        '- Parameter Dictionary (in parameter order):               -
        '-e
        '- sender
        '------------------------------------------------------------
        '- Local Variable Dictionary (alphabetically):              -
        '- strSQLCommand - Holds the SQL command used in data adapter-
        '------------------------------------------------------------


        Dim strSQLCommand As String

        btnSave.Visible = False
        btnCancel.Visible = False
        txtFirst.Enabled = False
        txtLast.Enabled = False
        txtAddr.Enabled = False
        txtCity.Enabled = False
        txtZip.Enabled = False
        txtState.Enabled = False
        txtID.Enabled = False

        strSQLCommand = "SELECT * FROM Owners"
        DBAdaptOwners = New SqlDataAdapter(strSQLCommand, strCONNECTION)
        DBAdaptOwners.Fill(dsOwners, "Owners")

        bindData()
        fillDGV()

    End Sub

    Sub fillDGV()

        '------------------------------------------------------------
        '-            Subprogram Name: fillDGV                      -
        '------------------------------------------------------------
        '-                Written By: Justin Ganzak                 -
        '-                Written On: April 2, 2022                 -
        '------------------------------------------------------------
        '- Subprogram Purpose:                                      -
        '-                                                          -
        '- This subroutine handles setting up the datagridview so that-
        '- on load it displays the table properly
        '------------------------------------------------------------
        '- Parameter Dictionary (in parameter order):               -
        '-
        '------------------------------------------------------------
        '- Local Variable Dictionary (alphabetically):              -
        '- strSQLCommand - Holds the SQL command used in data adapter-
        '------------------------------------------------------------

        Dim strSQLCMD As String
        strSQLCMD = "SELECT Vehicles.OwnerID, Vehicles.Make, Vehicles.Model, Vehicles.Color, Vehicles.ModelYear, Vehicles.VIN FROM Vehicles"
        DBAdaptVehicles = New SqlDataAdapter(strSQLCMD, strCONNECTION)
        dsVehicles.Clear()
        DBAdaptVehicles.Fill(dsVehicles, "Vehicles")
        dgvVehicles.DataSource = dsVehicles.Tables("Vehicles")
    End Sub

    Private Sub btnRight_Click(sender As Object, e As EventArgs) Handles btnRight.Click
        '------------------------------------------------------------
        '-            Subprogram Name: Right                        -
        '------------------------------------------------------------
        '-                Written By: Justin Ganzak                 -
        '-                Written On: April 2, 2022                 -
        '------------------------------------------------------------
        '- Subprogram Purpose:                                      -
        '-                                                          -
        '- This subroutine handles moving right in the menu
        '------------------------------------------------------------
        '- Parameter Dictionary (in parameter order):               -
        '-
        '------------------------------------------------------------
        '- Local Variable Dictionary (alphabetically):              -
        '------------------------------------------------------------
        BindingContext(dsOwners, "Owners").Position = (BindingContext(dsOwners, "Owners").Position + 1)

    End Sub

    Private Sub btnLeft_Click(sender As Object, e As EventArgs) Handles btnLeft.Click
        '------------------------------------------------------------
        '-            Subprogram Name: Left                         -
        '------------------------------------------------------------
        '-                Written By: Justin Ganzak                 -
        '-                Written On: April 2, 2022                 -
        '------------------------------------------------------------
        '- Subprogram Purpose:                                      -
        '-                                                          -
        '- This subroutine handles moving left in the menu
        '------------------------------------------------------------
        '- Parameter Dictionary (in parameter order):               -
        '-
        '------------------------------------------------------------
        '- Local Variable Dictionary (alphabetically):              -
        '------------------------------------------------------------
        BindingContext(dsOwners, "Owners").Position = (BindingContext(dsOwners, "Owners").Position - 1)

    End Sub

    Private Sub btnRightMax_Click(sender As Object, e As EventArgs) Handles btnRightMax.Click
        '------------------------------------------------------------
        '-            Subprogram Name: Last                         -
        '------------------------------------------------------------
        '-                Written By: Justin Ganzak                 -
        '-                Written On: April 2, 2022                 -
        '------------------------------------------------------------
        '- Subprogram Purpose:                                      -
        '-                                                          -
        '- This subroutine handles moving to the last item in the menu
        '------------------------------------------------------------
        '- Parameter Dictionary (in parameter order):               -
        '-
        '------------------------------------------------------------
        '- Local Variable Dictionary (alphabetically):              -
        '------------------------------------------------------------
        BindingContext(dsOwners, "Owners").Position = dsOwners.Tables("Owners").Rows.Count - 1

    End Sub
    Private Sub btnLeftMax_Click(sender As Object, e As EventArgs) Handles btnLeftMax.Click
        '------------------------------------------------------------
        '-            Subprogram Name: First                        -
        '------------------------------------------------------------
        '-                Written By: Justin Ganzak                 -
        '-                Written On: April 2, 2022                 -
        '------------------------------------------------------------
        '- Subprogram Purpose:                                      -
        '-                                                          -
        '- This subroutine handles moving to the first Owner in the menu
        '------------------------------------------------------------
        '- Parameter Dictionary (in parameter order):               -
        '-
        '------------------------------------------------------------
        '- Local Variable Dictionary (alphabetically):              -
        '------------------------------------------------------------
        BindingContext(dsOwners, "Owners").Position = 0
        '
    End Sub

    Private Sub btnAdd_Click(sender As Object, e As EventArgs) Handles btnAdd.Click
        '------------------------------------------------------------
        '-            Subprogram Name: Add                      -
        '------------------------------------------------------------
        '-                Written By: Justin Ganzak                 -
        '-                Written On: April 2, 2022                 -
        '------------------------------------------------------------
        '- Subprogram Purpose:                                      -
        '-                                                          -
        '- This subroutine handles adding new users to the dataset.
        '- It sets intTemp = 1 for future use in save button
        '------------------------------------------------------------
        '- Parameter Dictionary (in parameter order):               -
        '- e
        '- sender
        '------------------------------------------------------------
        '- Local Variable Dictionary (alphabetically):
        '-control - Holds each txt box for changing text and enabled
        '------------------------------------------------------------
        intTemp = 1

        btnSave.Visible = True
        btnCancel.Visible = True
        txtFirst.Enabled = True
        txtLast.Enabled = True
        txtAddr.Enabled = True
        txtCity.Enabled = True
        txtZip.Enabled = True
        txtState.Enabled = True



        For Each control As Control In grpMain.Controls
            If control.GetType() Is GetType(TextBox) Then
                Dim txt As TextBox = control
                txt.Enabled = True
                txt.Text = ""
                txt.DataBindings.Clear()
            End If
        Next
        txtID.Enabled = False
        txtID.Text = dsOwners.Tables("Owners").Rows.Count + 1

    End Sub

    Private Sub btnCancel_Click(sender As Object, e As EventArgs) Handles btnCancel.Click

        '------------------------------------------------------------
        '-            Subprogram Name: Cancel                   -
        '------------------------------------------------------------
        '-                Written By: Justin Ganzak                 -
        '-                Written On: April 2, 2022                 -
        '------------------------------------------------------------
        '- Subprogram Purpose:                                      -
        '-                                                          -
        '- This subroutine handles canceling the update/adding of a user-
        '- It calls bind data after and resets the position of the Owners dataset
        '------------------------------------------------------------
        '- Parameter Dictionary (in parameter order):               -
        '- e
        '- sender
        '------------------------------------------------------------
        '- Local Variable Dictionary (alphabetically):              -
        '------------------------------------------------------------

        bindData()


        BindingContext(dsOwners, "Owners").Position = BindingContext(dsOwners, "Owners").Position

        btnSave.Visible = False
        btnCancel.Visible = False
        txtFirst.Enabled = False
        txtLast.Enabled = False
        txtAddr.Enabled = False
        txtCity.Enabled = False
        txtZip.Enabled = False
        txtState.Enabled = False
        txtID.Enabled = False
    End Sub

    Sub saveData()
        '------------------------------------------------------------
        '-            Subprogram Name: saveData                     -
        '------------------------------------------------------------
        '-                Written By: Justin Ganzak                 -
        '-                Written On: April 2, 2022                 -
        '------------------------------------------------------------
        '- Subprogram Purpose:                                      -
        '-                                                          -
        '- This subroutine handles saving user data based on intTemp's value
        '- If intTemp is one, it error checks and runs the code for saving/adding
        '- If intTemp is two, it handles updating the information
        '------------------------------------------------------------
        '- Parameter Dictionary (in parameter order):               -
        '
        '------------------------------------------------------------
        '- Local Variable Dictionary (alphabetically):              -
        '- strSQLCommand - Holds sqlcommand for data adapter
        '------------------------------------------------------------
        Dim strSQLCommand As String = ""

        If IsNumeric(txtFirst.Text) Or IsNumeric(txtLast.Text) Or IsNumeric(txtState.Text) Or IsNumeric(txtZip.Text) = False Then       'Data validation
            MessageBox.Show("Error, cannot have numbers in first name, last name, or state. Zipcode must be numeric")
        Else
            If intTemp = 1 Then         'Handles saving/adding

                strSQLCommand = "INSERT INTO dbo.Owners (TUID, FirstName, LastName, StreetAddress, City, State, ZipCode) VALUES ("
                strSQLCommand &= txtID.Text & ","
                strSQLCommand &= "N'" & txtFirst.Text.Trim & "',"
                strSQLCommand &= "N'" & txtLast.Text.Trim & "',"
                strSQLCommand &= "N'" & txtAddr.Text.Trim & "',"
                strSQLCommand &= "N'" & txtCity.Text.Trim & "',"
                strSQLCommand &= "N'" & txtState.Text.Trim & "',"
                strSQLCommand &= "N'" & txtZip.Text.Trim & "')"
                DBAdaptOwners.Update(dsOwners.Tables("Owners"))



            End If

            If intTemp = 2 Then         'Handles update
                strSQLCommand = "UPDATE dbo.Owners SET "
                strSQLCommand &= "FirstName = '" & txtFirst.Text.Trim & "',"
                strSQLCommand &= "LastName = '" & txtLast.Text.Trim & "',"
                strSQLCommand &= "StreetAddress = '" & txtAddr.Text.Trim & "',"
                strSQLCommand &= "City = '" & txtCity.Text.Trim & "',"
                strSQLCommand &= "State = '" & txtState.Text.Trim & "',"
                strSQLCommand &= "ZipCode = '" & txtZip.Text.Trim & "'"
                strSQLCommand &= "WHERE TUID = " & txtID.Text


            End If

            Try
                DBAdaptOwners = New SqlDataAdapter(strSQLCommand, strCONNECTION)
                DBAdaptOwners.Fill(dsOwners, "Owners")
            Catch ex As Exception
                MessageBox.Show("Error saving/updating data")
            End Try


            dsOwners.Clear()
            strSQLCommand = "SELECT * FROM Owners"
            DBAdaptOwners = New SqlDataAdapter(strSQLCommand, strCONNECTION)
            DBAdaptOwners.Fill(dsOwners, "Owners")


            bindData()

            saveVisibility()

            intTemp = 0

            BindingContext(dsOwners, "Owners").Position = BindingContext(dsOwners, "Owners").Position
        End If
    End Sub

    Private Sub btnSave_Click(sender As Object, e As EventArgs) Handles btnSave.Click
        '------------------------------------------------------------
        '-            Subprogram Name: SaveData                    -
        '------------------------------------------------------------
        '-                Written By: Justin Ganzak                 -
        '-                Written On: April 2, 2022                 -
        '------------------------------------------------------------
        '- Subprogram Purpose:                                      -
        '-                                                          -
        '- This subroutine handles error checking the users inputs and
        '- calling the right subroutine to handle adding/updating users
        '------------------------------------------------------------
        '- Parameter Dictionary (in parameter order):               -
        '- e
        '- sender
        '------------------------------------------------------------
        '- Local Variable Dictionary (alphabetically):              -
        '------------------------------------------------------------
        If String.IsNullOrEmpty(txtAddr.Text) Or String.IsNullOrEmpty(txtCity.Text) Or String.IsNullOrEmpty(txtFirst.Text) Or String.IsNullOrEmpty(txtLast.Text) Or String.IsNullOrEmpty(txtState.Text) Or String.IsNullOrEmpty(txtZip.Text) Then
            Dim result As DialogResult = MessageBox.Show("Fields are left blank, are you sure? ", "Proceed?", MessageBoxButtons.YesNo)
            If result = DialogResult.Yes Then
                saveData()
            Else

            End If

        Else
            saveData()
        End If

    End Sub

    Sub saveVisibility()
        '------------------------------------------------------------
        '-            Subprogram Name: saveVisibility               -
        '------------------------------------------------------------
        '-                Written By: Justin Ganzak                 -
        '-                Written On: April 2, 2022                 -
        '------------------------------------------------------------
        '- Subprogram Purpose:                                      -
        '-                                                          -
        '- This subroutine handles the visibility/enabled property of
        '- text boxes and buttons when clicking save or add/update
        '------------------------------------------------------------
        '- Parameter Dictionary (in parameter order):               -
        '-
        '------------------------------------------------------------
        '- Local Variable Dictionary (alphabetically):              -
        '------------------------------------------------------------
        btnSave.Visible = False
        btnCancel.Visible = False
        txtFirst.Enabled = False
        txtLast.Enabled = False
        txtAddr.Enabled = False
        txtCity.Enabled = False
        txtZip.Enabled = False
        txtState.Enabled = False
        txtID.Enabled = False
        btnRightMax.Enabled = True
        btnRight.Enabled = True
        btnLeft.Enabled = True
        btnLeftMax.Enabled = True
        btnAdd.Enabled = True
        btnDelete.Enabled = True
        btnUpdate.Enabled = True
    End Sub

    Sub bindData()
        '------------------------------------------------------------
        '-            Subprogram Name: bindData                     -
        '------------------------------------------------------------
        '-                Written By: Justin Ganzak                 -
        '-                Written On: April 2, 2022                 -
        '------------------------------------------------------------
        '- Subprogram Purpose:                                      -
        '-                                                          -
        '- This subroutine handles rebinding the txtBoxes to their 
        '- corresponding data to allow them to update when the user
        '- scrolls through. It checks if they have databinding, and if not rebind them
        '------------------------------------------------------------
        '- Parameter Dictionary (in parameter order):               -
        '------------------------------------------------------------
        '- Local Variable Dictionary (alphabetically):              -
        '------------------------------------------------------------
        If txtFirst.DataBindings.Count = 0 Or txtLast.DataBindings.Count = 0 Or txtAddr.DataBindings.Count = 0 Then         'Prevents errors
            txtFirst.DataBindings.Add(New Binding("Text", dsOwners, "Owners.FirstName"))
            txtLast.DataBindings.Add(New Binding("Text", dsOwners, "Owners.LastName"))
            txtAddr.DataBindings.Add(New Binding("Text", dsOwners, "Owners.StreetAddress"))             'Rebinding data
            txtCity.DataBindings.Add(New Binding("Text", dsOwners, "Owners.City"))
            txtState.DataBindings.Add(New Binding("Text", dsOwners, "Owners.State"))
            txtZip.DataBindings.Add(New Binding("Text", dsOwners, "Owners.ZipCode"))

            If txtID.DataBindings.Count = 0 Then
                txtID.DataBindings.Add(New Binding("Text", dsOwners, "Owners.TUID"))                    'Rebind ID
            End If


        End If

    End Sub

    Private Sub btnUpdate_Click(sender As Object, e As EventArgs) Handles btnUpdate.Click
        '------------------------------------------------------------
        '-            Subprogram Name: Update                       -
        '------------------------------------------------------------
        '-                Written By: Justin Ganzak                 -
        '-                Written On: April 2, 2022                 -
        '------------------------------------------------------------
        '- Subprogram Purpose:                                      -
        '-                                                          -
        '- This subroutine handles updating user data. It sets intTemp to 2
        '- which lets the save subroutine know what to call to allow the data
        '- to be manipulated properly
        '------------------------------------------------------------
        '- Parameter Dictionary (in parameter order):               -
        '- e
        '- sender
        '------------------------------------------------------------
        '- Local Variable Dictionary (alphabetically):              -
        '- control - Holds all txtBoxes and changes their properties
        '------------------------------------------------------------
        intTemp = 2

        updateVisibility()

        For Each control As Control In grpMain.Controls        'Enabling txtBoxes and clearing bindings
            If control.GetType() Is GetType(TextBox) Then      'if control is textbox
                Dim txt As TextBox = control
                If txt.Name <> txtID.Name Then
                    txt.Enabled = True                  'Enable and clear
                    txt.DataBindings.Clear()
                End If
            End If
        Next


    End Sub

    Private Sub btnDelete_Click(sender As Object, e As EventArgs) Handles btnDelete.Click

        '------------------------------------------------------------
        '-            Subprogram Name: Delete                       -
        '------------------------------------------------------------
        '-                Written By: Justin Ganzak                 -
        '-                Written On: April 2, 2022                 -
        '------------------------------------------------------------
        '- Subprogram Purpose:                                      -
        '-                                                          -
        '- This subroutine handles delete data from the owners dataset-
        '- It gives the user a choice, and if they select yes than it-
        '- deletes the specific entry where the TUID matches the IDtext.
        '- It then repopulates the table and keeps the information correct
        '------------------------------------------------------------
        '- Parameter Dictionary (in parameter order):               -
        '- e
        '- sender
        '------------------------------------------------------------
        '- Local Variable Dictionary (alphabetically):              -
        '- result - Holds users answer to yesno messagebox
        '- strSQLCommand - Holds deleting sql command
        '------------------------------------------------------------

        Dim result As DialogResult = MessageBox.Show("Are you sure you want to delete " & txtFirst.Text & " " & txtLast.Text & "?", "Are you sure?", MessageBoxButtons.YesNo)
        If result = DialogResult.Yes Then



            Dim strSQLCommand As String = "DELETE FROM dbo.Owners WHERE TUID = " & txtID.Text

            DBAdaptOwners = New SqlDataAdapter(strSQLCommand, strCONNECTION)
            DBAdaptOwners.Fill(dsOwners, "Owners")


            strSQLCommand = "DELETE FROM dbo.Vehicles WHERE OwnerID= " & txtID.Text
            DBAdaptVehicles = New SqlDataAdapter(strSQLCommand, strCONNECTION)
            DBAdaptVehicles.Fill(dsVehicles, "Vehicles")


            dsOwners.Clear()
            strSQLCommand = "SELECT * FROM Owners"
            DBAdaptOwners = New SqlDataAdapter(strSQLCommand, strCONNECTION)
            DBAdaptOwners.Fill(dsOwners, "Owners")


            dsVehicles.Clear()
            strSQLCommand = "SELECT * FROM Vehicles"
            DBAdaptVehicles = New SqlDataAdapter(strSQLCommand, strCONNECTION)
            DBAdaptVehicles.Fill(dsVehicles, "Vehicles")

            bindData()
            BindingContext(dsOwners, "Owners").Position = BindingContext(dsOwners, "Owners").Position

        End If

    End Sub

    Private Sub updateDGV() Handles txtID.TextChanged

        '------------------------------------------------------------
        '-            Subprogram Name: UpdateDGV                    -
        '------------------------------------------------------------
        '-                Written By: Justin Ganzak                 -
        '-                Written On: April 2, 2022                 -
        '------------------------------------------------------------
        '- Subprogram Purpose:                                      -
        '-                                                          -
        '- This subroutine handles updating the datagridview table  -
        '- when switching between users. It keeps the current ID information
        '- accurate and allows the user to properly display the info
        '------------------------------------------------------------
        '- Parameter Dictionary (in parameter order):               -
        '- e
        '- sender
        '------------------------------------------------------------
        '- Local Variable Dictionary (alphabetically):              -
        '- strSQL - Holds command for SQL
        '------------------------------------------------------------

        Dim strSQL As String
        strSQL = "Select Vehicles.OwnerID, Vehicles.Color, Vehicles.ModelYear, Vehicles.Make, Vehicles.Model, Vehicles.VIN from Vehicles Where OwnerId = '" & txtID.Text & "'"
        dsVehicles.Clear()

        DBAdaptVehicles = New SqlDataAdapter(strSQL, strCONNECTION)
        DBAdaptVehicles.Fill(dsVehicles, "Vehicles")
        dgvVehicles.DataSource = dsVehicles.Tables("Vehicles")

    End Sub

    Sub updateVisibility()

        '------------------------------------------------------------
        '-            Subprogram Name: updateVisibility()           -
        '------------------------------------------------------------
        '-                Written By: Justin Ganzak                 -
        '-                Written On: April 2, 2022                 -
        '------------------------------------------------------------
        '- Subprogram Purpose:                                      -
        '-                                                          -
        '- This subroutine handles updating the visibility and enabling/disabling
        '- certain buttons on call
        '------------------------------------------------------------
        '- Parameter Dictionary (in parameter order):               -
        '
        '------------------------------------------------------------
        '- Local Variable Dictionary (alphabetically):              -
        '------------------------------------------------------------

        btnSave.Visible = True
        btnCancel.Visible = True
        btnAdd.Enabled = False
        btnDelete.Enabled = False
        btnUpdate.Enabled = False
        btnLeftMax.Enabled = False
        btnRight.Enabled = False
        btnLeft.Enabled = False
        btnRightMax.Enabled = False
    End Sub


End Class

