﻿Public Class frmInvoice
    '------------------------------------------------------------
    '-                File Name : Assignment2.frm               - 
    '-                Part of Project: Invoice Form             -
    '------------------------------------------------------------
    '-                Written By: Justin Ganzak                 -
    '-                Written On: January 23, 2022              -
    '------------------------------------------------------------
    '- File Purpose:                                            -
    '-                                                          -
    '- This file contains the invoice form for handling closing -
    '- and switching back to the main form. It also handles     -
    '- exiting the program.
    '------------------------------------------------------------
    '- Program Purpose:                                         -
    '- The purpose of this program is to handle the exit button -
    '- and reset the program when submitting order. It also     -
    '- manages the change order button to ensure no data is lost-
    '------------------------------------------------------------
    '- Global Variable Dictionary (alphabetically):             -
    '- (None)                                                   -
    '------------------------------------------------------------


    Private Sub frmOrder_FormClosing(sender As Object, e As FormClosingEventArgs) Handles Me.FormClosing
        '------------------------------------------------------------
        '-            Subprogram Name: Closing Invoices             -
        '------------------------------------------------------------
        '-                Written By: Justin Ganzak                 -
        '-                Written On: January 24, 2022              -
        '------------------------------------------------------------
        '- Subprogram Purpose:                                      -
        '-                                                          -
        '- This subroutine handles the closing process and switching-
        '- in between forms. It prevents users from exiting without -
        '- pushing the exit button.                                 -
        '------------------------------------------------------------
        '- Parameter Dictionary (in parameter order):               -
        '- Sender - Raises the event to happen                      -
        '- e - Contains the data of event                           -
        '------------------------------------------------------------
        '- Local Variable Dictionary (alphabetically):              -
        '- (None)                                                   -
        '------------------------------------------------------------

        'On form closing action, check if other form is not visible, if its true, show messagebox with yes/no buttons.
        'If yes is picked, close the form. otherwise cancel it. 
        If Not (frmOrder.Visible) Then
            If MessageBox.Show("Are you sure you want to quit?", "Kustom Karz Order System", MessageBoxButtons.YesNo) = DialogResult.Yes Then
                frmOrder.Close()                'show message with yes/no buttons
            Else
                e.Cancel = True                 'Prevent user from closing
            End If
        End If
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        '------------------------------------------------------------
        '-            Subprogram Name: Exit Button Click            -
        '------------------------------------------------------------
        '-                Written By: Justin Ganzak                 -
        '-                Written On: January 24, 2022              -
        '------------------------------------------------------------
        '- Subprogram Purpose:                                      -
        '-                                                          -
        '- This subroutine handles the exit button that appears in  -
        '- this form. Allows the user to exit the app on click.     - 
        '------------------------------------------------------------
        '- Parameter Dictionary (in parameter order):               -
        '- Sender - Raises the event to happen                      -
        '- e - Contains the data of event                           -
        '------------------------------------------------------------
        '- Local Variable Dictionary (alphabetically):              -
        '- (None)                                                   -
        '------------------------------------------------------------
        Me.Close()
    End Sub

    Private Sub btnChange_Click(sender As Object, e As EventArgs) Handles btnChange.Click
        '------------------------------------------------------------
        '-            Subprogram Name: Closing Invoices             -
        '------------------------------------------------------------
        '-                Written By: Justin Ganzak                 -
        '-                Written On: January 24, 2022              -
        '------------------------------------------------------------
        '- Subprogram Purpose:                                      -
        '-                                                          -
        '- This subroutine handles the change order process when the-
        '- user wants to edit their current order. This sets the    -
        '- correct items visible or not and clears the list to ensur-
        '- it holda the correct items.
        '------------------------------------------------------------
        '- Parameter Dictionary (in parameter order):               -
        '- Sender - Raises the event to happen                      -
        '- e - Contains the data of event                           -
        '------------------------------------------------------------
        '- Local Variable Dictionary (alphabetically):              -
        '- (None)                                                   -
        '------------------------------------------------------------
        Me.Visible = False
        frmOrder.Visible = True
        lstInvoice.Items.Clear()                'Set invisible for this form, make other form visible, clear list and total.
        frmOrder.orderListOptions.Clear()
        frmOrder.Order.decTotal = 0
    End Sub

    Private Sub btnSubmit_Click(sender As Object, e As EventArgs) Handles btnSubmit.Click
        '------------------------------------------------------------
        '-            Subprogram Name: Submit Button                -
        '------------------------------------------------------------
        '-                Written By: Justin Ganzak                 -
        '-                Written On: January 24, 2022              -
        '------------------------------------------------------------
        '- Subprogram Purpose:                                      -
        '-                                                          -
        '- This subroutine handles submit to manufacturer process   -
        '- In doing so it clears and resets all the data to allow   -
        '- the user to resubmit another form and get a new invoice  -
        '------------------------------------------------------------
        '- Parameter Dictionary (in parameter order):               -
        '- Sender - Raises the event to happen                      -
        '- e - Contains the data of event                           -
        '------------------------------------------------------------
        '- Local Variable Dictionary (alphabetically):              -
        '- (None)                                                   -
        '------------------------------------------------------------
        Me.Visible = False
        frmOrder.Visible = True
        lstInvoice.Items.Clear()
        frmOrder.orderListOptions.Clear()
        frmOrder.Order.decTotal = 0
        frmOrder.radv12.Checked = True
        frmOrder.txtName.Text = " "
        frmOrder.lstType.ClearSelected()                'Clear list, uncheck all buttons, clear text bar, set quantity to 1, default check v-12
        frmOrder.chkAC.Checked = False
        frmOrder.chkAux.Checked = False
        frmOrder.chkBluetooth.Checked = False
        frmOrder.chkDefrost.Checked = False
        frmOrder.chkEntert.Checked = False
        frmOrder.chkGPS.Checked = False
        frmOrder.chkHeat.Checked = False
        frmOrder.chkLeather.Checked = False
        frmOrder.chkStereo.Checked = False
        frmOrder.updQuan.Value = 1
    End Sub
End Class