﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmOrder
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.updQuan = New System.Windows.Forms.NumericUpDown()
        Me.grpDrive = New System.Windows.Forms.GroupBox()
        Me.radElectric = New System.Windows.Forms.RadioButton()
        Me.radHybrid = New System.Windows.Forms.RadioButton()
        Me.radv4 = New System.Windows.Forms.RadioButton()
        Me.radv6 = New System.Windows.Forms.RadioButton()
        Me.radv8 = New System.Windows.Forms.RadioButton()
        Me.radv12 = New System.Windows.Forms.RadioButton()
        Me.lblName = New System.Windows.Forms.Label()
        Me.txtName = New System.Windows.Forms.TextBox()
        Me.lblType = New System.Windows.Forms.Label()
        Me.lblQuantity = New System.Windows.Forms.Label()
        Me.grpOptions = New System.Windows.Forms.GroupBox()
        Me.chkEntert = New System.Windows.Forms.CheckBox()
        Me.chkGPS = New System.Windows.Forms.CheckBox()
        Me.chkBluetooth = New System.Windows.Forms.CheckBox()
        Me.chkAux = New System.Windows.Forms.CheckBox()
        Me.chkStereo = New System.Windows.Forms.CheckBox()
        Me.chkAC = New System.Windows.Forms.CheckBox()
        Me.chkDefrost = New System.Windows.Forms.CheckBox()
        Me.chkHeat = New System.Windows.Forms.CheckBox()
        Me.chkLeather = New System.Windows.Forms.CheckBox()
        Me.btnOrder = New System.Windows.Forms.Button()
        Me.lstType = New System.Windows.Forms.ListBox()
        CType(Me.updQuan, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.grpDrive.SuspendLayout()
        Me.grpOptions.SuspendLayout()
        Me.SuspendLayout()
        '
        'updQuan
        '
        Me.updQuan.Location = New System.Drawing.Point(391, 78)
        Me.updQuan.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.updQuan.Name = "updQuan"
        Me.updQuan.ReadOnly = True
        Me.updQuan.Size = New System.Drawing.Size(120, 23)
        Me.updQuan.TabIndex = 3
        Me.updQuan.Value = New Decimal(New Integer() {1, 0, 0, 0})
        '
        'grpDrive
        '
        Me.grpDrive.Controls.Add(Me.radElectric)
        Me.grpDrive.Controls.Add(Me.radHybrid)
        Me.grpDrive.Controls.Add(Me.radv4)
        Me.grpDrive.Controls.Add(Me.radv6)
        Me.grpDrive.Controls.Add(Me.radv8)
        Me.grpDrive.Controls.Add(Me.radv12)
        Me.grpDrive.Location = New System.Drawing.Point(13, 130)
        Me.grpDrive.Name = "grpDrive"
        Me.grpDrive.Size = New System.Drawing.Size(509, 61)
        Me.grpDrive.TabIndex = 5
        Me.grpDrive.TabStop = False
        Me.grpDrive.Text = "Drive Train Selection :"
        '
        'radElectric
        '
        Me.radElectric.AutoSize = True
        Me.radElectric.Location = New System.Drawing.Point(416, 22)
        Me.radElectric.Name = "radElectric"
        Me.radElectric.Size = New System.Drawing.Size(63, 19)
        Me.radElectric.TabIndex = 5
        Me.radElectric.TabStop = True
        Me.radElectric.Text = "Electric"
        Me.radElectric.UseVisualStyleBackColor = True
        '
        'radHybrid
        '
        Me.radHybrid.AutoSize = True
        Me.radHybrid.Location = New System.Drawing.Point(328, 22)
        Me.radHybrid.Name = "radHybrid"
        Me.radHybrid.Size = New System.Drawing.Size(61, 19)
        Me.radHybrid.TabIndex = 4
        Me.radHybrid.TabStop = True
        Me.radHybrid.Text = "Hybrid"
        Me.radHybrid.UseVisualStyleBackColor = True
        '
        'radv4
        '
        Me.radv4.AutoSize = True
        Me.radv4.Location = New System.Drawing.Point(256, 22)
        Me.radv4.Name = "radv4"
        Me.radv4.Size = New System.Drawing.Size(43, 19)
        Me.radv4.TabIndex = 3
        Me.radv4.TabStop = True
        Me.radv4.Text = "V-4"
        Me.radv4.UseVisualStyleBackColor = True
        '
        'radv6
        '
        Me.radv6.AutoSize = True
        Me.radv6.Location = New System.Drawing.Point(180, 22)
        Me.radv6.Name = "radv6"
        Me.radv6.Size = New System.Drawing.Size(43, 19)
        Me.radv6.TabIndex = 2
        Me.radv6.TabStop = True
        Me.radv6.Text = "V-6"
        Me.radv6.UseVisualStyleBackColor = True
        '
        'radv8
        '
        Me.radv8.AutoSize = True
        Me.radv8.Location = New System.Drawing.Point(106, 22)
        Me.radv8.Name = "radv8"
        Me.radv8.Size = New System.Drawing.Size(43, 19)
        Me.radv8.TabIndex = 1
        Me.radv8.TabStop = True
        Me.radv8.Text = "V-8"
        Me.radv8.UseVisualStyleBackColor = True
        '
        'radv12
        '
        Me.radv12.AutoSize = True
        Me.radv12.Checked = True
        Me.radv12.Location = New System.Drawing.Point(37, 22)
        Me.radv12.Name = "radv12"
        Me.radv12.Size = New System.Drawing.Size(49, 19)
        Me.radv12.TabIndex = 0
        Me.radv12.TabStop = True
        Me.radv12.Text = "V-12"
        Me.radv12.UseVisualStyleBackColor = True
        '
        'lblName
        '
        Me.lblName.AutoSize = True
        Me.lblName.Location = New System.Drawing.Point(13, 13)
        Me.lblName.Name = "lblName"
        Me.lblName.Size = New System.Drawing.Size(100, 15)
        Me.lblName.TabIndex = 6
        Me.lblName.Text = "Customer Name :"
        '
        'txtName
        '
        Me.txtName.Location = New System.Drawing.Point(119, 12)
        Me.txtName.Name = "txtName"
        Me.txtName.Size = New System.Drawing.Size(403, 23)
        Me.txtName.TabIndex = 7
        '
        'lblType
        '
        Me.lblType.AutoSize = True
        Me.lblType.Location = New System.Drawing.Point(13, 80)
        Me.lblType.Name = "lblType"
        Me.lblType.Size = New System.Drawing.Size(58, 15)
        Me.lblType.TabIndex = 8
        Me.lblType.Text = "Car Type :"
        '
        'lblQuantity
        '
        Me.lblQuantity.AutoSize = True
        Me.lblQuantity.Location = New System.Drawing.Point(326, 80)
        Me.lblQuantity.Name = "lblQuantity"
        Me.lblQuantity.Size = New System.Drawing.Size(59, 15)
        Me.lblQuantity.TabIndex = 9
        Me.lblQuantity.Text = "Quantity :"
        '
        'grpOptions
        '
        Me.grpOptions.Controls.Add(Me.chkEntert)
        Me.grpOptions.Controls.Add(Me.chkGPS)
        Me.grpOptions.Controls.Add(Me.chkBluetooth)
        Me.grpOptions.Controls.Add(Me.chkAux)
        Me.grpOptions.Controls.Add(Me.chkStereo)
        Me.grpOptions.Controls.Add(Me.chkAC)
        Me.grpOptions.Controls.Add(Me.chkDefrost)
        Me.grpOptions.Controls.Add(Me.chkHeat)
        Me.grpOptions.Controls.Add(Me.chkLeather)
        Me.grpOptions.Location = New System.Drawing.Point(12, 206)
        Me.grpOptions.Name = "grpOptions"
        Me.grpOptions.Size = New System.Drawing.Size(510, 152)
        Me.grpOptions.TabIndex = 10
        Me.grpOptions.TabStop = False
        Me.grpOptions.Text = "Options : "
        '
        'chkEntert
        '
        Me.chkEntert.AutoSize = True
        Me.chkEntert.Location = New System.Drawing.Point(356, 99)
        Me.chkEntert.Name = "chkEntert"
        Me.chkEntert.Size = New System.Drawing.Size(148, 19)
        Me.chkEntert.TabIndex = 8
        Me.chkEntert.Text = "Entertainment Package"
        Me.chkEntert.UseVisualStyleBackColor = True
        '
        'chkGPS
        '
        Me.chkGPS.AutoSize = True
        Me.chkGPS.Location = New System.Drawing.Point(356, 58)
        Me.chkGPS.Name = "chkGPS"
        Me.chkGPS.Size = New System.Drawing.Size(47, 19)
        Me.chkGPS.TabIndex = 7
        Me.chkGPS.Text = "GPS"
        Me.chkGPS.UseVisualStyleBackColor = True
        '
        'chkBluetooth
        '
        Me.chkBluetooth.AutoSize = True
        Me.chkBluetooth.Location = New System.Drawing.Point(356, 23)
        Me.chkBluetooth.Name = "chkBluetooth"
        Me.chkBluetooth.Size = New System.Drawing.Size(78, 19)
        Me.chkBluetooth.TabIndex = 6
        Me.chkBluetooth.Text = "Bluetooth"
        Me.chkBluetooth.UseVisualStyleBackColor = True
        '
        'chkAux
        '
        Me.chkAux.AutoSize = True
        Me.chkAux.Location = New System.Drawing.Point(181, 99)
        Me.chkAux.Name = "chkAux"
        Me.chkAux.Size = New System.Drawing.Size(141, 19)
        Me.chkAux.TabIndex = 5
        Me.chkAux.Text = "CD/MP3 Connections"
        Me.chkAux.UseVisualStyleBackColor = True
        '
        'chkStereo
        '
        Me.chkStereo.AutoSize = True
        Me.chkStereo.Location = New System.Drawing.Point(181, 58)
        Me.chkStereo.Name = "chkStereo"
        Me.chkStereo.Size = New System.Drawing.Size(111, 19)
        Me.chkStereo.TabIndex = 4
        Me.chkStereo.Text = "Premium Stereo"
        Me.chkStereo.UseVisualStyleBackColor = True
        '
        'chkAC
        '
        Me.chkAC.AutoSize = True
        Me.chkAC.Location = New System.Drawing.Point(181, 22)
        Me.chkAC.Name = "chkAC"
        Me.chkAC.Size = New System.Drawing.Size(114, 19)
        Me.chkAC.TabIndex = 3
        Me.chkAC.Text = "Air Conditioning"
        Me.chkAC.UseVisualStyleBackColor = True
        '
        'chkDefrost
        '
        Me.chkDefrost.AutoSize = True
        Me.chkDefrost.Location = New System.Drawing.Point(16, 99)
        Me.chkDefrost.Name = "chkDefrost"
        Me.chkDefrost.Size = New System.Drawing.Size(100, 19)
        Me.chkDefrost.TabIndex = 2
        Me.chkDefrost.Text = "Rear Defroster"
        Me.chkDefrost.UseVisualStyleBackColor = True
        '
        'chkHeat
        '
        Me.chkHeat.AutoSize = True
        Me.chkHeat.Location = New System.Drawing.Point(16, 58)
        Me.chkHeat.Name = "chkHeat"
        Me.chkHeat.Size = New System.Drawing.Size(94, 19)
        Me.chkHeat.TabIndex = 1
        Me.chkHeat.Text = "Heated Seats"
        Me.chkHeat.UseVisualStyleBackColor = True
        '
        'chkLeather
        '
        Me.chkLeather.AutoSize = True
        Me.chkLeather.Location = New System.Drawing.Point(17, 23)
        Me.chkLeather.Name = "chkLeather"
        Me.chkLeather.Size = New System.Drawing.Size(95, 19)
        Me.chkLeather.TabIndex = 0
        Me.chkLeather.Text = "Leather Seats"
        Me.chkLeather.UseVisualStyleBackColor = True
        '
        'btnOrder
        '
        Me.btnOrder.Location = New System.Drawing.Point(29, 375)
        Me.btnOrder.Name = "btnOrder"
        Me.btnOrder.Size = New System.Drawing.Size(482, 42)
        Me.btnOrder.TabIndex = 11
        Me.btnOrder.Text = "Place Car(s) Order"
        Me.btnOrder.UseVisualStyleBackColor = True
        '
        'lstType
        '
        Me.lstType.FormattingEnabled = True
        Me.lstType.ItemHeight = 15
        Me.lstType.Items.AddRange(New Object() {"Coupe", "Luxury", "Sedan", "Sports Edition", "SUV"})
        Me.lstType.Location = New System.Drawing.Point(77, 67)
        Me.lstType.Name = "lstType"
        Me.lstType.Size = New System.Drawing.Size(128, 34)
        Me.lstType.TabIndex = 12
        '
        'frmOrder
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 15.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(532, 440)
        Me.Controls.Add(Me.lstType)
        Me.Controls.Add(Me.btnOrder)
        Me.Controls.Add(Me.grpOptions)
        Me.Controls.Add(Me.lblQuantity)
        Me.Controls.Add(Me.lblType)
        Me.Controls.Add(Me.txtName)
        Me.Controls.Add(Me.lblName)
        Me.Controls.Add(Me.grpDrive)
        Me.Controls.Add(Me.updQuan)
        Me.Name = "frmOrder"
        Me.Text = "Kustom Karz Order Form"
        CType(Me.updQuan, System.ComponentModel.ISupportInitialize).EndInit()
        Me.grpDrive.ResumeLayout(False)
        Me.grpDrive.PerformLayout()
        Me.grpOptions.ResumeLayout(False)
        Me.grpOptions.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents updQuan As NumericUpDown
    Friend WithEvents grpDrive As GroupBox
    Friend WithEvents radv12 As RadioButton
    Friend WithEvents lblName As Label
    Friend WithEvents txtName As TextBox
    Friend WithEvents radElectric As RadioButton
    Friend WithEvents radHybrid As RadioButton
    Friend WithEvents radv4 As RadioButton
    Friend WithEvents radv6 As RadioButton
    Friend WithEvents radv8 As RadioButton
    Friend WithEvents lblType As Label
    Friend WithEvents lblQuantity As Label
    Friend WithEvents grpOptions As GroupBox
    Friend WithEvents chkEntert As CheckBox
    Friend WithEvents chkGPS As CheckBox
    Friend WithEvents chkBluetooth As CheckBox
    Friend WithEvents chkAux As CheckBox
    Friend WithEvents chkStereo As CheckBox
    Friend WithEvents chkAC As CheckBox
    Friend WithEvents chkDefrost As CheckBox
    Friend WithEvents chkHeat As CheckBox
    Friend WithEvents chkLeather As CheckBox
    Friend WithEvents btnOrder As Button
    Friend WithEvents lstType As ListBox
End Class
