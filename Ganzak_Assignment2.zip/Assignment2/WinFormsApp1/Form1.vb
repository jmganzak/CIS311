﻿Public Class frmOrder

    '------------------------------------------------------------
    '-                File Name : Assignment2.frm               - 
    '-                Part of Project: Order Form               -
    '------------------------------------------------------------
    '-                Written By: Justin Ganzak                 -
    '-                Written On: January 23, 2022              -
    '------------------------------------------------------------
    '- File Purpose:                                            -
    '-                                                          -
    '- This file contains the main form for the entire appli-   -
    '- cation.  This file gathers user input on this form which -
    '- communications with the second form in order to properly -
    '- run and produce the invoice.  Finally all generated      -
    '- output is contained here too.                            -
    '------------------------------------------------------------
    '- Program Purpose:                                         -
    '- The purpose of this program is to simulate a website in  -
    '- which a user can order a car and specify the type, model,-
    '- add ons, and more. After selecting all this the user can -
    '- submit this to recieve an invoice containing the total $.-
    '------------------------------------------------------------
    '- Global Variable Dictionary (alphabetically):             -
    '- orderListOptions - Array list which holds the add ons    -
    '-                that the user selects to put on his or her-
    '-                car to be calculated for future use in the-
    '-                program.                                  -
    '- order - Holds the structure in and contains variables.   -
    '------------------------------------------------------------

    '---------------------------------------------------------------------------------------
    '--- GLOBAL CONSTANTS --- GLOBAL CONSTANTS --- GLOBAL CONSTANTS --- GLOBAL CONSTANTS ---
    '--- GLOBAL CONSTANTS --- GLOBAL CONSTANTS --- GLOBAL CONSTANTS --- GLOBAL CONSTANTS ---
    '--- GLOBAL CONSTANTS --- GLOBAL CONSTANTS --- GLOBAL CONSTANTS --- GLOBAL CONSTANTS ---
    '---------------------------------------------------------------------------------------

    Public Const decOptions As Decimal = 750    'Default value for all additional options that the user may add on
    Public Const decCoupe As Decimal = 10000    'Coupe price
    Public Const decLuxury As Decimal = 20000   'Luxury price
    Public Const decSedan As Decimal = 17000    'Sedan Price
    Public Const decSports As Decimal = 25000   'Sports Price
    Public Const decSuv As Decimal = 27000      'SUV price
    Public Const decV12 As Decimal = 7500       'V12 Price
    Public Const decV8 As Decimal = 2500        'V8 Price
    Public Const decV6 As Decimal = 1000        'V6 Price
    Public Const decV4 As Decimal = 500         'V4 Price
    Public Const decHybrid As Decimal = 3000    'Hybrid price
    Public Const decElectric As Decimal = 6000  'Electric price

    '-------------------------------------------------------------------------------------------
    '--- GLOBAL STRUCTURES --- GLOBAL STRUCTURES --- GLOBAL STRUCTURES --- GLOBAL STRUCTURES ---
    '--- GLOBAL STRUCTURES --- GLOBAL STRUCTURES --- GLOBAL STRUCTURES --- GLOBAL STRUCTURES ---
    '--- GLOBAL STRUCTURES --- GLOBAL STRUCTURES --- GLOBAL STRUCTURES --- GLOBAL STRUCTURES ---
    '-------------------------------------------------------------------------------------------
    'this structure holds all data related to the invoice and holds the values for future calculations
    Public Structure OrderFor
        Dim strName As String           'Name of user
        Dim intQuantity As Integer      'Amount of cars selected 
        Dim strCarType As String        'Type of car
        Dim strDriveTrain As String     'Drive train option selected
        Dim strOptions As String        'Options selected
        Dim decTotal As Decimal         'Total cost
        Dim decTypeCost As Decimal      'Type of car cost
        Dim decOptionCost As Decimal    'Options cost
        Dim dblDriveTrain As Double     'Drive Train Cost
    End Structure

    Public Order As OrderFor

    Public orderListOptions As ArrayList = New ArrayList()     'Array for options selected for car

    '--- SUBPROGRAMS --- SUBPROGRAMS --- SUBPROGRAMS --- SUBPROGRAMS --- SUBPROGRAMS ---
    '--- SUBPROGRAMS --- SUBPROGRAMS --- SUBPROGRAMS --- SUBPROGRAMS --- SUBPROGRAMS ---
    '--- SUBPROGRAMS --- SUBPROGRAMS --- SUBPROGRAMS --- SUBPROGRAMS --- SUBPROGRAMS ---
    '-----------------------------------------------------------------------------------

    Private Sub frmOrder_FormClosing(sender As Object, e As FormClosingEventArgs) Handles Me.FormClosing
        '------------------------------------------------------------
        '-            Subprogram Name: Form Closing                 -
        '------------------------------------------------------------
        '-                Written By: Justin Ganzak                 -
        '-                Written On: January 23, 2022              -
        '------------------------------------------------------------
        '- Subprogram Purpose:                                      -
        '-                                                          -
        '- This subroutine checks when closing if the invoice form  -
        '- is not visible, and then displays a message to prevent   –
        '- the user from exiting without pressing the exit button.  -
        '------------------------------------------------------------
        '- Parameter Dictionary (in parameter order):               -
        '- sender                                                   -
        '- e - The form itself
        '------------------------------------------------------------
        '- Local Variable Dictionary (alphabetically):              -
        '- (None)                                                   -
        '------------------------------------------------------------

        'Check if invoice form is visible, if its not then show message box and prevent closing of the program
        If Not (frmInvoice.Visible) Then
            MessageBox.Show("Sorry but the application can only be closed on the Invoice Screen. Please press 'Place Order' to go to that screen.")
            e.Cancel = True
        End If

    End Sub


    Private Sub btnOrder_Click(sender As Object, e As EventArgs) Handles btnOrder.Click

        '------------------------------------------------------------
        '-            Subprogram Name: Order Button                 -
        '------------------------------------------------------------
        '-                Written By: Justin Ganzak                 -
        '-                Written On: January 23, 2022              -
        '------------------------------------------------------------
        '- Subprogram Purpose:                                      -
        '-                                                          -
        '- This subroutine handles the order button. When pressed   -
        '- it checks which buttons/check buttons are pressed and    –
        '- allocates the correct amount of cost to the variables for-
        '- future use in the program. It also calls one functions,  -
        '- isValid(), which checks if the syntax inputted is correct-
        '------------------------------------------------------------
        '- Parameter Dictionary (in parameter order):               -
        '- sender                                                   -
        '- e - The form itself
        '------------------------------------------------------------
        '- Local Variable Dictionary (alphabetically):              -
        '- intCount - This acts as a counter for the quantity to    -
        '- ensure that the correct amount is multiplied when calc.  -
        '- the total cost.
        '------------------------------------------------------------

        Order.intQuantity = updQuan.Value                   'Setting quantity
        Order.strCarType = lstType.SelectedItem             'Setting car type to selected type
        Order.strName = txtName.Text                        'Setting name

        If lstType.SelectedItem = "Coupe" Then
            Order.decTypeCost = decCoupe                'Check for coupe and add costs
            Order.decTotal += decCoupe
        End If

        If lstType.SelectedItem = "Luxury" Then         'Check for Luxury and add costs
            Order.decTypeCost = decLuxury
            Order.decTotal += decLuxury
        End If

        If lstType.SelectedItem = "Sports Edition" Then     'Check for Sports and add costs
            Order.decTypeCost = decSports
            Order.decTotal += decSports
        End If

        If lstType.SelectedItem = "SUV" Then                'Check for SUV and add costs
            Order.decTypeCost = decSuv
            Order.decTotal += decSuv
        End If

        If lstType.SelectedItem = "Sedan" Then              'Check for sedan and add costs
            Order.decTypeCost = decSedan
            Order.decTotal += decSedan
        End If

        If radv12.Checked = True Then                   'If v12 checked set variable and add cost
            Order.strDriveTrain = "V-12"
            Order.dblDriveTrain = decV12
            Order.decTotal += decV12
        End If

        If radv8.Checked = True Then                    'If v8 checked set variable and add cost
            Order.strDriveTrain = "V-8"
            Order.dblDriveTrain = decV8
            Order.decTotal += decV8
        End If

        If radv6.Checked = True Then                    'If v6 checked set variable and add cost
            Order.strDriveTrain = "V-6"
            Order.dblDriveTrain = decV6
            Order.decTotal += decV6
        End If

        If radv4.Checked = True Then                    'If v4 checked set variable and add cost
            Order.strDriveTrain = "V-4"
            Order.dblDriveTrain = decV4
            Order.decTotal += decV4
        End If

        If radHybrid.Checked = True Then                'If hybrid checked set variable and add cost
            Order.strDriveTrain = "Hybrid"
            Order.dblDriveTrain = decHybrid
            Order.decTotal += decHybrid
        End If

        If radElectric.Checked = True Then              'If electric checked set variable and add cost
            Order.strDriveTrain = "Electric"
            Order.dblDriveTrain = decElectric
            Order.decTotal += decElectric
        End If


        Dim intCount As Integer = 0                     'Declare count variable and set value to 0


        If chkLeather.Checked = True Then
            orderListOptions.Add("Leather Seats")
            Order.decTotal = Order.decTotal + decOptions        'Checking whats options are checked and adding cost/setting variables. Increase count by 1 if checked.
            intCount = intCount + 1                             'Leather Seats option
        End If

        If chkHeat.Checked = True Then                          'Heated Seat Option
            orderListOptions.Add("Heated Seats")
            Order.decTotal = Order.decTotal + decOptions
            intCount = intCount + 1
        End If

        If chkDefrost.Checked = True Then                       'Rear Defrost Option 
            orderListOptions.Add("Rear Defroster")
            Order.decTotal = Order.decTotal + decOptions
            intCount = intCount + 1
        End If

        If chkAC.Checked = True Then                            'Air Conditioning Option
            orderListOptions.Add("Air Conditioning")
            Order.decTotal = Order.decTotal + decOptions
            intCount = intCount + 1
        End If

        If chkStereo.Checked = True Then                        'Premium Stereo System Option
            orderListOptions.Add("Premium Stereo")
            Order.decTotal = Order.decTotal + decOptions
            intCount = intCount + 1
        End If

        If chkAux.Checked = True Then                           'CD/MP3 Option
            orderListOptions.Add("CD/MP3 Connections")
            Order.decTotal = Order.decTotal + decOptions
            intCount = intCount + 1
        End If

        If chkBluetooth.Checked = True Then                     'Bluetooth Option
            orderListOptions.Add("Bluetooth")
            Order.decTotal = Order.decTotal + decOptions
            intCount = intCount + 1
        End If

        If chkGPS.Checked = True Then                           'GPS Option
            orderListOptions.Add("GPS")
            Order.decTotal = Order.decTotal + decOptions
            intCount = intCount + 1
        End If

        If chkEntert.Checked = True Then                        'Entertainment System Option
            orderListOptions.Add("Entertainment Package")
            Order.decTotal = Order.decTotal + decOptions
            intCount = intCount + 1
        End If


        Order.decOptionCost = decOptions * intCount             'Set number of options selected * counter = decOptionCost

        isValid()                                               'Validate data

    End Sub

    Private Sub generateInvoice()

        '------------------------------------------------------------
        '-            Subprogram Name: Generate Invoice             -
        '------------------------------------------------------------
        '-                Written By: Justin Ganzak                 -
        '-                Written On: January 24, 2022              -
        '------------------------------------------------------------
        '- Subprogram Purpose:                                      -
        '-                                                          -
        '- This subroutine handles generating the invoice and pullin-
        '- the correct variables inserting them into the lstbox so  -
        ''- the invoice has all the items. 
        '------------------------------------------------------------
        '- Parameter Dictionary (in parameter order):               -
        '- (None)                                                   -
        '------------------------------------------------------------
        '- Local Variable Dictionary (alphabetically):              -
        '- intCount - This acts as a counter for the quantity to    -
        '- ensure that the correct amount is multiplied when calc.  -
        '- the total cost.                                          -
        '------------------------------------------------------------


        'This section prints out the invoice and pulls the correct variables
        frmInvoice.lstInvoice.Items.Add("===================================================")
        frmInvoice.lstInvoice.Items.Add(StrDup(60, " ") & "Kustom Karz Order")
        frmInvoice.lstInvoice.Items.Add("===================================================")
        frmInvoice.lstInvoice.Items.Add(" ")
        frmInvoice.lstInvoice.Items.Add("Getting ready to kustom manufacture for " + CStr(Order.strName))
        frmInvoice.lstInvoice.Items.Add(" ")
        frmInvoice.lstInvoice.Items.Add("There will be " + CStr(Order.intQuantity) + " car(s) kustom built")
        frmInvoice.lstInvoice.Items.Add(" ")
        frmInvoice.lstInvoice.Items.Add("Kar form factor : " + CStr(Order.strCarType) + " at " + Order.decTypeCost.ToString("C"))
        frmInvoice.lstInvoice.Items.Add(" ")
        frmInvoice.lstInvoice.Items.Add("Drive Train : " + Order.strDriveTrain + vbTab + vbTab + Order.dblDriveTrain.ToString("C"))
        frmInvoice.lstInvoice.Items.Add(" ")
        frmInvoice.lstInvoice.Items.Add("Here are the options requested:")
        'Loop through list to add car options to invoice
        For Each i As String In orderListOptions
            frmInvoice.lstInvoice.Items.Add(vbTab + i)
        Next
        'finish printing invoice
        frmInvoice.lstInvoice.Items.Add(CStr(orderListOptions.Count) + " Option(s) Selected for a total of " + Order.decOptionCost.ToString("C"))
        frmInvoice.lstInvoice.Items.Add(" ")
        frmInvoice.lstInvoice.Items.Add(" ")
        frmInvoice.lstInvoice.Items.Add("Per Vehicle Total :" + vbTab + vbTab + (Order.decTotal.ToString("C")))
        frmInvoice.lstInvoice.Items.Add("--------------------------------------------------------------")
        frmInvoice.lstInvoice.Items.Add("Quantity Ordered:" + vbTab + vbTab + CStr(Order.intQuantity))
        frmInvoice.lstInvoice.Items.Add("--------------------------------------------------------------")
        frmInvoice.lstInvoice.Items.Add("Grand Total: " + vbTab + vbTab + (Order.intQuantity * Order.decTotal - 0).ToString("C"))
        frmInvoice.lstInvoice.Items.Add(" ")
        frmInvoice.lstInvoice.Items.Add("===================================================")



    End Sub

    Private Sub isValid()
        '------------------------------------------------------------
        '-            Subprogram Name: Validate Inputs              -
        '------------------------------------------------------------
        '-                Written By: Justin Ganzak                 -
        '-                Written On: January 23, 2022              -
        '------------------------------------------------------------
        '- Subprogram Purpose:                                      -
        '-                                                          -
        '- This subroutine handles validating the inputs from the   -
        '- user. It checks if the name is blank or numeric, and then-
        '- checks if the listbox has a selected option. If it passes-
        '- Then it calls the generateInvoice(). If it fails to      -
        '- validate then it sends the corresponding error.          -
        '------------------------------------------------------------
        '- Parameter Dictionary (in parameter order):               -
        '- (None)                                                   -
        '------------------------------------------------------------
        '- Local Variable Dictionary (alphabetically):              -
        '- (None)                                                   -
        '------------------------------------------------------------


        'This loop validates the input
        If Not String.IsNullOrEmpty(txtName.Text) And Not String.IsNullOrWhiteSpace(txtName.Text) Then              'Check if the text box is null or empty, if not then move on
            If IsNumeric(txtName.Text) = False Then                 'Check if text box has numeric values in it, if not then move on
                If lstType.SelectedIndex >= 0 Then                  'Check if listbox has a selected index other than 0, if yes then move on
                    generateInvoice()                               'Call generateInvoice, hide this form and show the other form
                    Me.Visible = False
                    frmInvoice.Show()
                Else
                    MessageBox.Show("Order Invalid, Select a car type", "Kustom Karz Order System")             'Car type error message
                End If
            Else
                MessageBox.Show("Order Invalid, Name cannot contain numbers", "Kustom Karz Order System")       'Numeric Name error message
            End If
        Else
            MessageBox.Show("Order Invalid, Name cannot be blank", "Kustom Karz Order System")                  'blank name error message
        End If
    End Sub

End Class
